package it.controllers;

import com.hav.st.core.domain.Employee;
import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import com.hav.st.core.domain.Position;
import com.hav.st.core.domain.SalesStructure;
import com.hav.st.core.entities.functional.ApprovalStates;
import com.hav.st.core.models.ApprovalModel;
import com.hav.st.core.models.FullKpiModel;
import com.hav.st.core.models.FullSalesStructureModel;
import com.hav.st.core.models.SetManagementModel;
import com.hav.st.core.models.UpdateKpiModel;
import lombok.SneakyThrows;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static utils.GeneratorUtil.random5Digits;
import static utils.GeneratorUtil.randomDate;
import static utils.GeneratorUtil.randomDomainLevel;
import static utils.GeneratorUtil.randomDomainPosition;
import static utils.GeneratorUtil.randomDomainSalesStructure;

public class SalesStructureControllerTest extends AbstractTest {

    @Test
    public void createAndGetSalesStructure() {
        SalesStructure randomSalesStructure = createRandomSalesStructure();
        verifySalesStructure(randomSalesStructure, ApprovalStates.PENDING);
    }

    @SneakyThrows
    @Test
    public void updateSalesStructure() {
        SalesStructure originalSalesStructure = createRandomSalesStructure();

        SalesStructure salesStructure = new SalesStructure();
        salesStructure.setId(originalSalesStructure.getId());
        salesStructure.setName(originalSalesStructure.getName());
        salesStructure.setDescription(originalSalesStructure.getDescription());

        assertEquals(HttpStatus.NOT_MODIFIED.value(), updateSalesStructure(salesStructure));
        salesStructure.setName("NEW SALES STRUCTURE " + random5Digits());
        assertEquals(HttpStatus.OK.value(), updateSalesStructure(salesStructure));
        assertEquals(HttpStatus.NOT_MODIFIED.value(), updateSalesStructure(salesStructure));
        String uri = "/sales-structure/" + salesStructure.getId();
        MvcResult mvcResult = mvcSalesStructure.perform(
                MockMvcRequestBuilders.get(uri)
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals(HttpStatus.OK.value(), status);
        SalesStructure resultSalesStructure = super.mapFromJson(content, SalesStructure.class);
        assertNotNull(resultSalesStructure);
        assertEquals(resultSalesStructure.getId(), salesStructure.getId());
        assertEquals(resultSalesStructure.getName(), salesStructure.getName());
        assertEquals(resultSalesStructure.getDescription(), salesStructure.getDescription());
        //
        salesStructure.setId(null);
        assertEquals(HttpStatus.BAD_REQUEST.value(), updateSalesStructure(salesStructure));
    }

    @Test
    public void expireSalesStructure() {
        SalesStructure salesStructure = createRandomSalesStructure();
        assertTrue(salesStructure.getExpiryDate() == null);

        assertEquals(HttpStatus.BAD_REQUEST.value(), expireSalesStructure(salesStructure));

        Calendar instance = Calendar.getInstance();
        instance.setTime(salesStructure.getFromDate());
        instance.add(Calendar.MONTH, -12);
        salesStructure.setExpiryDate(instance.getTime());

        assertEquals(HttpStatus.NOT_ACCEPTABLE.value(), expireSalesStructure(salesStructure));

        instance.add(Calendar.MONTH, 24);
        salesStructure.setExpiryDate(instance.getTime());
        assertEquals(HttpStatus.OK.value(), expireSalesStructure(salesStructure));

        assertEquals(HttpStatus.NOT_ACCEPTABLE.value(), expireSalesStructure(salesStructure));
    }

    @Test
    public void attachLevelTreeToSalesStructure() {
        // Normal
        SalesStructure salesStructure = createRandomSalesStructure();
        LevelTree levelTree = createRandomLevelTree();
        assertEquals(HttpStatus.OK.value(), attachLevelTreeToSalesStructure(salesStructure, levelTree));
        assertEquals(HttpStatus.NOT_ACCEPTABLE.value(), attachLevelTreeToSalesStructure(salesStructure, levelTree));
        // can not attach if sales structure already have level tree
        LevelTree levelTree2 = createRandomLevelTree();
        assertEquals(HttpStatus.NOT_ACCEPTABLE.value(), attachLevelTreeToSalesStructure(salesStructure, levelTree2));
        // can not attach if level tree already attached to a sale structure
        SalesStructure salesStructure2 = createRandomSalesStructure();
        assertEquals(HttpStatus.NOT_ACCEPTABLE.value(), attachLevelTreeToSalesStructure(salesStructure2, levelTree));
        //
        FullSalesStructureModel fullSalesStructure = getFullSalesStructure(salesStructure);
        assertNotNull(fullSalesStructure.getLevelTree());
        assertEquals(levelTree.getId(), fullSalesStructure.getLevelTree().getId());
    }

    @Test
    public void approveSalesStructures() {
        Collection<SalesStructure> salesStructures = Arrays.asList(new SalesStructure[]{
                createRandomSalesStructure(),
        });

        LevelTree levelTree = createRandomLevelTree();

        assertEquals(HttpStatus.OK.value(), attachLevelTreeToSalesStructure(salesStructures.stream().findFirst().get(), levelTree));

        assertEquals(HttpStatus.BAD_REQUEST.value(), approveSalesStructures(salesStructures, ApprovalStates.PENDING));
        assertEquals(HttpStatus.OK.value(), approveSalesStructures(salesStructures, ApprovalStates.APPROVED));
        assertEquals(HttpStatus.NOT_ACCEPTABLE.value(), approveSalesStructures(salesStructures, ApprovalStates.APPROVED));
        assertEquals(HttpStatus.NOT_ACCEPTABLE.value(), approveSalesStructures(salesStructures, ApprovalStates.REJECTED));
    }

    @Test
    public void addPositionsIntoSaleStructure() {
        SalesStructure salesStructure = createRandomSalesStructure();
        LevelTree levelTree = createRandomLevelTree();
        assertEquals(HttpStatus.OK.value(), attachLevelTreeToSalesStructure(salesStructure, levelTree));
        Employee[] employees = {
                createEmployee(),
                createEmployee()
        };
        Level[] levels = addLevelsToTree(levelTree, randomDomainLevel(2)).toArray(new Level[2]);
        Position[] positions = {
                randomDomainPosition(employees[0], levels[0]),
                randomDomainPosition(employees[1], levels[1]),
        };
        assertEquals(2, addPositionsIntoSaleStructure(salesStructure, Arrays.asList(positions)).length);
    }

    @Test
    public void addRelationIsManagerOf() {
        SalesStructure salesStructure = createRandomSalesStructure();
        LevelTree levelTree = createRandomLevelTree();
        assertEquals(HttpStatus.OK.value(), attachLevelTreeToSalesStructure(salesStructure, levelTree));
        Employee[] employees = {
                createEmployee(),
                createEmployee()
        };
        Level[] levels = addLevelsToTree(levelTree, randomDomainLevel(2)).toArray(new Level[2]);
        Position[] positions = {
                randomDomainPosition(employees[0], levels[0]),
                randomDomainPosition(employees[1], levels[1]),
        };
        assertEquals(2, addPositionsIntoSaleStructure(salesStructure, Arrays.asList(positions)).length);

        SetManagementModel model = new SetManagementModel();
        List<SetManagementModel.RelInfo> relInfoList = new ArrayList<>();
        model.setRelationshipsInfo(relInfoList);

        relInfoList.add(new SetManagementModel.RelInfo(employees[0].getSalesId(), employees[1].getSalesId(), randomDate(2015, 1)));
        relInfoList.add(new SetManagementModel.RelInfo(employees[1].getSalesId(), employees[0].getSalesId(), randomDate(2015, 2)));

        assertEquals(HttpStatus.CREATED.value(), addRelationIsManagerOf(model));

        FullSalesStructureModel fullSalesStructure = getFullSalesStructure(salesStructure);
        assertNotNull(fullSalesStructure.getPositions());
        assertEquals(2, fullSalesStructure.getPositions().size());
        assertNotNull(fullSalesStructure.getIsManagerOfs());
        assertEquals(2, fullSalesStructure.getIsManagerOfs().size());
    }

    @Test
    public void createKpiForSalesStructure() {
        SalesStructure salesStructure = createRandomSalesStructure();
        LevelTree levelTree = createRandomLevelTree();
        assertEquals(HttpStatus.OK.value(), attachLevelTreeToSalesStructure(salesStructure, levelTree));
        Level[] levels = addLevelsToTree(levelTree, randomDomainLevel(2)).toArray(new Level[2]);

        UpdateKpiModel model = new UpdateKpiModel();
        model.setName(random5Digits());
        model.setDesc(random5Digits());
        model.setType(random5Digits());
        model.setFromDate(randomDate(2015));

        List<UpdateKpiModel.KpiByLevel> kpiByLevels = new ArrayList<>();
        model.setTargetValues(kpiByLevels);

        kpiByLevels.add(new UpdateKpiModel.KpiByLevel(levels[0].getLevelCode(), 0, 9.5));

        FullKpiModel fullKpiModel = createKpiForSalesStructure(salesStructure, model, levels);
        assertNotNull(fullKpiModel.getKpi());
        assertEquals(model.getName(), fullKpiModel.getKpi().getName());
        assertEquals(model.getDesc(), fullKpiModel.getKpi().getDesc());
        assertEquals(model.getType(), fullKpiModel.getKpi().getType());
        assertEquals(levels.length, fullKpiModel.getTargetValues().size());
        assertTrue(fullKpiModel.getTargetValues().stream().findFirst().isPresent());
        assertTrue(fullKpiModel.getTargetValues().stream().filter(x -> x.getLevel().getLevelCode().equals(kpiByLevels.get(0).getLevelCode())).findAny().isPresent());
        assertEqualsDouble(kpiByLevels.get(0).getWeight(), fullKpiModel.getTargetValues().stream().filter(x -> x.getLevel().getLevelCode().equals(kpiByLevels.get(0).getLevelCode())).findAny().get().getWeight());
    }

    @Test
    public void updateKpiForSalesStructure() {
        SalesStructure salesStructure = createRandomSalesStructure();
        LevelTree levelTree = createRandomLevelTree();
        assertEquals(HttpStatus.OK.value(), attachLevelTreeToSalesStructure(salesStructure, levelTree));
        Level[] levels = addLevelsToTree(levelTree, randomDomainLevel(2)).toArray(new Level[2]);

        UpdateKpiModel model = new UpdateKpiModel();
        model.setName(random5Digits());
        model.setDesc(random5Digits());
        model.setType(random5Digits());
        model.setFromDate(randomDate(2015));

        List<UpdateKpiModel.KpiByLevel> kpiByLevels = new ArrayList<>();
        model.setTargetValues(kpiByLevels);

        kpiByLevels.add(new UpdateKpiModel.KpiByLevel(levels[0].getLevelCode(), 0, 9.5));

        FullKpiModel fullKpiModel = createKpiForSalesStructure(salesStructure, model, levels);
        assertNotNull(fullKpiModel);

        model = new UpdateKpiModel();
        model.setKpiId(fullKpiModel.getKpi().getId());
        model.setName("IMCHANGED");
        kpiByLevels = new ArrayList<>();
        model.setTargetValues(kpiByLevels);

        kpiByLevels.add(new UpdateKpiModel.KpiByLevel(levels[0].getLevelCode(), 1.2, 8.2));
        kpiByLevels.add(new UpdateKpiModel.KpiByLevel(levels[1].getLevelCode(), 1.3, 2.8));
        levels = addLevelsToTree(levelTree, randomDomainLevel(1)).toArray(new Level[1]);
        kpiByLevels.add(new UpdateKpiModel.KpiByLevel(levels[0].getLevelCode(), 1.4, 1.1));

        fullKpiModel = updateKpiForSalesStructure(salesStructure, model);
        assertNotNull(fullKpiModel);
        assertEquals("IMCHANGED", fullKpiModel.getKpi().getName());
        assertEquals(3, fullKpiModel.getTargetValues().size());
        assertEqualsDouble(1.2 + 1.3 + 1.4, fullKpiModel.getTargetValues().stream().mapToDouble(x -> x.getTarget()).sum());
        assertEqualsDouble(8.2 + 2.8 + 1.1, fullKpiModel.getTargetValues().stream().mapToDouble(x -> x.getWeight()).sum());
    }

    @SneakyThrows
    protected FullKpiModel createKpiForSalesStructure(SalesStructure salesStructure, UpdateKpiModel model, Level[] levels) {
        String uri = "/sales-structure/" + salesStructure.getId() + "/_kpi";
        MvcResult mvcResult = mvcSalesStructure.perform(
                MockMvcRequestBuilders.post(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapToJson(model))
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals(HttpStatus.CREATED.value(), status);
        FullKpiModel resultFullSalesStructure = super.mapFromJson(content, FullKpiModel.class);
        assertNotNull(resultFullSalesStructure);
        assertEquals(levels.length, resultFullSalesStructure.getTargetValues().size());
        return resultFullSalesStructure;
    }

    @SneakyThrows
    protected FullKpiModel updateKpiForSalesStructure(SalesStructure salesStructure, UpdateKpiModel model) {
        String uri = "/sales-structure/" + salesStructure.getId() + "/_kpi";
        MvcResult mvcResult = mvcSalesStructure.perform(
                MockMvcRequestBuilders.patch(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapToJson(model))
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals(HttpStatus.OK.value(), status);
        FullKpiModel resultFullSalesStructure = super.mapFromJson(content, FullKpiModel.class);
        assertNotNull(resultFullSalesStructure);
        return resultFullSalesStructure;
    }

    @SneakyThrows
    protected int addRelationIsManagerOf(SetManagementModel model) {
        String uri = "/sales-structure/_positions/_management-relationship/_batch";
        MvcResult mvcResult = mvcSalesStructure.perform(
                MockMvcRequestBuilders.post(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapToJson(model))
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        return mvcResult.getResponse().getStatus();
    }

    @SneakyThrows
    protected Position[] addPositionsIntoSaleStructure(SalesStructure salesStructure, Collection<Position> positions) {
        assertFalse(CollectionUtils.isEmpty(positions));
        String uri = "/sales-structure/" + salesStructure.getId() + "/_positions/_batch";
        MvcResult mvcResult = mvcSalesStructure.perform(
                MockMvcRequestBuilders.post(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapToJson(positions))
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.CREATED.value(), status);
        String content = mvcResult.getResponse().getContentAsString();
        Position[] resultPositions = super.mapFromJson(content, Position[].class);
        assertNotNull(resultPositions);

        Position[] arrayPosition = positions.toArray(new Position[positions.size()]);

        for (int i = 0; i < arrayPosition.length; i++) {
            assertEquals(arrayPosition[i].getSalesId(), resultPositions[i].getSalesId());
            assertEquals(arrayPosition[i].getLevelCode(), resultPositions[i].getLevelCode());
        }

        return resultPositions;
    }

    @SneakyThrows
    protected FullSalesStructureModel getFullSalesStructure(SalesStructure salesStructure) {
        String uri = "/sales-structure/" + salesStructure.getId() + "/_full";
        MvcResult mvcResult = mvcSalesStructure.perform(
                MockMvcRequestBuilders.get(uri)
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals(HttpStatus.OK.value(), status);
        FullSalesStructureModel resultFullSalesStructure = super.mapFromJson(content, FullSalesStructureModel.class);
        assertNotNull(resultFullSalesStructure);
        assertEquals(salesStructure.getId(), resultFullSalesStructure.getSalesStructure().getId());
        return resultFullSalesStructure;
    }

    @SneakyThrows
    protected int attachLevelTreeToSalesStructure(SalesStructure salesStructure, LevelTree levelTree) {
        String uri = "/sales-structure/" + salesStructure.getId() + "/_level-tree/" + levelTree.getId();
        MvcResult mvcResult = mvcSalesStructure.perform(
                MockMvcRequestBuilders.post(uri)
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        return mvcResult.getResponse().getStatus();
    }

    @SneakyThrows
    protected int approveSalesStructures(Collection<SalesStructure> collection, ApprovalStates newState) {
        ApprovalModel<SalesStructure> approvalModel = new ApprovalModel<>();
        approvalModel.setCollection(collection);
        approvalModel.setApprovalState(newState);

        String uri = "/sales-structure/_approval/_batch";
        MvcResult mvcResult = mvcSalesStructure.perform(
                MockMvcRequestBuilders.post(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapToJson(approvalModel))
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        return mvcResult.getResponse().getStatus();
    }

    @SneakyThrows
    protected int expireSalesStructure(SalesStructure salesStructure) {
        String uri = "/sales-structure";
        MvcResult mvcResult = mvcSalesStructure.perform(
                MockMvcRequestBuilders.delete(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapToJson(salesStructure))
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        return mvcResult.getResponse().getStatus();
    }

    @SneakyThrows
    protected void verifySalesStructure(SalesStructure salesStructure, ApprovalStates approvalStates) {
        assertNotNull(salesStructure.getId());

        String uri = "/sales-structure/" + salesStructure.getId();
        MvcResult mvcResult = mvcSalesStructure.perform(
                MockMvcRequestBuilders.get(uri)
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals(HttpStatus.OK.value(), status);
        SalesStructure resultSalesStructure = mapFromJson(content, SalesStructure.class);
        assertNotNull(resultSalesStructure);
        assertEquals(salesStructure.getId(), resultSalesStructure.getId());
        assertEquals(salesStructure.getName(), resultSalesStructure.getName());
        assertEquals(salesStructure.getDescription(), resultSalesStructure.getDescription());
        assertEquals(approvalStates, salesStructure.getApprovalState());
        assertEquals(salesStructure.getFromDate(), resultSalesStructure.getFromDate());
    }

    @SneakyThrows
    protected SalesStructure createRandomSalesStructure() {
        SalesStructure salesStructure = randomDomainSalesStructure();

        String uri = "/sales-structure";
        MvcResult mvcResult = mvcSalesStructure.perform(
                MockMvcRequestBuilders.post(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapToJson(salesStructure))
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals(HttpStatus.CREATED.value(), status);
        SalesStructure resultSalesStructure = mapFromJson(content, SalesStructure.class);
        assertNotNull(resultSalesStructure);
        assertNotNull(resultSalesStructure.getId());
        assertEquals(ApprovalStates.PENDING, resultSalesStructure.getApprovalState());

        return resultSalesStructure;
    }

    @SneakyThrows
    protected int updateSalesStructure(SalesStructure salesStructure) {
        String uri = "/sales-structure";
        MvcResult mvcResult = mvcSalesStructure.perform(
                MockMvcRequestBuilders.patch(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapToJson(salesStructure))
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        return mvcResult.getResponse().getStatus();
    }
}
