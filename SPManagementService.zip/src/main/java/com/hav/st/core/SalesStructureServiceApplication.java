package com.hav.st.core;

import com.hav.st.core.component.GraphEntityEventListener;
import org.neo4j.ogm.session.SessionFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.PostConstruct;


/**
 * @author Minhdd
 */
@SpringBootApplication
public class SalesStructureServiceApplication {

    private final SessionFactory neo4jSessionFactory;

//    private final org.hibernate.SessionFactory pgSessionFactory;

    //    public SalesStructureServiceApplication(SessionFactory sessionFactory, org.hibernate.SessionFactory pgSessionFactory) {
//        this.neo4jSessionFactory = sessionFactory;
//        this.pgSessionFactory = pgSessionFactory;
//    }
    public SalesStructureServiceApplication(SessionFactory sessionFactory) {
        this.neo4jSessionFactory = sessionFactory;

    }

    @PostConstruct
    public void registerEventlistener() {
        neo4jSessionFactory.register(new GraphEntityEventListener());
    }

    public static void main(String[] args) {
        SpringApplication.run(SalesStructureServiceApplication.class, args);
    }

}