package com.hav.st.core.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hav.st.core.entities.functional.Approvable;
import com.hav.st.core.entities.functional.ApprovalStates;
import com.hav.st.core.entities.functional.Expirable;
import com.hav.st.core.exceptions.InvalidOperationSpmsException;
import lombok.Data;
import lombok.NonNull;
import lombok.SneakyThrows;

import java.time.Instant;
import java.util.Date;
import java.util.concurrent.Callable;
import java.util.function.Function;

@Data
public abstract class DomainEntity {

    protected String id;
    private String approvalStates;
    private Date fromDate;
    private Date toDate;

    @JsonIgnore
    public ApprovalStates getApprovalState() {
        return ApprovalStates.of(approvalStates);
    }

    @JsonIgnore
    public void setApprovalState(ApprovalStates state) {
        this.approvalStates = state == null ? null : state.getShortName();
    }

    public void setFromDate(Date date) {
        fromDate = date;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setExpiryDate(Date date) {
        toDate = date;
    }

    public Date getExpiryDate() {
        return toDate;
    }

    @JsonIgnore
    public boolean isExpired() {
        if (this instanceof Expirable == false)
            return false;
        return toDate != null && toDate.toInstant().isBefore(Instant.now());
    }

    public boolean isExpiredAt(@NonNull Date date) {
        if (this instanceof Expirable == false)
            return false;
        return toDate != null && toDate.before(date);
    }
}