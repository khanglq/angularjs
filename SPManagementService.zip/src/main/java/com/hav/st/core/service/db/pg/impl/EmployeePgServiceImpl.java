package com.hav.st.core.service.db.pg.impl;

import com.hav.st.core.entities.pg.Employee;
import com.hav.st.core.exceptions.EntityNotFoundSpmsException;
import com.hav.st.core.repository.pg.EmployeePgRepository;
import com.hav.st.core.service.db.GenericDbServiceImpl;
import com.hav.st.core.service.db.pg.EmployeePgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.UUID;

@Service
@Transactional("jpaTransactionManager")
public class EmployeePgServiceImpl extends GenericDbServiceImpl<Employee, UUID, EmployeePgRepository> implements EmployeePgService {

    @Autowired
    private EmployeePgRepository repository;

    @Override
    protected EmployeePgRepository getRepository() {
        return repository;
    }

    @Override
    public Optional<Employee> findByEmpId(String employeeId) {
        return repository.findByEmpId(employeeId);
    }
}