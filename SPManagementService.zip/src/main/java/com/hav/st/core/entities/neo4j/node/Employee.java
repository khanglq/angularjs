package com.hav.st.core.entities.neo4j.node;

import com.hav.st.core.annotations.ShortName;
import com.hav.st.core.entities.functional.Approvable;
import com.hav.st.core.entities.functional.Expirable;
import com.hav.st.core.entities.neo4j.relationship.Incharge;
import lombok.Data;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Property;
import org.neo4j.ogm.annotation.Relationship;

import java.util.HashSet;
import java.util.Set;

@Data
@NodeEntity(label = "Employee")
public class Employee extends EntityNode implements Expirable, Approvable {

    @Property(name = "empid")
    private String employeeId;

    private String salesId;

    @Relationship(type = "INCHARGE")
    private Set<Incharge> allIncharges;

    public void addRelIncharge(Incharge incharge) {
        if (allIncharges == null) {
            allIncharges = new HashSet<>();
        }
        allIncharges.add(incharge);
    }

}