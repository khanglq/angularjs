package com.hav.st.core.domain;

import lombok.Data;
import org.springframework.beans.BeanUtils;

@Data
public class Level extends DomainEntity {

    private int level;
    private String levelCode;
    private String name;

    public static com.hav.st.core.entities.neo4j.node.Level toNeo4jEntity(Level domain) {
        com.hav.st.core.entities.neo4j.node.Level entity = new com.hav.st.core.entities.neo4j.node.Level();

        BeanUtils.copyProperties(domain, entity);
        return entity;
    }

    public static Level fromEntity(com.hav.st.core.entities.neo4j.node.Level entity) {
        Level domain = new Level();
        domain.id = entity.getCid();

        BeanUtils.copyProperties(entity, domain);
        return domain;
    }
}
