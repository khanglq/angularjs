package com.hav.st.core.entities.neo4j.relationship;

import com.hav.st.core.annotations.ShortName;
import com.hav.st.core.entities.functional.Expirable;
import com.hav.st.core.entities.neo4j.node.Employee;
import com.hav.st.core.entities.neo4j.node.Position;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.neo4j.ogm.annotation.RelationshipEntity;

@Data
@RelationshipEntity(type = "INCHARGE")
@ShortName("INC")
public class Incharge extends EntityRelationship<Employee, Position> implements Expirable {

}