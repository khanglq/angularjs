package com.hav.st.core.entities.functional;

public interface Approvable {
    ApprovalStates getApprovalState();
    void setApprovalState(ApprovalStates state);

    default boolean IsApproved() {
        return getApprovalState().isApproved();
    }

    default boolean IsPending() {
        return getApprovalState().isPending();
    }

    default boolean IsRejected() {
        return getApprovalState().isRejected();
    }
}
