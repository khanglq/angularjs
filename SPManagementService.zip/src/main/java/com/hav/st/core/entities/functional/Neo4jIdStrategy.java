package com.hav.st.core.entities.functional;

import com.hav.st.core.entities.neo4j.Neo4jEntity;
import com.hav.st.core.exceptions.InvalidOperationSpmsException;
import org.neo4j.ogm.id.IdStrategy;

import java.util.UUID;

public class Neo4jIdStrategy implements IdStrategy {
    @Override
    public Object generateId(Object o) {
        if (o instanceof Neo4jEntity) {
            return UUID.randomUUID().toString();
        }

        throw new InvalidOperationSpmsException("Can not generate id for non-neo4j entity objects");
    }
}