package com.hav.st.core.service.domain;

import com.hav.st.core.domain.Kpi;
import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import com.hav.st.core.domain.Position;
import com.hav.st.core.domain.SalesStructure;
import com.hav.st.core.domain.relationship.IsManagerOf;
import com.hav.st.core.entities.functional.ApprovalStates;
import com.hav.st.core.models.FullKpiModel;
import com.hav.st.core.models.FullSalesStructureModel;
import com.hav.st.core.models.SetManagementModel;
import com.hav.st.core.models.UnsetManagementModel;
import com.hav.st.core.models.UpdateKpiModel;

import java.util.Collection;
import java.util.Date;

public interface SalesStructureService {
    Collection<Position> addPositionsIntoSalesStructure(SalesStructure salesStructure, Collection<Position> positions);
    void addManagementRelationship(SetManagementModel model);
    void approveManagementRelationships(Collection<IsManagerOf> relationships, ApprovalStates newState);
    void expireManagementRelationship(UnsetManagementModel model);
    void expireManagementRelationship(String id, Date expiryDate);
    SalesStructure getSalesStructure(SalesStructure salesStructure);
    FullSalesStructureModel getFullSalesStructure(SalesStructure salesStructure);
    SalesStructure createSalesStructure(SalesStructure salesStructure);
    boolean updateSalesStructure(SalesStructure salesStructure);
    void expireSalesStructure(SalesStructure salesStructure);
    void expireSalesStructures(Collection<SalesStructure> salesStructures);
    void updateApprovalStateOfSalesStructures(Collection<SalesStructure> salesStructures, ApprovalStates newState);
    void updateApprovalStateOfPositions(Collection<Position> positions, ApprovalStates newState);
    void expirePositions(Collection<Position> positions);
    void updateSalesStructureSetUseLevelTree(SalesStructure salesStructure, LevelTree levelTree);
    Collection<Level> getLevelsWithinSalesStructure(SalesStructure salesStructure);
    FullKpiModel getKpi(Kpi kpi);
    FullKpiModel createKpiForSalesStructure(SalesStructure salesStructure, UpdateKpiModel model);
    FullKpiModel updateKpiForSalesStructure(SalesStructure salesStructure, UpdateKpiModel model);
}
