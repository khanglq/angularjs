package com.hav.st.core.service.domain.impl;

import com.hav.st.core.domain.Employee;
import com.hav.st.core.entities.functional.ApprovalStates;
import com.hav.st.core.exceptions.BadDataSpmsException;
import com.hav.st.core.exceptions.EntityNotFoundSpmsException;
import com.hav.st.core.exceptions.InvalidOperationSpmsException;
import com.hav.st.core.service.db.neo4j.EmployeeNeo4jService;
import com.hav.st.core.service.db.pg.EmployeePgService;
import com.hav.st.core.service.domain.EmployeeService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;


@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeePgService employeePgService;

    @Autowired
    private EmployeeNeo4jService employeeNeo4jService;

    @Override
    public void add(Employee employee) {
        validateEmployee(employee);

        CompletableFuture<Void> saveToPgFuture = CompletableFuture.runAsync(() -> {
            employeePgService.save(Employee.toPgEntity(employee));
        });

        CompletableFuture<Void> saveToNeo4jFuture = CompletableFuture.runAsync(() -> {
            employeeNeo4jService.save(Employee.toNeo4jEntity(employee));
        });

        CompletableFuture.allOf(saveToPgFuture, saveToNeo4jFuture).join();
    }

    @Override
    public void add(Collection<Employee> employees) {
        if (employees.isEmpty()) {
            throw new BadDataSpmsException("Require at least one employee");
        }

        for (Employee employee: employees) {
            validateEmployee(employee);
        }

        CompletableFuture<Void> saveToPgFuture = CompletableFuture.runAsync(() -> {
            employeePgService.saveAll(employees.stream().map(e -> Employee.toPgEntity(e)).collect(Collectors.toList()));
        });

        CompletableFuture<Void> saveToNeo4jFuture = CompletableFuture.runAsync(() -> {
            employeeNeo4jService.saveAll(employees.stream().map(e -> Employee.toNeo4jEntity(e)).collect(Collectors.toList()));
        });

        CompletableFuture.allOf(saveToPgFuture, saveToNeo4jFuture).join();
    }

    private void validateEmployee(Employee employee) {
        if (StringUtils.isBlank(employee.getEmployeeId())) {
            throw new BadDataSpmsException("Missing employee id");
        }

        if (StringUtils.isBlank(employee.getName())) {
            throw new BadDataSpmsException("Missing name of employee");
        }

        if (StringUtils.isBlank(employee.getAddress())) {
            throw new BadDataSpmsException("Missing address of employee");
        }

        if (StringUtils.isBlank(employee.getPhoneNo())) {
            throw new BadDataSpmsException("Missing phone number of employee");
        }

        if (StringUtils.isBlank(employee.getSalesId())) {
            throw new BadDataSpmsException("Missing sales id of employee");
        }

        if (employee.getProbationDate() == null) {
            throw new BadDataSpmsException("Missing probation date of employee");
        }
    }

    @Override
    public Employee findByEmpId(String empId) {
        com.hav.st.core.entities.neo4j.node.Employee employeeNeo4jEntity = employeeNeo4jService.findByEmpId(empId)
                .orElseThrow(EntityNotFoundSpmsException.of(com.hav.st.core.entities.neo4j.node.Employee.class, "empid", empId));
        com.hav.st.core.entities.pg.Employee employeePgEntity = employeePgService.findByEmpId(empId)
                .orElseThrow(EntityNotFoundSpmsException.of(com.hav.st.core.entities.pg.Employee.class, "empid", empId));

        return Employee.fromEntity(employeeNeo4jEntity, employeePgEntity);
    }

    @Override
    public void updateApprovalStateOfEmployees(Collection<Employee> employees, ApprovalStates newState) {
        if (employees.stream().anyMatch(x -> StringUtils.isBlank(x.getEmployeeId()))) {
            throw new BadDataSpmsException("Missing employee id");
        }

        if (newState == null) {
            throw new BadDataSpmsException("Approval state must not be null");
        }

        if (newState == ApprovalStates.PENDING) {
            throw new BadDataSpmsException("New approval state can not be PENDING");
        }

        for (Employee employee : employees) {
            com.hav.st.core.entities.neo4j.node.Employee employeeNeo4jEntity = employeeNeo4jService.findByEmpId(employee.getEmployeeId())
                    .orElseThrow(EntityNotFoundSpmsException.of(employee));

            if (!employeeNeo4jEntity.IsPending()) {
                throw new InvalidOperationSpmsException("Can only change approval state of PENDING employee");
            }

            employeeNeo4jEntity.setApprovalState(newState);

            employeeNeo4jService.save(employeeNeo4jEntity);
        }
    }
}