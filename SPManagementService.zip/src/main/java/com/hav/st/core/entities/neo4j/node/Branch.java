package com.hav.st.core.entities.neo4j.node;

import com.hav.st.core.annotations.ShortName;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.neo4j.ogm.annotation.NodeEntity;

@Data
@NodeEntity(label = "Branch")
@ShortName("CN")
public class Branch extends EntityNode {

    private String branchCode;

}
