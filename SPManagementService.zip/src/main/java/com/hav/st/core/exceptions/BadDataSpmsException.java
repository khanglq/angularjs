package com.hav.st.core.exceptions;

public class BadDataSpmsException extends SalePersonManagementServiceException {
    public BadDataSpmsException(String s) {
        super(s);
    }
}
