package com.hav.st.core.models;

import com.hav.st.core.domain.Kpi;
import com.hav.st.core.domain.Level;
import com.hav.st.core.entities.neo4j.relationship.ApplyTo;
import lombok.Data;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Data
public class FullKpiModel {
    private Kpi kpi;
    private Collection<TargetValue> targetValues;

    @Data
    public static class TargetValue {
        private Level level;
        private double target;
        private double weight;
    }

    public static FullKpiModel fromEntity(com.hav.st.core.entities.neo4j.node.Kpi entity) {
        FullKpiModel model = new FullKpiModel();
        model.setKpi(Kpi.fromNeo4jEntity(entity));

        List<TargetValue> targetValues = new ArrayList<>();
        if (!CollectionUtils.isEmpty(entity.getAllApplyTo())) {
            for (ApplyTo applyTo : entity.getAllApplyTo()) {
                TargetValue targetValue = new TargetValue();
                targetValue.setLevel(Level.fromEntity(applyTo.getToNode()));
                targetValue.setTarget(applyTo.getTarget());
                targetValue.setWeight(applyTo.getWeight());
                targetValues.add(targetValue);
            }
        }
        model.setTargetValues(targetValues);
        return model;
    }
}
