package com.hav.st.core.controller;

import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import com.hav.st.core.service.domain.LevelTreeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;

@Api(value = "level-tree", tags = {"level"}, description = "Levels management service")
@RestController
@RequestMapping("/level-tree")
public class LevelTreeController extends BaseController {

    private static final Logger logger = LogManager.getLogger(LevelTreeController.class);
    private LevelTreeService levelTreeService;

    public LevelTreeController(LevelTreeService levelTreeService) {
        this.levelTreeService = levelTreeService;
    }

    @ApiOperation(value = "Get Specific Level Tree")
    @GetMapping("/{treeId}")
    public ResponseEntity<LevelTree> getSpecificLevelTree(@PathVariable("treeId") String treeId) {
        LevelTree levelTree = new LevelTree();
        levelTree.setId(treeId);
        return Ok(levelTreeService.getTree(levelTree));
    }

    @ApiOperation(value = "Create new level tree")
    @PostMapping()
    public ResponseEntity<LevelTree> createNewLevelTree(@RequestBody LevelTree levelTree) {
        return Created(levelTreeService.addTree(levelTree));
    }

    @ApiOperation(value = "Update level tree partially")
    @PatchMapping()
    public ResponseEntity updateTreePartially(@RequestBody LevelTree levelTree) {
        if (StringUtils.isBlank(levelTree.getId())) {
            return BadRquest("Missing id");
        }

        return levelTreeService.updateTreePartially(levelTree) ? Ok() : NotModified();
    }

    @ApiOperation(value = "Add a level to tree")
    @PostMapping("/{treeId}/_level")
    public ResponseEntity<Level> addLevelToTree(@PathVariable("treeId") String treeId, @RequestBody Level level) {
        LevelTree levelTree = new LevelTree();
        levelTree.setId(treeId);
        return Created(levelTreeService.addLevel(levelTree, level));
    }

    @ApiOperation(value = "Add levels to tree", hidden = true)
    @PostMapping("/{treeId}/_level/_batch")
    public ResponseEntity<Collection<Level>> addLevelsToTree(@PathVariable("treeId") String treeId, @RequestBody Collection<Level> levels) {
        if (levels.isEmpty()) {
            return BadRquest();
        }

        LevelTree levelTree = new LevelTree();
        levelTree.setId(treeId);
        return Created(levelTreeService.addLevels(levelTree, levels));
    }
}
