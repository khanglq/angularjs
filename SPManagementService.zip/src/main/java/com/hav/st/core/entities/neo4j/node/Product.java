package com.hav.st.core.entities.neo4j.node;

import com.hav.st.core.annotations.ShortName;
import com.hav.st.core.entities.functional.Approvable;
import com.hav.st.core.entities.functional.ApprovalStates;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.neo4j.ogm.annotation.NodeEntity;

@Data
@NodeEntity(label = "Product")
@ShortName("SP")
public class Product extends EntityNode {

    private String productCode;

}
