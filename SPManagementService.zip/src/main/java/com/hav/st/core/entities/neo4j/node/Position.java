package com.hav.st.core.entities.neo4j.node;

import com.hav.st.core.annotations.ShortName;
import com.hav.st.core.entities.functional.Approvable;
import com.hav.st.core.entities.functional.Expirable;
import com.hav.st.core.entities.neo4j.relationship.Contains;
import com.hav.st.core.entities.neo4j.relationship.HasLevel;
import com.hav.st.core.entities.neo4j.relationship.Incharge;
import com.hav.st.core.entities.neo4j.relationship.IsManagerOf;
import lombok.Data;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import java.util.ArrayList;
import java.util.List;

@Data
@NodeEntity(label = "Position")
@ShortName("VT")
public class Position extends EntityNode implements Approvable, Expirable {

    private String salesId;

    @Relationship(type = "CONTAINS", direction = Relationship.INCOMING)
    private Contains contains;

    @Relationship(type = "INCHARGE", direction = Relationship.INCOMING)
    private Incharge incharge;

    @Relationship(type = "HAS_LEVEL")
    private HasLevel hasLevel;

    @Relationship(type = "IS_MANAGER_OF")
    private List<IsManagerOf> manages;

    @Relationship(type = "IS_MANAGER_OF", direction = Relationship.INCOMING)
    private List<IsManagerOf> managedBy;

    public void addRelManages(IsManagerOf rel) {
        if (manages == null) {
            manages = new ArrayList<>();
        }
        manages.add(rel);
    }

    public void addRelManagedBy(IsManagerOf rel) {
        if (managedBy == null) {
            managedBy = new ArrayList<>();
        }
        managedBy.add(rel);
    }
}