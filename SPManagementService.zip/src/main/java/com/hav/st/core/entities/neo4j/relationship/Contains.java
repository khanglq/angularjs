package com.hav.st.core.entities.neo4j.relationship;

import com.hav.st.core.entities.neo4j.node.Position;
import com.hav.st.core.entities.neo4j.node.SalesStructure;
import lombok.Data;
import org.neo4j.ogm.annotation.RelationshipEntity;

@Data
@RelationshipEntity(type = "CONTAINS")
public class Contains extends EntityRelationship<SalesStructure, Position> {

}
