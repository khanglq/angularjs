package com.hav.st.core.service.domain;

import com.hav.st.core.domain.Employee;
import com.hav.st.core.dto.MessageRequestDTO;
import com.hav.st.core.entities.functional.ApprovalStates;

import java.util.Collection;


public interface EmployeeService {
    void add(Employee employee);
    void add(Collection<Employee> employees);

    Employee findByEmpId(String empId);
    void updateApprovalStateOfEmployees(Collection<Employee> employees, ApprovalStates newState);
}
