package com.hav.st.core.service.domain;

import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;

import java.util.Collection;

public interface LevelTreeService {
    LevelTree getTree(LevelTree levelTree);
    LevelTree addTree(LevelTree levelTree);
    boolean updateTreePartially(LevelTree levelTree);
    Level addLevel(LevelTree levelTree, Level level);
    Collection<Level> addLevels(LevelTree levelTree, Collection<Level> levels);
}
