package com.hav.st.core.entities.pg;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;
import java.util.Date;
import java.util.UUID;

@Data
@Entity
@Table(name = "dim_employee")
public class Employee extends PostgresEntity {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "pk_id", updatable = false, nullable = false)
    private BigInteger id;

    @NotNull
    @Column(name = "empid", nullable = false)
    private String employeeId;

    @NotNull
    @Column(name = "name", nullable = false)
    private String name;

    @NotNull
    @Column(name = "address", nullable = false)
    private String address;

    @NotNull
    @Column(name = "phone_no", nullable = false)
    private String phoneNo;

    @NotNull
    @Column(name = "probation_date", nullable = false)
    private Date probationDate;
}