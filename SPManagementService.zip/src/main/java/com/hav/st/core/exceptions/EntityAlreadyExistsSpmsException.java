package com.hav.st.core.exceptions;

public class EntityAlreadyExistsSpmsException extends SalePersonManagementServiceException {
    public EntityAlreadyExistsSpmsException(String s) {
        super(s);
    }
}
