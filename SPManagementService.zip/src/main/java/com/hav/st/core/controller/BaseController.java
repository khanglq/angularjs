package com.hav.st.core.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin
public abstract class BaseController {
    protected ResponseEntity<String> Ok() {
        return Ok("Success");
    }

    protected ResponseEntity<String> Ok(String message) {
        return StatusCode(message, HttpStatus.OK);
    }

    protected <T> ResponseEntity Ok(@Nullable T body) {
        return StatusCode(body, HttpStatus.OK);
    }

    protected ResponseEntity Created() {
        return Created("Created");
    }

    protected <T> ResponseEntity Created(@Nullable T body) {
        return StatusCode(body, HttpStatus.CREATED);
    }

    protected ResponseEntity NotFound() {
        return StatusCode(HttpStatus.NOT_FOUND);
    }

    protected ResponseEntity NotFound(String message) {
        return StatusCode(message, HttpStatus.NOT_FOUND);
    }

    protected ResponseEntity Conflict() {
        return StatusCode(HttpStatus.CONFLICT);
    }

    protected ResponseEntity Conflict(String message) {
        return StatusCode(message, HttpStatus.CONFLICT);
    }

    protected ResponseEntity BadRquest() {
        return StatusCode(HttpStatus.BAD_REQUEST);
    }

    protected ResponseEntity BadRquest(String message) {
        return StatusCode(message, HttpStatus.BAD_REQUEST);
    }

    protected ResponseEntity NotModified() {
        return StatusCode(HttpStatus.NOT_MODIFIED);
    }

    protected <T> ResponseEntity StatusCode(HttpStatus httpStatus) {
        return new ResponseEntity<>(httpStatus);
    }

    protected ResponseEntity<String> StatusCode(String message, HttpStatus httpStatus) {
        return new ResponseEntity<>(message, httpStatus);
    }

    protected <T> ResponseEntity StatusCode(@Nullable T body, HttpStatus httpStatus) {
        return new ResponseEntity<>(body, httpStatus);
    }

    // extra
    protected ResponseEntity Deleted() {
        return Ok("Deleted");
    }
}
