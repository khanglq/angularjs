package com.hav.st.core.domain;

import lombok.Data;
import org.springframework.beans.BeanUtils;

@Data
public class LevelTree extends DomainEntity {

    private String name;
    private String description;

    public static com.hav.st.core.entities.neo4j.node.LevelTree toNeo4jEntity(LevelTree domain) {
        com.hav.st.core.entities.neo4j.node.LevelTree entity = new com.hav.st.core.entities.neo4j.node.LevelTree();

        BeanUtils.copyProperties(domain, entity);
        return entity;
    }

    public static LevelTree fromEntity(com.hav.st.core.entities.neo4j.node.LevelTree entity) {
        LevelTree domain = new LevelTree();
        domain.id = entity.getCid();

        BeanUtils.copyProperties(entity, domain);
        return domain;
    }
}
