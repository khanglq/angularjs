package com.hav.st.core.entities.pg;

public abstract class PostgresEntity {
}
