package com.hav.st.core.repository.neo4j.node;

import com.hav.st.core.entities.neo4j.node.Position;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface PositionNeo4jRepository extends Neo4jRepository<Position, String> {

    @Query("MATCH (m:Position) WHERE m.salesId = {salesId} RETURN m ")
    Optional<Position> findBySalesId(@Param("salesId") String salesId);

}
