package com.hav.st.core.exceptions;

import com.hav.st.core.domain.DomainEntity;

import java.util.function.Supplier;

public class EntityNotFoundSpmsException extends SalePersonManagementServiceException {
    public EntityNotFoundSpmsException(String s) {
        super(s);
    }

    public static Supplier<EntityNotFoundSpmsException> of(DomainEntity domain) {
        return of(domain.getClass(), "cid", domain.getId());
    }

    public static Supplier<EntityNotFoundSpmsException> ofPosition(String propertyName, Object value) {
        return of(com.hav.st.core.entities.neo4j.node.Position.class, propertyName, value);
    }

    public static Supplier<EntityNotFoundSpmsException> of(Class clz, Object rid) {
        return of(clz, "cid", rid);
    }

    public static Supplier<EntityNotFoundSpmsException> of(Class clz, String propertyName, Object value) {
        return msg(clz.getSimpleName() + " with " + propertyName + " = '" + value + "' could not be found");
    }

    public static Supplier<EntityNotFoundSpmsException> msg(String message) {
        return () -> new EntityNotFoundSpmsException(message);
    }
}
