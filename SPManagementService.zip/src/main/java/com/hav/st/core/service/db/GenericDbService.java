package com.hav.st.core.service.db;

import org.springframework.data.repository.CrudRepository;

import java.util.Collection;

public interface GenericDbService<T, ID, TRepo extends CrudRepository<T, ID>> {
    void save(T entity);
    void saveAll(Collection<T> entities);
}