package com.hav.st.core.exceptions;

/**
 * Delivered type of exception can be safely report message to client.
 * Delivered type of exception ONLY be used to print exception to client.
 */
public abstract class SalePersonManagementServiceException extends RuntimeException {
    public SalePersonManagementServiceException(String s) {
        super(s);
    }

    public SalePersonManagementServiceException(String s, Throwable throwable) {
        super(s, throwable);
    }
}
