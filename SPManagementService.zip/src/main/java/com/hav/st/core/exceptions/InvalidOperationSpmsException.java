package com.hav.st.core.exceptions;

public class InvalidOperationSpmsException extends SalePersonManagementServiceException {
    public InvalidOperationSpmsException() {
        super("Invalid operation");
    }

    public InvalidOperationSpmsException(String s) {
        super(s);
    }
}
