package com.hav.st.core.exceptions.handler;

import com.hav.st.core.exceptions.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

@RestControllerAdvice
public class ApiExceptionHandler {

    /**
     * Tất cả các Exception không được khai báo sẽ được xử lý tại đây
     * @return
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleAllException(Exception ex, WebRequest request) {
        ex.printStackTrace();
        return "Internal server error";
    }

    @ExceptionHandler(EntityNotFoundSpmsException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public String WhenEntityNotFound(Exception ex, WebRequest request) {
        ex.printStackTrace();
        return printMessage(ex);
    }

    @ExceptionHandler(EntityAlreadyExistsSpmsException.class)
    @ResponseStatus(value = HttpStatus.CONFLICT)
    public String WhenEntityAlreadyExists(Exception ex, WebRequest request) {
        ex.printStackTrace();
        return printMessage(ex);
    }

    @ExceptionHandler(InvalidOperationSpmsException.class)
    @ResponseStatus(value = HttpStatus.NOT_ACCEPTABLE)
    public String WhenInvalidOperationSpmsException(Exception ex, WebRequest request) {
        ex.printStackTrace();
        return printMessage(ex);
    }

    @ExceptionHandler(BadDataSpmsException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public String WhenBadDataSpmsException(Exception ex, WebRequest request) {
        ex.printStackTrace();
        return printMessage(ex);
    }

    // @ExceptionHandler(BadDataSpmsException.class)
    @ExceptionHandler(SalePersonManagementServiceException.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public String DefaultForSalePersonManagementServiceException(Exception ex, WebRequest request) {
        ex.printStackTrace();
        return printMessage(ex);
    }

    private String printMessage(Exception ex) {
        return ex.getMessage();
    }
}