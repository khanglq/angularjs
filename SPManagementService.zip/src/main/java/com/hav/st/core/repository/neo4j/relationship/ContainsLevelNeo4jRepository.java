package com.hav.st.core.repository.neo4j.relationship;

import com.hav.st.core.entities.neo4j.relationship.Contains;
import com.hav.st.core.entities.neo4j.relationship.ContainsLevel;
import org.springframework.data.neo4j.repository.Neo4jRepository;

public interface ContainsLevelNeo4jRepository extends Neo4jRepository<ContainsLevel, String> {
}
