package com.hav.st.core.models;

import com.hav.st.core.domain.DomainEntity;
import com.hav.st.core.entities.functional.ApprovalStates;
import lombok.Data;

import java.util.Collection;

@Data
public class ApprovalModel<T extends DomainEntity> {
    Collection<T> collection;
    ApprovalStates approvalState;
}
