package com.hav.st.core.entities.neo4j.node;

import com.hav.st.core.entities.functional.Neo4jIdStrategy;
import com.hav.st.core.entities.neo4j.Neo4jEntity;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;

import java.util.Date;

@Data
@NodeEntity
public abstract class EntityNode extends Neo4jEntity {

}
