package com.hav.st.core.entities.neo4j.node;

import com.hav.st.core.annotations.ShortName;
import com.hav.st.core.entities.neo4j.relationship.ContainsLevel;
import com.hav.st.core.entities.neo4j.relationship.UseLevelTree;
import lombok.Data;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import java.util.ArrayList;
import java.util.List;

@Data
@NodeEntity(label = "LevelTree")
@ShortName("CCV")
public class LevelTree extends EntityNode {

    private String name;
    private String description;

    @Relationship(type = "CONTAINS_LEVEL")
    private List<ContainsLevel> allContains;

    @Relationship(type = "USE_LEVEL_TREE", direction = Relationship.INCOMING)
    private UseLevelTree useLevelTree;

    public void addRelContains(ContainsLevel contains) {
        if (allContains == null) {
            allContains = new ArrayList<>();
        }
        allContains.add(contains);
    }
}