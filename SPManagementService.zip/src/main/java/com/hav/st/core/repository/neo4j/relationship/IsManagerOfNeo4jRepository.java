package com.hav.st.core.repository.neo4j.relationship;

import com.hav.st.core.entities.neo4j.node.Position;
import com.hav.st.core.entities.neo4j.relationship.IsManagerOf;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface IsManagerOfNeo4jRepository extends Neo4jRepository<IsManagerOf, String> {

    @Query("MATCH (f:Position)-[r:IS_MANAGER_OF]->(t:Position) WHERE f.salesId = {fromSalesId} AND t.salesId = {toSalesId} AND NOT EXISTS(r.toDate) AND r.approvalStates = 'A' RETURN r")
    Optional<IsManagerOf> findCurrentlyActivatedRelationship(@Param("fromSalesId") String fromSalesId, @Param("toSalesId") String toSalesId);

}