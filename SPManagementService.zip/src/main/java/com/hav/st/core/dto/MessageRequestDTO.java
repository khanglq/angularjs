package com.hav.st.core.dto;

import lombok.Data;

import java.util.List;

@Data
public class MessageRequestDTO<T> {

    public enum Command {
        NONE,
        UPDATE,
    }

    public enum Type {
        NONE,
        REL,
    }

    public static final String UPDATE_CMD = "UPD";
    public static final String REL_TYPE = "REL";

    private Command cmd;
    private Type type;
    private List<T> msg;
}
