package com.hav.st.core.service.db.pg;

import com.hav.st.core.entities.pg.Employee;
import com.hav.st.core.repository.pg.EmployeePgRepository;
import com.hav.st.core.service.db.GenericDbService;

import java.util.Collection;
import java.util.Optional;
import java.util.UUID;

public interface EmployeePgService extends GenericDbService<Employee, UUID, EmployeePgRepository> {
    void save(Employee employee);
    void saveAll(Collection<Employee> employees);
    Optional<Employee> findByEmpId(String employeeId);
}