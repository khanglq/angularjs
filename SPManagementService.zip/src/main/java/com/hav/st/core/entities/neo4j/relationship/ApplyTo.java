package com.hav.st.core.entities.neo4j.relationship;

import com.hav.st.core.entities.neo4j.node.Kpi;
import com.hav.st.core.entities.neo4j.node.Level;
import lombok.Data;
import org.neo4j.ogm.annotation.RelationshipEntity;

@Data
@RelationshipEntity(type = "APPLY_TO")
public class ApplyTo extends  EntityRelationship<Kpi, Level> {
    private double target;
    private double weight;
}
