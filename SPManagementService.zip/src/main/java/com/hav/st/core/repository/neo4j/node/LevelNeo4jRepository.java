package com.hav.st.core.repository.neo4j.node;

import com.hav.st.core.entities.neo4j.node.Level;
import org.springframework.data.neo4j.repository.Neo4jRepository;

public interface LevelNeo4jRepository extends Neo4jRepository<Level, String> {
}
