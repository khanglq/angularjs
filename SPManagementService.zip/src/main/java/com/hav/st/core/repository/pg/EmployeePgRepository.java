package com.hav.st.core.repository.pg;

import com.hav.st.core.entities.pg.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface EmployeePgRepository extends JpaRepository<Employee, UUID> {
    /*
    @Query("SELECT u FROM Employee u WHERE LOWER(u.name) = LOWER(:username)")
    Employee findByUsernameCaseInsensitive(@Param("username") String username);

    @Query
    Employee findByEmail(String email);
     */

    @Query("SELECT u FROM Employee u ")
    List<Employee> findAll();

    @Query("SELECT u FROM Employee u WHERE u.employeeId = :employeeId")
    Optional<Employee> findByEmpId(@Param("employeeId") String employeeId);
}