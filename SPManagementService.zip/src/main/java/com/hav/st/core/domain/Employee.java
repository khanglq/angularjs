package com.hav.st.core.domain;

import com.hav.st.core.entities.functional.Approvable;
import com.hav.st.core.entities.functional.Expirable;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.Date;

@Data
public class Employee extends DomainEntity implements Expirable, Approvable {

    @NotNull
    private String employeeId;

    @NotNull
    private String name;

    @NotNull
    private String salesId;

    @NotNull
    private String address;

    @NotNull
    private String phoneNo;

    @NotNull
    private Date probationDate;

    public static com.hav.st.core.entities.pg.Employee toPgEntity(Employee employee) {
        com.hav.st.core.entities.pg.Employee employeeEntity = new com.hav.st.core.entities.pg.Employee();
        employeeEntity.setEmployeeId(employee.getEmployeeId());
        employeeEntity.setName(employee.getName());
        employeeEntity.setAddress(employee.getAddress());
        employeeEntity.setPhoneNo(employee.getPhoneNo());
        employeeEntity.setProbationDate(employee.getProbationDate());
        return employeeEntity;
    }

    public static com.hav.st.core.entities.neo4j.node.Employee toNeo4jEntity(Employee employee) {
        com.hav.st.core.entities.neo4j.node.Employee nodeEmployeeEntity = new com.hav.st.core.entities.neo4j.node.Employee();
        nodeEmployeeEntity.setEmployeeId(employee.getEmployeeId());
        nodeEmployeeEntity.setSalesId(employee.getSalesId());
        nodeEmployeeEntity.setFromDate(employee.getFromDate());
        return nodeEmployeeEntity;
    }

    public static Employee fromEntity(com.hav.st.core.entities.neo4j.node.Employee employeeNeo4jEntity, com.hav.st.core.entities.pg.Employee employeePgEntity) {
        Employee employee = new Employee();

        // copy from neo4j
        employee.setEmployeeId(employeeNeo4jEntity.getEmployeeId());
        employee.setSalesId(employeeNeo4jEntity.getSalesId());
        employee.setFromDate(employeeNeo4jEntity.getFromDate());
        employee.setApprovalState(employeeNeo4jEntity.getApprovalState());

        // copy from pg
        employee.setName(employeePgEntity.getName());
        employee.setAddress(employeePgEntity.getAddress());
        employee.setPhoneNo(employeePgEntity.getPhoneNo());
        employee.setProbationDate(employeePgEntity.getProbationDate());

        return employee;
    }
}
