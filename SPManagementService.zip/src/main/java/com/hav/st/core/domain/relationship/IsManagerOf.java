package com.hav.st.core.domain.relationship;

import com.hav.st.core.domain.DomainEntity;
import com.hav.st.core.entities.functional.Approvable;
import com.hav.st.core.entities.functional.Expirable;
import lombok.Data;

@Data
public class IsManagerOf extends DomainEntity implements Approvable, Expirable {
    private String fromPositionId;
    private String toPositionId;

    public static IsManagerOf fromNeo4jEntity(com.hav.st.core.entities.neo4j.relationship.IsManagerOf entity) {
        IsManagerOf domain = new IsManagerOf();
        domain.setId(entity.getCid());

        domain.setFromPositionId(entity.getFromNode().getCid());
        domain.setToPositionId(entity.getToNode().getCid());
        return domain;
    }
}