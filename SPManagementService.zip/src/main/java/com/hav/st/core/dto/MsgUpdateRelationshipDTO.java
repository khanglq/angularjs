package com.hav.st.core.dto;

import lombok.Data;

import java.util.*;

@Data
public class MsgUpdateRelationshipDTO<D> {
    public MsgUpdateRelationshipDTO() {
    }

    private String fromId;
    private String toId;
    private List<D> rel;
}
