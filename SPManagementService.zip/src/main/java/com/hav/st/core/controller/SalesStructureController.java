package com.hav.st.core.controller;

import com.hav.st.core.domain.Kpi;
import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import com.hav.st.core.domain.Position;
import com.hav.st.core.domain.SalesStructure;
import com.hav.st.core.domain.relationship.IsManagerOf;
import com.hav.st.core.models.ApprovalModel;
import com.hav.st.core.models.FullKpiModel;
import com.hav.st.core.models.FullSalesStructureModel;
import com.hav.st.core.models.SetManagementModel;
import com.hav.st.core.models.UnsetManagementModel;
import com.hav.st.core.models.UpdateKpiModel;
import com.hav.st.core.service.domain.SalesStructureService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;
import java.util.Date;

@Api(value = "sales-structure", tags = {"sales-structure"}, description = "Sales structures management service")
@RestController
@RequestMapping("/sales-structure")
public class SalesStructureController extends BaseController {

    private static final Logger logger = LogManager.getLogger(SalesStructureController.class);
    private SalesStructureService salesStructureService;


    public SalesStructureController(SalesStructureService salesStructureService) {
        this.salesStructureService = salesStructureService;
    }

    @ApiOperation(value = "Get specific sales structure")
    @GetMapping("/{salesStructureId}")
    public ResponseEntity<SalesStructure> getSalesStructure(@PathVariable("salesStructureId") String salesStructureId) {
        SalesStructure salesStructure = new SalesStructure();
        salesStructure.setId(salesStructureId);
        return Ok(salesStructureService.getSalesStructure(salesStructure));
    }

    @ApiOperation(value = "Get full details of a specific sales structure")
    @GetMapping("/{salesStructureId}/_full")
    public ResponseEntity<FullSalesStructureModel> getFullSalesStructure(@PathVariable("salesStructureId") String salesStructureId) {
        SalesStructure salesStructure = new SalesStructure();
        salesStructure.setId(salesStructureId);
        return Ok(salesStructureService.getFullSalesStructure(salesStructure));
    }

    @ApiOperation(value = "Create new sales structure")
    @PostMapping()
    public ResponseEntity<SalesStructure> createSalesStructure(@RequestBody SalesStructure salesStructure) {
        return Created(salesStructureService.createSalesStructure(salesStructure));
    }

    @ApiOperation(value = "Update sales structure partially")
    @PatchMapping()
    public ResponseEntity updateSalesStructurePartially(@RequestBody SalesStructure salesStructure) {
        if (StringUtils.isBlank(salesStructure.getId())) {
            return BadRquest("Missing id of sale structure");
        }
        return salesStructureService.updateSalesStructure(salesStructure)
                ? Ok()
                : NotModified();
    }

    @ApiOperation(value = "Expire sales structure")
    @DeleteMapping()
    public ResponseEntity expireSalesStructure(@RequestBody SalesStructure salesStructure) {
        salesStructureService.expireSalesStructure(salesStructure);
        return Ok();
    }

    @ApiOperation(value = "Expire sales structures in batch", hidden = true)
    @DeleteMapping("/_batch")
    public ResponseEntity expireSalesStructures(@RequestBody Collection<SalesStructure> salesStructures) {
        if (salesStructures.isEmpty()) {
            return BadRquest();
        }

        salesStructureService.expireSalesStructures(salesStructures);
        return Ok();
    }

    @ApiOperation(value = "Get levels within sales structure")
    @PostMapping("/{salesStructureId}/_level-tree/{levelTreeId}")
    public ResponseEntity updateSalesStructureSetUseLevelTree(@PathVariable("salesStructureId") String salesStructureId, @PathVariable("levelTreeId") String levelTreeId) {
        SalesStructure salesStructure = new SalesStructure();
        salesStructure.setId(salesStructureId);
        LevelTree levelTree = new LevelTree();
        levelTree.setId(levelTreeId);

        salesStructureService.updateSalesStructureSetUseLevelTree(salesStructure, levelTree);
        return Ok();
    }

    @ApiOperation(value = "Approve sales structures in batch")
    @PostMapping("/_approval/_batch")
    public ResponseEntity approveSalesStructures(@RequestBody ApprovalModel<SalesStructure> model) {
        salesStructureService.updateApprovalStateOfSalesStructures(model.getCollection(), model.getApprovalState());
        return Ok();
    }

    @ApiOperation(value = "Add positions into specific sales structure")
    @PostMapping("/{salesStructureId}/_positions/_batch")
    public ResponseEntity<Collection<Position>> addPositionsIntoSpecificSalesStructure(@PathVariable("salesStructureId") String salesStructureId, @RequestBody Collection<Position> positions) {
        SalesStructure salesStructure = new SalesStructure();
        salesStructure.setId(salesStructureId);
        return Created(salesStructureService.addPositionsIntoSalesStructure(salesStructure, positions));
    }

    @ApiOperation(value = "Approve positions in batch")
    @PostMapping("/_positions/_approval/_batch")
    public ResponseEntity approvePositions(@RequestBody ApprovalModel<Position> model) {
        if (model.getCollection() == null || model.getCollection().isEmpty()) {
            return BadRquest();
        }

        salesStructureService.updateApprovalStateOfPositions(model.getCollection(), model.getApprovalState());
        return Ok();
    }

    @ApiOperation(value = "Expire positions in batch")
    @DeleteMapping("/_positions/_batch")
    public ResponseEntity expirePositions(@RequestBody Collection<Position> positions) {
        if (positions.isEmpty()) {
            return BadRquest();
        }

        salesStructureService.expirePositions(positions);
        return Ok();
    }

    @ApiOperation(value = "Setup new management relationship between pairs of position in batch")
    @PostMapping("/_positions/_management-relationship/_batch")
    public ResponseEntity addRelationIsManagerOf(@RequestBody SetManagementModel model) {
        if (model.getRelationshipsInfo() == null || model.getRelationshipsInfo().isEmpty()) {
            return BadRquest();
        }

        salesStructureService.addManagementRelationship(model);
        return Created();
    }

    @ApiOperation(value = "Approve relationship between pairs of position in batch")
    @PostMapping("/_positions/_management-relationship/_approve/_batch")
    public ResponseEntity addRelationIsManagerOf(@RequestBody ApprovalModel<IsManagerOf> model) {
        if (model.getCollection() == null || model.getCollection().isEmpty() || model.getApprovalState() == null) {
            return BadRquest();
        }

        salesStructureService.approveManagementRelationships(model.getCollection(), model.getApprovalState());
        return Ok();
    }

    @ApiOperation(value = "Unset management relationship between pairs of position in batch")
    @DeleteMapping("/_positions/_management-relationship/_batch")
    public ResponseEntity expireRelationIsManagerOf(@RequestBody UnsetManagementModel model) {
        if (model.getRelationshipsInfo() == null || model.getRelationshipsInfo().isEmpty()) {
            return BadRquest();
        }

        salesStructureService.expireManagementRelationship(model);
        return Ok();
    }

    @ApiOperation(value = "Unset management relationship using id of IS_MANAGER_OF relationship")
    @DeleteMapping("/_positions/_management-relationship/{relationshipId}")
    public ResponseEntity expireRelationIsManagerOf(@PathVariable("relationshipId") String relationshipId, @RequestBody Date expiryDate) {
        salesStructureService.expireManagementRelationship(relationshipId, expiryDate);
        return Ok();
    }

    @ApiOperation(value = "Get levels within sales structure")
    @GetMapping("/{salesStructureId}/_levels")
    public ResponseEntity<Collection<Level>> getLevelsWithinSalesStructure(@PathVariable("salesStructureId") String salesStructureId) {
        SalesStructure salesStructure = new SalesStructure();
        salesStructure.setId(salesStructureId);
        return Ok(salesStructureService.getLevelsWithinSalesStructure(salesStructure));
    }

    @ApiOperation(value = "Create KPI")
    @PostMapping("/{salesStructureId}/_kpi")
    public ResponseEntity<FullKpiModel> createKpiForSalesStructure(@PathVariable("salesStructureId") String salesStructureId, @RequestBody UpdateKpiModel model) {
        SalesStructure salesStructure = new SalesStructure();
        salesStructure.setId(salesStructureId);
        return Created(salesStructureService.createKpiForSalesStructure(salesStructure, model));
    }

    @ApiOperation(value = "Update KPI target values")
    @PatchMapping("/{salesStructureId}/_kpi")
    public ResponseEntity<FullKpiModel> updateKpi(@PathVariable("salesStructureId") String salesStructureId, @RequestBody UpdateKpiModel model) {
        SalesStructure salesStructure = new SalesStructure();
        salesStructure.setId(salesStructureId);
        return Ok(salesStructureService.updateKpiForSalesStructure(salesStructure, model));
    }

    @ApiOperation(value = "Get specific KPI")
    @GetMapping("/_kpi/{kpiId}")
    public ResponseEntity<FullKpiModel> getKpi(@PathVariable("kpiId") String kpiId) {
        Kpi kpi = new Kpi();
        kpi.setId(kpiId);
        return Ok(salesStructureService.getKpi(kpi));
    }
}
