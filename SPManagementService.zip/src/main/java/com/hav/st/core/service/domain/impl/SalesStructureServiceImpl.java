package com.hav.st.core.service.domain.impl;

import com.hav.st.core.domain.Kpi;
import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import com.hav.st.core.domain.Position;
import com.hav.st.core.domain.SalesStructure;
import com.hav.st.core.domain.relationship.IsManagerOf;
import com.hav.st.core.entities.functional.ApprovalStates;
import com.hav.st.core.entities.neo4j.relationship.ApplyTo;
import com.hav.st.core.entities.neo4j.relationship.Contains;
import com.hav.st.core.entities.neo4j.relationship.HasLevel;
import com.hav.st.core.entities.neo4j.relationship.Incharge;
import com.hav.st.core.exceptions.BadDataSpmsException;
import com.hav.st.core.exceptions.EntityNotFoundSpmsException;
import com.hav.st.core.exceptions.InvalidOperationSpmsException;
import com.hav.st.core.models.FullKpiModel;
import com.hav.st.core.models.FullSalesStructureModel;
import com.hav.st.core.models.SetManagementModel;
import com.hav.st.core.models.UnsetManagementModel;
import com.hav.st.core.models.UpdateKpiModel;
import com.hav.st.core.repository.neo4j.node.EmployeeNeo4jRepository;
import com.hav.st.core.repository.neo4j.node.KpiNeo4jRepository;
import com.hav.st.core.repository.neo4j.node.LevelTreeNeo4jRepository;
import com.hav.st.core.repository.neo4j.node.PositionNeo4jRepository;
import com.hav.st.core.repository.neo4j.node.SalesStructureNeo4jRepository;
import com.hav.st.core.repository.neo4j.relationship.ContainsNeo4jRepository;
import com.hav.st.core.repository.neo4j.relationship.HasLevelNeo4jRepository;
import com.hav.st.core.repository.neo4j.relationship.InchargeNeo4jRepository;
import com.hav.st.core.repository.neo4j.relationship.IsManagerOfNeo4jRepository;
import com.hav.st.core.repository.neo4j.relationship.UseLevelTreeNeo4jRepository;
import com.hav.st.core.service.domain.SalesStructureService;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Transactional
@Service
public class SalesStructureServiceImpl implements SalesStructureService {

    private final SalesStructureNeo4jRepository salesStructureNeo4jRepository;

    private final ContainsNeo4jRepository containsNeo4jRepository;

    private final InchargeNeo4jRepository inchargeNeo4jRepository;

    private final PositionNeo4jRepository positionNeo4jRepository;

    private final EmployeeNeo4jRepository employeeNeo4jRepository;

    private final IsManagerOfNeo4jRepository isManagerOfNeo4jRepository;

    private final HasLevelNeo4jRepository hasLevelNeo4jRepository;

    private final LevelTreeNeo4jRepository levelTreeNeo4jRepository;

    private final UseLevelTreeNeo4jRepository useLevelTreeNeo4jRepository;

    private final KpiNeo4jRepository kpiNeo4jRepository;

    public SalesStructureServiceImpl(SalesStructureNeo4jRepository salesStructureNeo4jRepository, ContainsNeo4jRepository containsNeo4jRepository, InchargeNeo4jRepository inchargeNeo4jRepository, PositionNeo4jRepository positionNeo4jRepository, EmployeeNeo4jRepository employeeNeo4jRepository, IsManagerOfNeo4jRepository isManagerOfNeo4jRepository, HasLevelNeo4jRepository hasLevelNeo4jRepository, LevelTreeNeo4jRepository levelTreeNeo4jRepository, UseLevelTreeNeo4jRepository useLevelTreeNeo4jRepository, KpiNeo4jRepository kpiNeo4jRepository) {
        this.salesStructureNeo4jRepository = salesStructureNeo4jRepository;
        this.containsNeo4jRepository = containsNeo4jRepository;
        this.inchargeNeo4jRepository = inchargeNeo4jRepository;
        this.positionNeo4jRepository = positionNeo4jRepository;
        this.employeeNeo4jRepository = employeeNeo4jRepository;
        this.isManagerOfNeo4jRepository = isManagerOfNeo4jRepository;
        this.hasLevelNeo4jRepository = hasLevelNeo4jRepository;
        this.levelTreeNeo4jRepository = levelTreeNeo4jRepository;
        this.useLevelTreeNeo4jRepository = useLevelTreeNeo4jRepository;
        this.kpiNeo4jRepository = kpiNeo4jRepository;
    }

    @SneakyThrows
    @Override
    public Collection<Position> addPositionsIntoSalesStructure(SalesStructure salesStructure, Collection<Position> positions) {
        if (positions.isEmpty()) {
            throw new BadDataSpmsException("Require at least one position");
        }

        for (Position position : positions) {
            if (position.getFromDate() == null) {
                throw new BadDataSpmsException("Missing fromDate of position");
            }
            if (StringUtils.isBlank(position.getSalesId())) {
                throw new BadDataSpmsException("Missing sales id of position");
            }
            if (StringUtils.isBlank(position.getLevelCode())) {
                throw new BadDataSpmsException("Missing level code of position");
            }
        }

        com.hav.st.core.entities.neo4j.node.SalesStructure nodeSalesStructureEntity = salesStructureNeo4jRepository
                .findById(salesStructure.getId(), 2)
                .orElseThrow(EntityNotFoundSpmsException.of(salesStructure));

        if (nodeSalesStructureEntity.getUseLevelTree() == null) {
            throw new InvalidOperationSpmsException("Sale structure must be associated with a level tree in order to add positions");
        }

        if (CollectionUtils.isEmpty(nodeSalesStructureEntity.getUseLevelTree().getToNode().getAllContains())) {
            throw new InvalidOperationSpmsException("The level tree which is being associated with sale structure does not contains any level");
        }

        List<com.hav.st.core.entities.neo4j.node.Position> createdPositions = new ArrayList<>();

        for (Position position : positions) {
            com.hav.st.core.entities.neo4j.node.Level level = nodeSalesStructureEntity.getUseLevelTree()
                    .getToNode()
                    .getAllContains().stream().filter(x -> position.getLevelCode().equals(x.getToNode().getLevelCode()))
                    .findFirst()
                    .orElseThrow(EntityNotFoundSpmsException.of(com.hav.st.core.entities.neo4j.node.Level.class, "levelCode", position.getLevelCode()))
                    .getToNode();

            com.hav.st.core.entities.neo4j.node.Employee nodeEmployeeEntity = employeeNeo4jRepository
                    .findBySalesId(position.getSalesId())
                    .orElseThrow(EntityNotFoundSpmsException.of(com.hav.st.core.entities.neo4j.node.Employee.class, "salesId", position.getSalesId()));

            //
            com.hav.st.core.entities.neo4j.node.Position nodePositionEntity = new com.hav.st.core.entities.neo4j.node.Position();

            nodePositionEntity.setFromDate(position.getFromDate());
            nodePositionEntity.setToDate(position.getToDate());
            nodePositionEntity.setSalesId(position.getSalesId());

            positionNeo4jRepository.save(nodePositionEntity);
            //

            Incharge relInchargeEntity = new Incharge();

            relInchargeEntity.setFromDate(position.getFromDate());
            relInchargeEntity.setToDate(position.getToDate());

            relInchargeEntity.connects(nodeEmployeeEntity, nodePositionEntity);

            inchargeNeo4jRepository.save(relInchargeEntity);
            //

            Contains relContainsEntity = new Contains();

            relContainsEntity.connects(nodeSalesStructureEntity, nodePositionEntity);

            containsNeo4jRepository.save(relContainsEntity);
            //

            HasLevel relHasLevelEntity = new HasLevel();

            relHasLevelEntity.connects(nodePositionEntity, level);

            hasLevelNeo4jRepository.save(relHasLevelEntity);
            //

            nodePositionEntity.setIncharge(relInchargeEntity);
            nodePositionEntity.setContains(relContainsEntity);
            nodePositionEntity.setHasLevel(relHasLevelEntity);

            positionNeo4jRepository.save(nodePositionEntity);
            //

            nodeEmployeeEntity.addRelIncharge(relInchargeEntity);
            employeeNeo4jRepository.save(nodeEmployeeEntity);
            //

            nodeSalesStructureEntity.addRelContains(relContainsEntity);
            salesStructureNeo4jRepository.save(nodeSalesStructureEntity);

            createdPositions.add(nodePositionEntity);
        }

        return createdPositions.stream().map(x -> Position.fromNeo4jEntity(x)).collect(Collectors.toList());
    }

    @Override
    public void addManagementRelationship(SetManagementModel model) {
        if (model.getRelationshipsInfo().stream().anyMatch(x -> StringUtils.isBlank(x.getFromSalesId()))) {
            throw new BadDataSpmsException("Missing sales id of manager");
        }

        if (model.getRelationshipsInfo().stream().anyMatch(x -> StringUtils.isBlank(x.getToSalesId()))) {
            throw new BadDataSpmsException("Missing sales id of lower level employee");
        }

        if (model.getRelationshipsInfo().stream().anyMatch(x -> x.getEffectiveDate() == null)) {
            throw new BadDataSpmsException("Missing effective date of relationship");
        }

        if (model.getRelationshipsInfo().stream().anyMatch(x -> x.getFromSalesId().equals(x.getToSalesId()))) {
            throw new BadDataSpmsException("Manager and lower level employee can not be the same");
        }

        for (SetManagementModel.RelInfo relInfo : model.getRelationshipsInfo()) {
            com.hav.st.core.entities.neo4j.node.Position fromPosition = positionNeo4jRepository
                    .findBySalesId(relInfo.getFromSalesId())
                    .orElseThrow(EntityNotFoundSpmsException.ofPosition("salesId", relInfo.getFromSalesId()));

            com.hav.st.core.entities.neo4j.node.Position toPosition = positionNeo4jRepository
                    .findBySalesId(relInfo.getToSalesId())
                    .orElseThrow(EntityNotFoundSpmsException.ofPosition("salesId", relInfo.getToSalesId()));

            com.hav.st.core.entities.neo4j.relationship.IsManagerOf relIsManagerOfEntity = new com.hav.st.core.entities.neo4j.relationship.IsManagerOf();
            relIsManagerOfEntity.setExpiryDate(relInfo.getEffectiveDate());

            relIsManagerOfEntity.connects(fromPosition, toPosition);

            fromPosition.addRelManages(relIsManagerOfEntity);
            toPosition.addRelManagedBy(relIsManagerOfEntity);

            isManagerOfNeo4jRepository.save(relIsManagerOfEntity);

            //TODO DELETE THE FOLLOWING 2 LINES
            positionNeo4jRepository.save(fromPosition);
            positionNeo4jRepository.save(toPosition);
        }
    }

    @Override
    public void approveManagementRelationships(Collection<IsManagerOf> relationships, ApprovalStates newState) {
        for (IsManagerOf relationship : relationships) {
            if (StringUtils.isBlank(relationship.getId())) {
                throw new BadDataSpmsException("Missing id of relationship");
            }
        }

        if (newState == null || newState.isPending()) {
            throw new InvalidOperationSpmsException("Can only approve or reject");
        }

        for (IsManagerOf relationship : relationships) {
            com.hav.st.core.entities.neo4j.relationship.IsManagerOf relIsManagerOfEntity = isManagerOfNeo4jRepository
                    .findById(relationship.getId())
                    .orElseThrow(EntityNotFoundSpmsException.of(relationship));

            if (!relIsManagerOfEntity.getApprovalState().isPending()) {
                throw new InvalidOperationSpmsException("Approve/Reject the Pending relationships only");
            }

            relIsManagerOfEntity.setApprovalState(newState);

            isManagerOfNeo4jRepository.save(relIsManagerOfEntity);
        }
    }

    @Override
    public void expireManagementRelationship(UnsetManagementModel model) {
        if (model.getRelationshipsInfo().stream().anyMatch(x -> StringUtils.isBlank(x.getFromSalesId()))) {
            throw new BadDataSpmsException("Missing sales id of manager");
        }

        if (model.getRelationshipsInfo().stream().anyMatch(x -> StringUtils.isBlank(x.getToSalesId()))) {
            throw new BadDataSpmsException("Missing sales id of lower level employee");
        }

        if (model.getRelationshipsInfo().stream().anyMatch(x -> x.getExpiryDate() == null)) {
            throw new BadDataSpmsException("Missing expiry date of relationship");
        }

        for (UnsetManagementModel.RelInfo relInfo : model.getRelationshipsInfo()) {
            com.hav.st.core.entities.neo4j.relationship.IsManagerOf relIsManagerOfEntity = isManagerOfNeo4jRepository
                    .findCurrentlyActivatedRelationship(relInfo.getFromSalesId(), relInfo.getToSalesId())
                    .orElseThrow(EntityNotFoundSpmsException.msg("No active relationship had been found between " + relInfo.getFromSalesId() + " and " + relInfo.getToSalesId()));

            relIsManagerOfEntity.setExpiryDate(relInfo.getExpiryDate());

            isManagerOfNeo4jRepository.save(relIsManagerOfEntity);
        }
    }

    @Override
    public void expireManagementRelationship(String id, Date expiryDate) {
        com.hav.st.core.entities.neo4j.relationship.IsManagerOf relIsManagerOfEntity = isManagerOfNeo4jRepository
                .findById(id, 1)
                .orElseThrow(EntityNotFoundSpmsException.msg("Relationship could not be found"));

        relIsManagerOfEntity.setExpiryDate(expiryDate);

        isManagerOfNeo4jRepository.save(relIsManagerOfEntity);
    }

    @Override
    public SalesStructure getSalesStructure(SalesStructure salesStructure) {
        com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository.findById(salesStructure.getId(), 0)
                .orElseThrow(EntityNotFoundSpmsException.of(salesStructure));

        return SalesStructure.fromNeo4jEntity(salesStructureEntity);
    }

    @Override
    public FullSalesStructureModel getFullSalesStructure(SalesStructure salesStructure) {
        com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository.findById(salesStructure.getId(), -1)
                .orElseThrow(EntityNotFoundSpmsException.of(salesStructure));
        return FullSalesStructureModel.fromEntity(salesStructureEntity);
    }

    @Override
    public SalesStructure createSalesStructure(SalesStructure salesStructure) {
        if (salesStructure.getFromDate() == null) {
            throw new BadDataSpmsException("Missing effective date");
        }

        if (salesStructure.getToDate() != null && !salesStructure.getToDate().after(salesStructure.getFromDate())) {
            throw new BadDataSpmsException("Expiry date must be greater than effective date");
        }

        if (StringUtils.isBlank(salesStructure.getName())) {
            throw new BadDataSpmsException("Missing name");
        }

        com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = SalesStructure.toNeo4jEntity(salesStructure);

        salesStructureNeo4jRepository.save(salesStructureEntity);

        return SalesStructure.fromNeo4jEntity(salesStructureEntity);
    }

    @Override
    public boolean updateSalesStructure(SalesStructure salesStructure) {

        if (salesStructure.getFromDate() != null) {
            throw new InvalidOperationSpmsException("Effective date can not be changed");
        }

        if (salesStructure.getToDate() != null) {
            throw new InvalidOperationSpmsException("Expiry date can not be updated via this method");
        }

        if (salesStructure.getApprovalStates() != null) {
            throw new InvalidOperationSpmsException("Approval state can not be updated via this method");
        }

        boolean anyUpdated = false;

        com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository.findById(salesStructure.getId(), 0)
                .orElseThrow(EntityNotFoundSpmsException.of(salesStructure));

        if (!StringUtils.isBlank(salesStructure.getName()) && !StringUtils.equals(salesStructureEntity.getName(), salesStructure.getName())) {
            salesStructureEntity.setName(salesStructure.getName());
            anyUpdated = true;
        }

        if (!StringUtils.isBlank(salesStructure.getDescription()) && !StringUtils.equals(salesStructureEntity.getDescription(), salesStructure.getDescription())) {
            salesStructureEntity.setDescription(salesStructure.getDescription());
            anyUpdated = true;
        }

        salesStructureNeo4jRepository.save(salesStructureEntity);

        return anyUpdated;
    }

    @Override
    public void expireSalesStructure(SalesStructure salesStructure) {
        List<SalesStructure> salesStructures = new ArrayList<>();
        salesStructures.add(salesStructure);
        expireSalesStructures(salesStructures);
    }

    @Override
    public void expireSalesStructures(Collection<SalesStructure> salesStructures) {
        for (SalesStructure salesStructure : salesStructures) {
            if (StringUtils.isBlank(salesStructure.getId()))
                throw new BadDataSpmsException("Missing sales structure id");
            if (salesStructure.getToDate() == null) {
                throw new BadDataSpmsException("Missing expiry date of sale structure id " + salesStructure.getId());
            }

            com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository.findById(salesStructure.getId(), 0)
                    .orElseThrow(EntityNotFoundSpmsException.of(salesStructure));

            if (salesStructureEntity.getToDate() != null) {
                throw new InvalidOperationSpmsException("Sales structure already has expiry date (id: " + salesStructure.getId() + ")");
            }

            if (!salesStructure.getExpiryDate().after(salesStructureEntity.getFromDate())) {
                throw new InvalidOperationSpmsException("Expiry date must after effective date");
            }

            salesStructureEntity.setExpiryDate(salesStructure.getExpiryDate());

            salesStructureNeo4jRepository.save(salesStructureEntity);
        }
    }

    @Override
    public void updateApprovalStateOfSalesStructures(Collection<SalesStructure> salesStructures, ApprovalStates newState) {
        if (CollectionUtils.isEmpty(salesStructures)) {
            throw new BadDataSpmsException("Missing sales structures");
        }

        if (salesStructures.stream().anyMatch(x -> StringUtils.isBlank(x.getId()))) {
            throw new BadDataSpmsException("Missing sales structure id");
        }

        if (newState == null) {
            throw new BadDataSpmsException("Approval state must not be null");
        }

        if (newState == ApprovalStates.PENDING) {
            throw new BadDataSpmsException("New approval state can not be PENDING");
        }

        for (SalesStructure salesStructure : salesStructures) {
            com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository.findById(salesStructure.getId(), 1)
                    .orElseThrow(EntityNotFoundSpmsException.of(salesStructure));

            if (!salesStructureEntity.IsPending()) {
                throw new InvalidOperationSpmsException("Can only change approval state of PENDING sales structures");
            }

            if (salesStructureEntity.getFromDate() == null && newState.isApproved()) {
                throw new InvalidOperationSpmsException("Sales structure must have effective date in order to be approved");
            }

            if (salesStructureEntity.getUseLevelTree() == null && newState.isApproved()) {
                throw new InvalidOperationSpmsException("Sales structure must have level tree in order to be approved");
            }

            salesStructureEntity.setApprovalState(newState);

            salesStructureNeo4jRepository.save(salesStructureEntity);
        }
    }

    @Override
    public void updateApprovalStateOfPositions(Collection<Position> positions, ApprovalStates newState) {
        if (CollectionUtils.isEmpty(positions))
            throw new BadDataSpmsException("Missing positions");

        if (positions.stream().anyMatch(x -> StringUtils.isBlank(x.getId())))
            throw new BadDataSpmsException("Missing position id");

        if (newState == null)
            throw new BadDataSpmsException("Approval state must not be null");

        if (newState == ApprovalStates.PENDING)
            throw new BadDataSpmsException("New approval state can not be PENDING");

        for (Position position : positions) {
            com.hav.st.core.entities.neo4j.node.Position positionEntity = positionNeo4jRepository.findById(position.getId(), 0)
                    .orElseThrow(EntityNotFoundSpmsException.of(position));

            if (!positionEntity.IsPending())
                throw new InvalidOperationSpmsException("Can only change approval state of PENDING positions");

            if (positionEntity.getHasLevel() == null && newState.isApproved())
                throw new InvalidOperationSpmsException("Position must have associated level in order to be approved");

            positionEntity.setApprovalState(newState);

            positionNeo4jRepository.save(positionEntity);
        }
    }

    @Override
    public void expirePositions(Collection<Position> positions) {
        if (positions.stream().anyMatch(x -> StringUtils.isBlank(x.getId())))
            throw new BadDataSpmsException("Missing position id");

        for (Position position : positions) {
            com.hav.st.core.entities.neo4j.node.Position positionEntity = positionNeo4jRepository.findById(position.getId(), 0)
                    .orElseThrow(EntityNotFoundSpmsException.of(position));

            if (position.getToDate() != null)
                throw new InvalidOperationSpmsException("Position already has expiry date (id: " + position.getId() + ")");

            positionEntity.setExpiryDate(position.getExpiryDate());

            positionNeo4jRepository.save(positionEntity);
        }
    }

    @Override
    public void updateSalesStructureSetUseLevelTree(SalesStructure salesStructure, LevelTree levelTree) {
        com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository.findById(salesStructure.getId())
                .orElseThrow(EntityNotFoundSpmsException.of(salesStructure));
        com.hav.st.core.entities.neo4j.node.LevelTree levelTreeEntity = levelTreeNeo4jRepository.findById(levelTree.getId())
                .orElseThrow(EntityNotFoundSpmsException.of(levelTree));

        if (salesStructureEntity.getUseLevelTree() != null)
            throw new InvalidOperationSpmsException("Sales structure already have level tree");

        if (levelTreeEntity.getUseLevelTree() != null)
            throw new InvalidOperationSpmsException("Level tree already attached to a sales structure");

        com.hav.st.core.entities.neo4j.relationship.UseLevelTree relUseLevelTree = new com.hav.st.core.entities.neo4j.relationship.UseLevelTree();
        relUseLevelTree.connects(salesStructureEntity, levelTreeEntity);

        useLevelTreeNeo4jRepository.save(relUseLevelTree);
    }

    @Override
    public Collection<Level> getLevelsWithinSalesStructure(SalesStructure salesStructure) {
        if (StringUtils.isBlank(salesStructure.getId()))
            throw new BadDataSpmsException("Missing sales structure id");

        com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository.findById(salesStructure.getId())
                .orElseThrow(EntityNotFoundSpmsException.of(salesStructure));

        return salesStructureEntity
                .getUseLevelTree().getToNode()
                .getAllContains().stream()
                .map(x -> Level.fromEntity(x.getToNode()))
                .collect(Collectors.toList());
    }

    @Override
    public FullKpiModel getKpi(Kpi kpi) {
        if (StringUtils.isBlank(kpi.getId()))
            throw new BadDataSpmsException("Missing KPI Id");

        com.hav.st.core.entities.neo4j.node.Kpi kpiEntity = kpiNeo4jRepository.findById(kpi.getId(), 2)
                .orElseThrow(EntityNotFoundSpmsException.of(com.hav.st.core.entities.neo4j.node.Kpi.class, kpi.getId()));

        return FullKpiModel.fromEntity(kpiEntity);
    }

    @Override
    public FullKpiModel createKpiForSalesStructure(SalesStructure salesStructure, UpdateKpiModel model) {

        //validation
        if (StringUtils.isNotBlank(model.getKpiId())) {
            throw new BadDataSpmsException("KPI creation does not accept provided id");
        }

        if (StringUtils.isBlank(model.getName())) {
            throw new BadDataSpmsException("Missing KPI name");
        }

        if (StringUtils.isBlank(model.getType())) {
            throw new BadDataSpmsException("Missing KPI type");
        }

        if (model.getFromDate() == null) {
            throw new BadDataSpmsException("Missing effective date");
        }

        if (model.getToDate() != null && !model.getFromDate().before(model.getToDate())) {
            throw new BadDataSpmsException("Effective date must before expiry date");
        }

        if (CollectionUtils.isEmpty(model.getTargetValues())) {
            throw new BadDataSpmsException("Missing target values");
        }

        com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository
                .findById(salesStructure.getId(), 3)
                .orElseThrow(EntityNotFoundSpmsException.of(salesStructure));

        Collection<String> levelsCode = salesStructureEntity
                .getUseLevelTree().getToNode()
                .getAllContains().stream()
                .map(x -> x.getToNode().getLevelCode())
                .collect(Collectors.toList());

        for (UpdateKpiModel.KpiByLevel targetValue : model.getTargetValues()) {
            if (StringUtils.isBlank(targetValue.getLevelCode())) {
                throw new BadDataSpmsException("Missing level code");
            }
            if (!levelsCode.contains(targetValue.getLevelCode())) {
                throw new EntityNotFoundSpmsException("Level code: " + targetValue.getLevelCode());
            }
        }
        // end of validation

        com.hav.st.core.entities.neo4j.node.Kpi kpi = new com.hav.st.core.entities.neo4j.node.Kpi();
        kpi.setName(model.getName());
        kpi.setDesc(model.getDesc());
        kpi.setType(model.getType());
        kpi.setFromDate(model.getFromDate());
        kpi.setToDate(model.getToDate());

        for (com.hav.st.core.entities.neo4j.node.Level level : salesStructureEntity
                .getUseLevelTree().getToNode()
                .getAllContains().stream()
                .map(x -> x.getToNode()).collect(Collectors.toList())) {

            com.hav.st.core.entities.neo4j.relationship.ApplyTo applyTo = new com.hav.st.core.entities.neo4j.relationship.ApplyTo();

            Optional<UpdateKpiModel.KpiByLevel> kpiByLevel = model.getTargetValues().stream().filter(x -> level.getLevelCode().equals(x.getLevelCode())).findFirst();
            if (kpiByLevel.isPresent()) {
                applyTo.setTarget(kpiByLevel.get().getTarget());
                applyTo.setWeight(kpiByLevel.get().getWeight());
            }

            applyTo.connects(kpi, level);

            kpi.addRelApplyTo(applyTo);
            level.addRelApplyTo(applyTo);
        }

        kpiNeo4jRepository.save(kpi);

        return FullKpiModel.fromEntity(kpi);
    }

    @Override
    public FullKpiModel updateKpiForSalesStructure(SalesStructure salesStructure, UpdateKpiModel model) {
        //validation
        if (StringUtils.isBlank(model.getKpiId())) {
            throw new BadDataSpmsException("Require ID of target KPI");
        }

        com.hav.st.core.entities.neo4j.node.Kpi kpi = kpiNeo4jRepository.findById(model.getKpiId(), 3)
                .orElseThrow(EntityNotFoundSpmsException.of(com.hav.st.core.entities.neo4j.node.Kpi.class, model.getKpiId()));

        if (kpi.getAllApplyTo().size() == 0)
            throw new BadDataSpmsException("Target KPI does not refer to any node");

        com.hav.st.core.entities.neo4j.node.LevelTree levelTree = levelTreeNeo4jRepository.findById(kpi.getAllApplyTo().get(0).getToNode().getContains().getFromNode().getCid(), 2).get();
        if (!levelTree.getUseLevelTree().getFromNode().getCid().equals(salesStructure.getId())) {
            throw new InvalidOperationSpmsException("Target KPI does not connect to level tree of target sales structure");
        }

        List<com.hav.st.core.entities.neo4j.node.Level> levels = kpi.getAllApplyTo().get(0).getToNode().getContains()
                .getFromNode()
                .getAllContains().stream()
                .map(x -> x.getToNode())
                .collect(Collectors.toList());

        Set<String> levelCodes = levels.stream()
                .map(x -> x.getLevelCode())
                .collect(Collectors.toSet());

        if (model.getFromDate() != null && model.getFromDate() != kpi.getFromDate())
            throw new BadDataSpmsException("Cannot change effective date");

        if (model.getToDate() != null && model.getToDate() != kpi.getExpiryDate())
            throw new BadDataSpmsException("Cannot change expiry date via this method");

        if (StringUtils.isNotBlank(model.getName()) && !model.getName().equals(kpi.getName())) {
            kpi.setName(model.getName());
        }

        if (StringUtils.isNotBlank(model.getDesc()) && !model.getDesc().equals(kpi.getDesc())) {
            kpi.setName(model.getDesc());
        }

        if (!CollectionUtils.isEmpty(model.getTargetValues())) {
            for (UpdateKpiModel.KpiByLevel targetValue : model.getTargetValues()) {
                if (StringUtils.isBlank(targetValue.getLevelCode())) {
                    throw new BadDataSpmsException("Missing level code");
                }
                if (!levelCodes.contains(targetValue.getLevelCode())) {
                    throw new EntityNotFoundSpmsException("Level code: " + targetValue.getLevelCode());
                }

                Optional<ApplyTo> relApplyToEntity = kpi.getAllApplyTo().stream().filter(x -> targetValue.getLevelCode().equals(x.getToNode().getLevelCode())).findFirst();
                if (relApplyToEntity.isPresent()) {
                    relApplyToEntity.get().setTarget(targetValue.getTarget());
                    relApplyToEntity.get().setWeight(targetValue.getWeight());
                } else {
                    com.hav.st.core.entities.neo4j.node.Level level = levels.stream().filter(x -> targetValue.getLevelCode().equals(x.getLevelCode())).findFirst().get();

                    com.hav.st.core.entities.neo4j.relationship.ApplyTo applyTo = new com.hav.st.core.entities.neo4j.relationship.ApplyTo();
                    applyTo.setTarget(targetValue.getTarget());
                    applyTo.setWeight(targetValue.getWeight());
                    applyTo.connects(kpi, level);

                    kpi.addRelApplyTo(applyTo);
                    level.addRelApplyTo(applyTo);
                }
            }
        }

        kpiNeo4jRepository.save(kpi);

        return FullKpiModel.fromEntity(kpi);
    }
}
