package com.hav.st.core.domain.neo4j;

public class Branch extends DomainEntity {
    private String branchCode;

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }
}
