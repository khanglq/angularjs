package com.hav.st.core.controller;

import com.hav.st.core.domain.neo4j.Collaborator;
import com.hav.st.core.domain.neo4j.Employee;
import com.hav.st.core.dto.DataRequestDTO;
import com.hav.st.core.dto.MessageRequestDTO;
import com.hav.st.core.dto.MsgUpdateRelationshipDTO;
import com.hav.st.core.dto.RelationshipDTO;
import com.hav.st.core.service.CollaboratorService;
import com.hav.st.core.service.EmployeeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Api(value = "collaborators", tags = {"collaborators"})
@RestController
@RequestMapping("/collaborator")
public class CollaboratorController extends BaseController {


    private static final Logger logger = LogManager.getLogger(CollaboratorController.class);
    private CollaboratorService collaboratorService;


    public CollaboratorController(CollaboratorService collaboratorService) {
        this.collaboratorService = collaboratorService;
    }

    @ApiOperation(value = "Get All Collaborators")
    @PreAuthorize("#oauth2.hasScope('read')")
    @GetMapping("/all")
    public Collection<Collaborator> getAllEmployee(@RequestParam(value = "limit", required = false) Integer limit) {
        return collaboratorService.findAll(limit == null ? 100 : limit);
    }


    @ApiOperation(value = "Create Collaborator")
    @PostMapping("/")
    public ResponseEntity createCollaborator(@ApiParam(value = "Create Collaborator Object", required = true) @RequestBody Collaborator collaborator) {
        if (collaboratorService.findById(collaborator.getId()) != null) {
            return new ResponseEntity<>("Collaborator is existed", HttpStatus.FOUND);
        }
        collaboratorService.save(collaborator);
        return new ResponseEntity<>(collaborator, HttpStatus.OK);
    }

    @ApiOperation(value = "Build Collaborators Tree")
    @PostMapping("/build")
    public ResponseEntity buildCollaboratorTree(@ApiParam(value = "Message Object", required = true) @RequestBody MessageRequestDTO<MsgUpdateRelationshipDTO<RelationshipDTO>> messageRequestDTO) {
        collaboratorService.buildTree(messageRequestDTO);
        return new ResponseEntity<>("Done", HttpStatus.OK);
    }

    @ApiOperation(value = "Create All Collaborators")
    @PostMapping("/all")
    public ResponseEntity createAllCollaborators(@ApiParam(value = "List Collaborators", required = true) @RequestBody DataRequestDTO<Collaborator> collaboratorDataRequestDTO) {
        List<Collaborator> result = new ArrayList<>();
        for (Collaborator collaborator : collaboratorDataRequestDTO.getData()) {
            if (collaboratorService.findById(collaborator.getId()) == null) {
                collaboratorService.save(collaborator);
                result.add(collaborator);
            }
        }
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @ApiOperation(value = "Delete All Collaborators")
    @DeleteMapping(value = "/", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity deleteAll() {
        logger.debug("Delete All Collaborators ");
        collaboratorService.deleteAll();
        return new ResponseEntity<>("Collaborators are deleted", HttpStatus.OK);
    }

    @ApiOperation(value = "Delete Collaborator")
    @DeleteMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity deleteById(@PathVariable(value = "id") String id) {
        logger.debug("Delete Collaborator {} : " + id);
        Collaborator collaborator = collaboratorService.findById(id);
        if (collaborator == null) {
            return new ResponseEntity("Collaborator is not found", HttpStatus.NOT_FOUND);
        }
        collaboratorService.delete(collaborator);
        return new ResponseEntity<>("Collaborator is deleted", HttpStatus.OK);
    }

}
