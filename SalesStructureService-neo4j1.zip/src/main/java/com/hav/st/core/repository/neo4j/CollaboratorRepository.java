package com.hav.st.core.repository.neo4j;

import com.hav.st.core.domain.neo4j.Collaborator;
import com.hav.st.core.domain.neo4j.Employee;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;

import java.util.Collection;

public interface CollaboratorRepository extends Neo4jRepository<Collaborator, String> {

    @Override
    @Query("MATCH (m:Collaborator) RETURN m LIMIT {limit}")
    Collection<Collaborator> findAll(@Param("limit") int limit);

}
