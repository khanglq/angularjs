package com.hav.st.core.domain.neo4j;

public class Customer extends DomainEntity {
    private String customerCode;

}
