package com.hav.st.core.dto;

import java.util.List;

public class MessageRequestDTO<T> {

    public static final String UPDATE_CMD = "UPD";
    public static final String REL_TYPE = "REL";

    private String cmd;
    private String type;
    private List<T> msg;

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<T> getMsg() {
        return msg;
    }

    public void setMsg(List<T> msg) {
        this.msg = msg;
    }


}
