package com.hav.st.core.dto;

import java.util.List;

public class DataRequestDTO<T> {

    private List<T> data;

    public List<T> getData() {
        return data;
    }

    public void setData(List<T> list) {
        this.data = list;
    }
}
