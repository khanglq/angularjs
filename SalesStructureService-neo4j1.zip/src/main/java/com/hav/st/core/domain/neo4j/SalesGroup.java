package com.hav.st.core.domain.neo4j;

public class SalesGroup extends DomainEntity {
}
