package com.hav.st.core.service;

import com.hav.st.core.domain.neo4j.Employee;
import com.hav.st.core.dto.MessageRequestDTO;

import java.util.Collection;


public interface EmployeeService {
    public void save(Employee employee);

    public Employee findByEmpId(String empId);

    public Collection<Employee> findAll(Integer limit);

    public void deleteAll();

    public void delete(Employee employee);

    public void addRel(Employee from, Employee to, String type);

    public void buildTree(MessageRequestDTO messageRequestDTO);
}
