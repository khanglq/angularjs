package com.hav.st.core.service;

import com.hav.st.core.domain.neo4j.Collaborator;
import com.hav.st.core.dto.MessageRequestDTO;

import java.util.Collection;

public interface CollaboratorService {

    public void save(Collaborator collaborator);

    public Collection<Collaborator> findAll(Integer limit);

    public void deleteAll();

    public void delete(Collaborator collaborator);

    public void addRel(Collaborator from, Collaborator to, String type);

    public void buildTree(MessageRequestDTO messageRequestDTO);

    Collaborator findById(String id);
}
