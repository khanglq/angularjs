package com.hav.st.core.controller;

import com.hav.st.core.domain.neo4j.Employee;
import com.hav.st.core.dto.DataRequestDTO;
import com.hav.st.core.dto.MessageRequestDTO;
import com.hav.st.core.dto.MsgUpdateRelationshipDTO;
import com.hav.st.core.dto.RelationshipDTO;
import com.hav.st.core.service.EmployeeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Api(value = "employees", tags = {"employees"})
@RestController
@RequestMapping("/employee")
public class EmployeeController extends BaseController {


    private static final Logger logger = LogManager.getLogger(EmployeeController.class);
    private EmployeeService employeeService;


    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @ApiOperation(value = "Get All Employees")
    @PreAuthorize("#oauth2.hasScope('read')")
    @GetMapping("/all")
    public Collection<Employee> getAllEmployee(@RequestParam(value = "limit", required = false) Integer limit) {
        return employeeService.findAll(limit == null ? 100 : limit);
    }

    @ApiOperation(value = "Get Employee By ID")
    @GetMapping("/{empId}")
    @PreAuthorize("#oauth2.hasScope('read')")
    public ResponseEntity getEmployeeById(@PathVariable("empId") String empId) {
        Employee employee = employeeService.findByEmpId(empId);
        if (employee == null) {
            return new ResponseEntity<>("Employee is not found ", HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(employeeService.findByEmpId(empId), HttpStatus.OK);
    }

    @ApiOperation(value = "Create Employee")
    @PostMapping("/")
    public ResponseEntity createEmployee(@ApiParam(value = "Create Employee Object", required = true) @RequestBody Employee employee) {
        if (employeeService.findByEmpId(employee.getId()) != null) {
            return new ResponseEntity<>("Employee is existed", HttpStatus.FOUND);
        }
        employeeService.save(employee);
        return new ResponseEntity<>(employee, HttpStatus.OK);
    }

    @ApiOperation(value = "Build Employees Tree")
    @PostMapping("/build")
    public ResponseEntity buildEmployeesTree(@ApiParam(value = "Message Object", required = true) @RequestBody MessageRequestDTO<MsgUpdateRelationshipDTO<RelationshipDTO>> messageRequestDTO) {
        employeeService.buildTree(messageRequestDTO);
        return new ResponseEntity<>("Done", HttpStatus.OK);
    }

    @ApiOperation(value = "Create All Employees")
    @PostMapping("/all")
    public ResponseEntity createAllEmployees(@ApiParam(value = "List Employees", required = true) @RequestBody DataRequestDTO<Employee> employees) {
        List<Employee> result = new ArrayList<>();
        for (Employee employee : employees.getData()) {
            if (employeeService.findByEmpId(employee.getId()) == null) {
                employeeService.save(employee);
                result.add(employee);
            }
        }
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @ApiOperation(value = "Delete All Employees")
    @DeleteMapping(value = "/", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity deleteAll() {
        logger.debug("Delete All Employees ");
        employeeService.deleteAll();
        return new ResponseEntity<>("Employees are deleted", HttpStatus.OK);
    }

    @ApiOperation(value = "Delete Employee")
    @DeleteMapping(value = "/{empId}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity deleteById(@PathVariable(value = "empId") String empId) {
        logger.debug("Delete Employee {} : " + empId);
        Employee employee = employeeService.findByEmpId(empId);
        if (employee == null) {
            return new ResponseEntity("Employee is not found", HttpStatus.NOT_FOUND);
        }
        employeeService.delete(employee);
        return new ResponseEntity<>("Employee is deleted", HttpStatus.OK);
    }

}
