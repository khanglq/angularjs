package com.hav.st.core.domain.neo4j;

public class Level extends DomainEntity {

    private int level;
    private String levelCode;

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getLevelCode() {
        return levelCode;
    }

    public void setLevelCode(String levelCode) {
        this.levelCode = levelCode;
    }
}
