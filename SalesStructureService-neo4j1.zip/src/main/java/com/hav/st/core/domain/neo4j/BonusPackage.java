package com.hav.st.core.domain.neo4j;

public class BonusPackage extends DomainEntity {
}
