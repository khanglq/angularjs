package com.hav.st.core.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.Collections;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("Sales Structure System API Document")
                .description("This is for internal only")
                .license("Commercial License ")
                .licenseUrl("")
                .termsOfServiceUrl("")
                .version("api/v1")
                .contact(new Contact("", "", "minhdd@vps.com.vn"))
                .build();
    }

    @Bean
    public Docket customImplementation() {
        return new Docket(DocumentationType.SWAGGER_2).host("localhost:8082").protocols(Collections.singleton("http"))
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.hav.st.core.controller"))
                .build()
                .apiInfo(apiInfo());
    }


}
