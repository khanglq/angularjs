package com.hav.st.core.dto;

import java.util.Date;

public class RelationshipDTO {
    private String effectiveDate;
    private String endDate;
    private String type;
    private String relName;

    public RelationshipDTO() {
    }

    public String getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getRelName() {
        return relName;
    }

    public void setRelName(String relName) {
        this.relName = relName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return relName + " {" +
                "effectiveDate:'" + effectiveDate + '\'' +
                ", endDate:'" + endDate + '\'' +
                ", createdDate:'" + new Date() + '\'' +
                ", type:'" + type + '\'' +
                ", relName:'" + relName + '\'' +
                '}';
    }
}
