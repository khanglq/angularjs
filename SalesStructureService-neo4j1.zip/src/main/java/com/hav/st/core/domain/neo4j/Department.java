package com.hav.st.core.domain.neo4j;

public class Department extends DomainEntity {
    private String deptCode;

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }
}
