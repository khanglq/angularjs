package com.hav.st.core.domain.neo4j;

public class Company extends DomainEntity {

    private String companyCode;

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }
}
