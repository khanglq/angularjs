package com.hav.st.core.dto;

import java.io.Serializable;

public abstract class BaseDTO implements Serializable {

}
