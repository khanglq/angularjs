package com.hav.st.core.service.impl;

import com.hav.st.core.domain.neo4j.Collaborator;
import com.hav.st.core.domain.neo4j.Employee;
import com.hav.st.core.dto.MessageRequestDTO;
import com.hav.st.core.dto.MsgUpdateRelationshipDTO;
import com.hav.st.core.dto.RelationshipDTO;
import com.hav.st.core.repository.neo4j.CollaboratorRepository;
import com.hav.st.core.repository.neo4j.EmployeeRepository;
import com.hav.st.core.service.CollaboratorService;
import com.hav.st.core.service.EmployeeService;
import org.neo4j.ogm.session.Session;
import org.neo4j.ogm.session.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Transactional
@Service
public class CollaboratorServiceImpl implements CollaboratorService {

    @Autowired
    CollaboratorRepository collaboratorRepository;
    private SessionFactory sessionFactory;
    private Session session;

    public CollaboratorServiceImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        this.session = this.sessionFactory.openSession();
    }

    @Override
    public void save(Collaborator collaborator) {
        collaboratorRepository.save(collaborator);
    }

    @Override
    public Collection<Collaborator> findAll(Integer limit) {
        return collaboratorRepository.findAll(limit);
    }

    @Override
    public void deleteAll() {
        collaboratorRepository.deleteAll();
    }

    @Override
    public void delete(Collaborator collaborator) {
        collaboratorRepository.delete(collaborator);
    }

    @Override
    public void addRel(Collaborator from, Collaborator to, String type) {

    }

    @Override
    public void buildTree(MessageRequestDTO messageRequestDTO) {

    }

    @Override
    public Collaborator findById(String id) {
        return null;
    }
}