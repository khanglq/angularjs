package com.hav.st.core.controller;

import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin
public abstract class BaseController {
}
