package com.hav.st.core.service.impl;

import com.hav.st.core.domain.neo4j.Employee;
import com.hav.st.core.dto.MessageRequestDTO;
import com.hav.st.core.dto.MsgUpdateRelationshipDTO;
import com.hav.st.core.dto.RelationshipDTO;
import com.hav.st.core.repository.neo4j.EmployeeRepository;
import com.hav.st.core.service.EmployeeService;
import org.neo4j.ogm.session.Session;
import org.neo4j.ogm.session.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.*;

@Transactional
@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public void save(Employee employee) {
        employeeRepository.save(employee);
    }

    @Override
    public Employee findByEmpId(String empId) {
        return employeeRepository.findByEmpId(empId);
    }

    @Override
    public Collection<Employee> findAll(Integer limit) {
        return employeeRepository.findAll(limit);
    }

    @Override
    public void deleteAll() {
        employeeRepository.deleteAll();
    }

    @Override
    public void delete(Employee employee) {
        employeeRepository.delete(employee);
    }

    @Override
    public void addRel(Employee from, Employee to, String type) {

    }

    @Override
    public void buildTree(MessageRequestDTO messageRequestDTO) {
        if (MessageRequestDTO.UPDATE_CMD.equalsIgnoreCase(messageRequestDTO.getCmd())) {
            if (MessageRequestDTO.REL_TYPE.equalsIgnoreCase(messageRequestDTO.getType())) {
                List<MsgUpdateRelationshipDTO<RelationshipDTO>> msgUpdateRelList = messageRequestDTO.getMsg();
                for (MsgUpdateRelationshipDTO<RelationshipDTO> msgUpdateRel : msgUpdateRelList) {
                    for (RelationshipDTO relationshipDTO : msgUpdateRel.getRel()) {
                        Map<String, Object> params = new HashMap<>(1);
                        params.put("fromEmpId", msgUpdateRel.getFromId());
                        params.put("toEmpId", msgUpdateRel.getToId());
                        StringBuilder cypherSb = new StringBuilder("MATCH (employee:Employee), (manager:Employee) ");
                        cypherSb.append("WHERE employee.empId = $fromEmpId AND manager.empId = $toEmpId ");
                        cypherSb.append("CREATE (employee)-[r:" + relationshipDTO.toString() + "]->(manager) ");
                        cypherSb.append("RETURN employee,manager");
                        Iterable<Employee> result = session.query(Employee.class, cypherSb.toString(), params);
                        System.out.println(result.iterator());
                    }
                }
            }
        }
    }

    private SessionFactory sessionFactory;
    private Session session;

    public EmployeeServiceImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        this.session = this.sessionFactory.openSession();
    }
}