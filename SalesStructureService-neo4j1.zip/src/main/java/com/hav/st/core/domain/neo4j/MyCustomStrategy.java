package com.hav.st.core.domain.neo4j;

import org.neo4j.ogm.id.IdStrategy;

import java.util.UUID;

public class MyCustomStrategy implements IdStrategy {
    @Override
    public Object generateId(Object o) {
        return UUID.randomUUID().toString();
    }
}
