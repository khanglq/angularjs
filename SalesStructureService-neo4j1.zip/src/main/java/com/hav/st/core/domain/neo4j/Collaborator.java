package com.hav.st.core.domain.neo4j;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.id.UuidStrategy;

import java.util.Date;

public class Collaborator extends DomainEntity {
    @Id
    @GeneratedValue(strategy = MyCustomStrategy.class)
    protected String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    private String refIdAuth;
    private String groupCode;
    private String mktId; // WA ID
    private String mktName;
    private String mktIdArrear; // ID WA truy thu HH/PQL
    private int level; // Level of WA/CTV
    private String mktIdParent; // ID cha, QL truc tiep
    private String contractNo; // so HD CTV
    private Date contractDate; // ngay ky HD
    private Date liquidationDate; // ngay thanh ly HD CTV
    private String presentationPerson; // ten nguoi dai dien VPS ky HD CTV
    private String cardId; //CMT ND
    private Date issuedDate; // ngay cap
    private String placeOfIssued; // noi cap
    private String bankNo;// TT TK nhan HH
    private String bankName;
    private String bankBranch;
    private String bankProvince;
    private String payeeName; // ten chu tk
    private String email;
    private String residenceAddress; // dia chi thuong tru
    private String address; // d/c nhan thong tin
    private String phoneNo1;
    private String phoneNo2;
    private String deptCode; // ma phong ban
    private String branchCode; // ma chi nhanh quan ly sales tai VPS
    private String referStaffCode; // thong tin tham chieu dinh danh CTV cua doi tac - ma nv
    private String referRMCode; // ma RM
    private String referPosition; // chuc vu
    private String referIntroBranch; // Ma chi nhanh quan ly theo bank
    private String referOffice; // Dia chi van phong
    private String note; // ghi chu
    private String rejectNode; // li do tu choi duyet
    private int status; // trang thai 0 - chua xu ly , 1 da xu ly - default 1
    private int confirmFlag; // trang thai 0 - cho duyet , 1 da duyet
    private Date confirmDate;
    private String confirmUser;

    public String getRefIdAuth() {
        return refIdAuth;
    }

    public void setRefIdAuth(String refIdAuth) {
        this.refIdAuth = refIdAuth;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getMktId() {
        return mktId;
    }

    public void setMktId(String mktId) {
        this.mktId = mktId;
    }

    public String getMktName() {
        return mktName;
    }

    public void setMktName(String mktName) {
        this.mktName = mktName;
    }

    public String getMktIdArrear() {
        return mktIdArrear;
    }

    public void setMktIdArrear(String mktIdArrear) {
        this.mktIdArrear = mktIdArrear;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getMktIdParent() {
        return mktIdParent;
    }

    public void setMktIdParent(String mktIdParent) {
        this.mktIdParent = mktIdParent;
    }

    public String getContractNo() {
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public Date getContractDate() {
        return contractDate;
    }

    public void setContractDate(Date contractDate) {
        this.contractDate = contractDate;
    }

    public Date getLiquidationDate() {
        return liquidationDate;
    }

    public void setLiquidationDate(Date liquidationDate) {
        this.liquidationDate = liquidationDate;
    }

    public String getPresentationPerson() {
        return presentationPerson;
    }

    public void setPresentationPerson(String presentationPerson) {
        this.presentationPerson = presentationPerson;
    }

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public Date getIssuedDate() {
        return issuedDate;
    }

    public void setIssuedDate(Date issuedDate) {
        this.issuedDate = issuedDate;
    }

    public String getPlaceOfIssued() {
        return placeOfIssued;
    }

    public void setPlaceOfIssued(String placeOfIssued) {
        this.placeOfIssued = placeOfIssued;
    }

    public String getBankNo() {
        return bankNo;
    }

    public void setBankNo(String bankNo) {
        this.bankNo = bankNo;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankBranch() {
        return bankBranch;
    }

    public void setBankBranch(String bankBranch) {
        this.bankBranch = bankBranch;
    }

    public String getBankProvince() {
        return bankProvince;
    }

    public void setBankProvince(String bankProvince) {
        this.bankProvince = bankProvince;
    }

    public String getPayeeName() {
        return payeeName;
    }

    public void setPayeeName(String payeeName) {
        this.payeeName = payeeName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getResidenceAddress() {
        return residenceAddress;
    }

    public void setResidenceAddress(String residenceAddress) {
        this.residenceAddress = residenceAddress;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNo1() {
        return phoneNo1;
    }

    public void setPhoneNo1(String phoneNo1) {
        this.phoneNo1 = phoneNo1;
    }

    public String getPhoneNo2() {
        return phoneNo2;
    }

    public void setPhoneNo2(String phoneNo2) {
        this.phoneNo2 = phoneNo2;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getReferStaffCode() {
        return referStaffCode;
    }

    public void setReferStaffCode(String referStaffCode) {
        this.referStaffCode = referStaffCode;
    }

    public String getReferRMCode() {
        return referRMCode;
    }

    public void setReferRMCode(String referRMCode) {
        this.referRMCode = referRMCode;
    }

    public String getReferPosition() {
        return referPosition;
    }

    public void setReferPosition(String referPosition) {
        this.referPosition = referPosition;
    }

    public String getReferIntroBranch() {
        return referIntroBranch;
    }

    public void setReferIntroBranch(String referIntroBranch) {
        this.referIntroBranch = referIntroBranch;
    }

    public String getReferOffice() {
        return referOffice;
    }

    public void setReferOffice(String referOffice) {
        this.referOffice = referOffice;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getRejectNode() {
        return rejectNode;
    }

    public void setRejectNode(String rejectNode) {
        this.rejectNode = rejectNode;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getConfirmFlag() {
        return confirmFlag;
    }

    public void setConfirmFlag(int confirmFlag) {
        this.confirmFlag = confirmFlag;
    }

    public Date getConfirmDate() {
        return confirmDate;
    }

    public void setConfirmDate(Date confirmDate) {
        this.confirmDate = confirmDate;
    }

    public String getConfirmUser() {
        return confirmUser;
    }

    public void setConfirmUser(String confirmUser) {
        this.confirmUser = confirmUser;
    }
}
