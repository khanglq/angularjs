package com.hav.st.core.component;

import com.hav.st.core.domain.neo4j.DomainEntity;
import org.neo4j.ogm.session.event.Event;
import org.neo4j.ogm.session.event.EventListener;

import java.util.Date;

public class GraphEntityEventListener implements EventListener {
    @Override
    public void onPostSave(Event event) {
        if (event.getObject() instanceof DomainEntity == false) return;
        DomainEntity entity = (DomainEntity) event.getObject();
        if (entity.getId() == null) {
            entity.setCreatedDate(new Date());
        }
        entity.setLastUpdatedDate(new Date());
    }

    @Override
    public void onPreSave(Event event) {
        if (event.getObject() instanceof DomainEntity == false) return;
        DomainEntity entity = (DomainEntity) event.getObject();
        if (entity.getId() != null || (entity.getId() instanceof Long && Long.parseLong(entity.getId().toString()) < 0)) {
            entity.setCreatedDate(new Date());
        }
    }

    @Override
    public void onPreDelete(Event event) {

    }

    @Override
    public void onPostDelete(Event event) {

    }
}
