package com.hav.st.core.domain.neo4j;

public class Product extends DomainEntity {

    private String productCode;


}
