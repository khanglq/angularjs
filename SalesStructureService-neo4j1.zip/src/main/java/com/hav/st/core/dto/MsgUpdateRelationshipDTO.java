package com.hav.st.core.dto;

import java.util.*;

public class MsgUpdateRelationshipDTO<D> {
    public MsgUpdateRelationshipDTO() {
    }

    private String fromId;
    private String toId;
    private List<D> rel;


    public String getFromId() {
        return fromId;
    }

    public void setFromId(String fromId) {
        this.fromId = fromId;
    }

    public String getToId() {
        return toId;
    }

    public void setToId(String toId) {
        this.toId = toId;
    }

    public List<D> getRel() {
        return rel;
    }

    public void setRel(List<D> rel) {
        this.rel = rel;
    }
}
