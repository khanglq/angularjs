package com.hav.st.core.domain.neo4j;

public class PO extends DomainEntity {
    private String poCode;

    public String getPoCode() {
        return poCode;
    }

    public void setPoCode(String poCode) {
        this.poCode = poCode;
    }
}
