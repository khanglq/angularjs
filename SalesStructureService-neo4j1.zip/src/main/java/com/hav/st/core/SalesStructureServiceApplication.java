package com.hav.st.core;

import com.hav.st.core.component.GraphEntityEventListener;
import org.neo4j.ogm.session.SessionFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.PostConstruct;



/**
 * @author Minhdd
 */
@SpringBootApplication
public class SalesStructureServiceApplication {

    private final SessionFactory sessionFactory;

    public SalesStructureServiceApplication(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @PostConstruct
    public void registerEventlistener() {
        sessionFactory.register(new GraphEntityEventListener());
    }

    public static void main(String[] args) {
        SpringApplication.run(SalesStructureServiceApplication.class, args);
    }

}