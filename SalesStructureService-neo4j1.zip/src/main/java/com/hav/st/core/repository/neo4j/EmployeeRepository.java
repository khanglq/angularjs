package com.hav.st.core.repository.neo4j;

import com.hav.st.core.domain.neo4j.Employee;

import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;

import java.util.Collection;

/**
 * @author Minhdd
 */
public interface EmployeeRepository extends Neo4jRepository<Employee, Long> {

    @Query("MATCH (m:Employee) WHERE m.id = {empId} RETURN m ")
    Employee findByEmpId(@Param("empId") String empId);

    @Override
    @Query("MATCH (m:Employee) RETURN m LIMIT {limit}")
    Collection<Employee> findAll(@Param("limit") int limit);

//    @Query("MATCH (employee:Employee), (manager:Employee) WHERE employee.empId = {0} AND manager.empId = {1} \n" +
//            "CREATE (employee)-[:REPORTS_TO]->(manager)\n" +
//            "RETURN employee,manager")
//    void addNewEmployee(String employeeId, String managerId);
//
//    @Query("MATCH (employee:Employee), (manager:Employee) WHERE employee.empId = {0} AND manager.empId = {1} \n" +
//            "CREATE (employee)-[:{2}]->(manager)\n" +
//            "RETURN employee,manager")
//    void updateRel(String employeeId, String managerId, String relName);
}