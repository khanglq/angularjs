package com.hav.st.core.domain.neo4j;

public class BU extends DomainEntity {
    private String buCode;

    public String getBuCode() {
        return buCode;
    }

    public void setBuCode(String buCode) {
        this.buCode = buCode;
    }
}
