package com.hav.st.kpi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KpiServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
