package com.hav.st.kpi.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hav.st.kpi.domain.BaseEntity;
import lombok.Data;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.sql.Date;

@Data
@Entity
@Table(name = "Fact_Product_Revenue")
public class ProductRevenue extends BaseEntity {


    @Column(name = "Amount")
    private Long amount;

    @Column(name = "Month")
    private int month;

    @Column(name = "Quarter")
    private int quarter;

    @Column(name = "Year")
    private int year;

    //    @ManyToMany ???
    @ToString.Exclude
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "Product_Code", referencedColumnName = "Product_Code")
    private ProductCode productCode;

    //    @ManyToMany ???
    @ToString.Exclude
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "FK_Sale_ID")
    private SalePerson salePerson;

    @ToString.Exclude
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "FK_Contract_ID")
    private ContractID contractID;

    @Column(name = "Process_Date")
    private Date processDate;

}
