package com.hav.st.kpi.controller;

import com.hav.st.kpi.component.tranfer.KpiPolicyTransform;
import com.hav.st.kpi.model.request.kpi.KPIPolicySaveRequest;
import com.hav.st.kpi.service.KpiConditionPolicyService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.Data;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Api(value = "kpi", tags = {"KPI"}, description = "KPI service")
@RestController
@Data
public class KpiController {

    private final KpiConditionPolicyService kpiConditionPolicyService;

    private final KpiPolicyTransform kpiPolicyTransform;

    @ApiOperation(value = "Get Employee By ID")
    @PostMapping(value = "/kpi/sale/{saleId}")
    public void getEmployees(@PathVariable String saleId){

    }

    @ApiOperation(value = "Create KPI policy")
    @PostMapping(value = "/kpi/policy/create")
    public void creatKpiPolicy(@RequestBody KPIPolicySaveRequest kpiPolicy){
        kpiConditionPolicyService.save(kpiPolicy, kpiPolicyTransform::transfer);
    }
}
