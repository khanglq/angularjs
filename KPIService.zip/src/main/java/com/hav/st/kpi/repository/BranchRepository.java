package com.hav.st.kpi.repository;

import com.hav.st.kpi.domain.entity.Branch;

public interface BranchRepository extends BaseRepository<Branch, Long> {

}
