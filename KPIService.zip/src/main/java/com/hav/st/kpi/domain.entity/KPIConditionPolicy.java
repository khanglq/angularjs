package com.hav.st.kpi.domain.entity;

import com.hav.st.kpi.domain.BaseEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.sql.Date;

@Data
@Entity
@Table(name = "KPI_Condition_Policy")
public class KPIConditionPolicy extends BaseEntity {

    @Column(name = "Name", nullable = false)
    private String name;

    @Column(name = "Description")
    private String description;

    @Column(name = "Apply_To_Type")
    private String applyToType;

    @Column(name = "Apply_To_ID")
    private String applyToID;

    @Column(name = "Target_Type")
    private String targetType;

    @Column(name = "Target_Value_From")
    private BigDecimal targetValueFrom;

    @Column(name = "Target_Value_To")
    private BigDecimal targetValueTo;

    @Column(name = "Weight")
    private BigDecimal weight;

    @Column(name = "UOM")
        private String UOM;

    @Column(name = "Status")
    private String status;

    @Column(name = "Start_Date")
    private Date startDate;

    @Column(name = "End_Date")
    private Date endDate;
}