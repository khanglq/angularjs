package com.hav.st.kpi.domain.entity;

import com.hav.st.kpi.domain.BaseEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.sql.Date;

@Data
@Entity
@Table(name = "Fact_KPI_Result")
public class KPIResult extends BaseEntity {


    @Column(name = "Process_Date")
    private Date processDate;

    @Column(name = "Total_Balance")
    private Long totalBalance;

    @Column(name = "Target_Current_Period")
    private Long targetCurrentPeriod;

    @Column(name = "Target_Prev_Period")
    private Long targetPrevPeriod;

    @Column(name = "Amount_Prev_Period")
    private Long amountPrevPeriod;

    @Column(name = "Accumulative_Target_Achieved_Pct")
    private Long accumulativeTargetAchievedPct;

    @Column(name = "KPI_PCT")
    private Long kpiPercent;

    @Column(name = "KPI_Result")
    private String kpiResult;

    @Column(name = "No_Of_Run")
    private int noOfRun;

    @Column(name = "Session_ID")
    private Long sessionID;

    @Column(name = "FK_Sale_ID")
    private Long FK_Sale_ID;

    @Column(name = "Note")
    private String note;

    @Column(name = "Attachment")
    private String attachment;
}

