package com.hav.st.kpi.model.request.kpi;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;

@Data
public class KPIPolicySaveRequest {

    private String kpiId;
    private String name;
    private String description;
    private String applyToType;
    private String applyToID;
    private String targetType;
    private BigDecimal targetValueFrom;
    private BigDecimal targetValueTo;
    private BigDecimal weight;
    private String UOM;
    private String status;
    private Date startDate;
    private Date endDate;
    private Collection<KpiByLevel> targetValues;

    @Data
    public class KpiByLevel
    {
//        private int targetValue;
        private String levelCode;
    }
}
