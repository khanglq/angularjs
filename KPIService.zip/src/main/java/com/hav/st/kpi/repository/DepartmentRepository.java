package com.hav.st.kpi.repository;

import com.hav.st.kpi.domain.entity.Department;

public interface DepartmentRepository extends BaseRepository<Department, Long> {

}
