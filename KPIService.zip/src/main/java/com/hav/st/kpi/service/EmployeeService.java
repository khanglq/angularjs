package com.hav.st.kpi.service;

import com.hav.st.kpi.domain.entity.Employee;

public interface EmployeeService extends BaseService<Employee, Long> {
}
