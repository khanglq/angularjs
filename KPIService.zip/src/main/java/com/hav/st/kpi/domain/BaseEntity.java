package com.hav.st.kpi.domain;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;
import java.sql.Date;

/** BaseEntity for all tables entity, with ID and auto-gen strategy, manage Object Version for Optimistic Locking
 */

@MappedSuperclass
@Data
public abstract class BaseEntity {
    @Id
    @Column(name="PK_ID", unique=true, nullable=false)
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    protected Long id;

    @Version
    @Column(name = "version")
    private long version;

    @Column(name = "Created_Date")
    protected Date createdDate;

    @Column(name = "Updated_Date")
    protected Date updatedDate;

    @Column(name = "Created_By")
    protected String createdBy;

    @Column(name = "Updated_By")
    protected String updatedBy;
}
