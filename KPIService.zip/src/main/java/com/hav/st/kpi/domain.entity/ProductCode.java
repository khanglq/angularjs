package com.hav.st.kpi.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hav.st.kpi.domain.BaseEntity;
import lombok.Data;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "Dim_Product_Code")
public class ProductCode extends BaseEntity {

    @Column(name = "Description")
    protected String description;

    @Column(name = "Start_Date")
    protected Date startDate;

    @Column(name = "End_Date")
    protected Date endDate;

    @ToString.Exclude
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "FK_Product_Cat")
    private ProductCategory productCategory;

    @Column(name = "Product_Code", nullable = false, unique = true)
    private String productCode;

    @OneToOne(fetch = FetchType.LAZY, mappedBy = "productCode")
    private DayConvention dayConvention;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "productCode")
    private List<SalePersonCustomer> salePersonCustomerList = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "productCode")
    private List<ProductRevenue> productRevenueList = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "productCode")
    private List<ProductRevenueNET> productRevenueNETList = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "productCode")
    private List<KPIProductResult> kpiProductResultList = new ArrayList<>();
}
