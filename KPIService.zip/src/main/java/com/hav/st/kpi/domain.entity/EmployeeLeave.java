package com.hav.st.kpi.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hav.st.kpi.domain.BaseEntity;
import lombok.Data;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.sql.Date;

@Data
@Entity
@Table(name = "Dim_Employee_Leave")
public class EmployeeLeave extends BaseEntity {

    @ToString.Exclude
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "FK_Employee_ID")
    private Employee employee;

    @Column(name = "Leave_Type")
    private String leaveType;

    @Column(name = "Note")
    private String note;

    @Column(name = "From_Date")
    private Date fromDate;

    @Column(name = "To_Date")
    private Date toDate;
}
