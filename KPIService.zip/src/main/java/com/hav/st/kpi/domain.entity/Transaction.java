package com.hav.st.kpi.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hav.st.kpi.domain.BaseEntity;
import lombok.Data;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.sql.Date;

@Data
@Entity
@Table(name = "Fact_Transaction")
public class Transaction extends BaseEntity {

    @ToString.Exclude
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "FK_Contract_ID")
    private ContractID contractID;

//    @ManyToMany ???
    private String Product_Code;

    //    @ManyToMany ???
    @ToString.Exclude
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "FK_Sale_ID")
    private SalePerson salePerson;

    @ToString.Exclude
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "FK_Cust_ID")
    private CustID custID;

    @Column(name = "Product_Type")
    private String productType;

    @Column(name = "Product_Sub_Type")
    private String productSubType;

    @Column(name = "Transaction_Type")
    private String transactionType;

    @Column(name = "Deal_Date")
    private Date dealDate;

    @Column(name = "Value_Date")
    private Date valueDate;

    @Column(name = "Expire_Date")
    private Date expireDate;

    @Column(name = "Maturity_Date")
    private Date maturityDate;

    @Column(name = "Payment_Date")
    private String paymentDate;

    @Column(name = "Amount")
    private Long amount;

    @Column(name = "Quantity")
    private int quantity;

    @Column(name = "Indiv_Org_Flag")
    private Long indivOrgFlag;

    @Column(name = "Day_Count_Convention")
    private String dayCountConvention;

    @Column(name = "Contract_ID_Ref")
    private Long contractIdRef;

}