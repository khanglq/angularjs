package com.hav.st.kpi.service;

import com.hav.st.kpi.model.response.BaseResponse;
import org.springframework.data.jpa.domain.Specification;

import java.io.Serializable;
import java.util.List;
import java.util.function.Function;

public interface BaseService<T, ID extends Serializable> {
    List<T> findAll();

    T findById(ID id);

    <P> P getId(ID id, Function<T, P> transfer);

    <Q> void save(Q q, Function<Q, T> transfer);

    <Q> void update(ID id, Q q, Function<Q, T> transfer);

    void delete(T t);

    void delete(ID id);

    <P> BaseResponse<P> getByCondition(Specification<T> filter, Function<T, P> transfer);
}
