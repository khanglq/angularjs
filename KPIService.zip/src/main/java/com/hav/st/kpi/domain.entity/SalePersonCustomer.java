package com.hav.st.kpi.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hav.st.kpi.domain.BaseEntity;
import lombok.Data;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.sql.Date;

@Data
@Entity
@Table(name = "Dim_Sale_Person_Customer")
public class SalePersonCustomer extends BaseEntity {

    @ToString.Exclude
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "FK_Sale_ID")
    private SalePerson salePerson;

    @ToString.Exclude
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "FK_Cust_ID")
    private CustID custID;

    @ToString.Exclude
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "Product_Code", referencedColumnName = "Product_Code")
//    @JoinColumn(name = "Product_Code", insertable = false, updatable = false)
    private ProductCode productCode;


//    @Column(name = "Product_Code", nullable = false, unique = true)
//    private String productCode;

    @Column(name = "Start_Date")
    private Date startDate;

    @Column(name = "End_Date")
    private Date endDate;
}
