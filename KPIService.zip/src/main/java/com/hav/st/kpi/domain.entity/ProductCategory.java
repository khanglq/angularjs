package com.hav.st.kpi.domain.entity;

import com.hav.st.kpi.domain.BaseEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.sql.Date;

@Data
@Entity
@Table(name = "Dim_Product_Category")
public class ProductCategory extends BaseEntity {

    @Column(name = "Description")
    protected String description;

    @Column(name = "Start_Date")
    protected Date startDate;

    @Column(name = "End_Date")
    protected Date endDate;

    @Column(name = "Name", nullable = false)
    private String name;
}
