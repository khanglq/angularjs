package com.hav.st.kpi.core;

public interface KPIManagement {

}
