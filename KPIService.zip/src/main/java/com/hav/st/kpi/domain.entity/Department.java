package com.hav.st.kpi.domain.entity;

import com.hav.st.kpi.domain.BaseEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "Dim_Department")
public class Department extends BaseEntity {

    @Column(name = "Name", nullable = false)
    private String name;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "department")
    private List<Employee> employeeList = new ArrayList<>();

    @Column(name = "Description")
    protected String description;

    @Column(name = "Start_Date")
    protected Date startDate;

    @Column(name = "End_Date")
    protected Date endDate;
}
