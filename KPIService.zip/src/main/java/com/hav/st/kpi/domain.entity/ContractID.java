package com.hav.st.kpi.domain.entity;

import com.hav.st.kpi.domain.BaseEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "Dim_Contract_ID")
public class ContractID extends BaseEntity {

    @Column(name = "Contract_No", nullable = false)
    private String contractNo;

    @Column(name = "System_Code", nullable = false)
    private String systemCode;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "contractID")
    private List<Transaction> transactionList = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "contractID")
    private List<ProductRevenue> productRevenueList = new ArrayList<>();
}
