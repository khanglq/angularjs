package com.hav.st.kpi.model.response.employee;

import lombok.Data;

@Data
public class EmployeeResponse {
    private long id;
    private String name;
}
