package com.hav.st.kpi.core.business;

import com.hav.st.kpi.config.saservices.Constants;
import com.hav.st.kpi.core.KPIManagement;
import com.hav.st.kpi.model.request.kpi.KPIData;
import com.hav.st.kpi.model.request.kpi.KPIPolicySaveRequest;
import com.hav.st.kpi.model.response.kpi.KPIDataSaleID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class KPIBusinessImpl implements KPIManagement {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    public void assignKPI(String ssId, KPIData kpiData) {
        Map<String, String> params = new HashMap<>();
        params.put("ssid", ssId);

        RestTemplate restTemplate = new RestTemplate();
        URI uri = UriComponentsBuilder.fromUriString(Constants.SPMService.Update_KPI_URL)
                    .buildAndExpand(params)
                    .toUri();

        String resp = restTemplate.postForObject(uri, kpiData, String.class);
        logger.info("result = " + resp);
    }


    /**
     * lấy thông tin KPI cho SaleID
     * @param SaleID
     * @param ssId: Sale-Structure-ID
     * @return
     */
    public KPIDataSaleID getKpiTarget(String SaleID, String ssId) {
        Map<String, String> params = new HashMap<>();
        params.put("ssid", ssId);

        RestTemplate restTemplate = new RestTemplate();
        URI uri = UriComponentsBuilder.fromUriString(Constants.SPMService.Update_KPI_URL)
                .buildAndExpand(params)
                .toUri();
        logger.info("uri = " + uri.toString());

        //temp data
        KPIPolicySaveRequest kpiPolicySaveRequest = new KPIPolicySaveRequest();
        kpiPolicySaveRequest.setKpiId("2342");
        kpiPolicySaveRequest.setName("KPI lqk");
        kpiPolicySaveRequest.setApplyToType("NY_KPI");
        kpiPolicySaveRequest.setStartDate(new Date());
        kpiPolicySaveRequest.setEndDate(new Date());
        KPIPolicySaveRequest.KpiByLevel kpiByLevel1 = kpiPolicySaveRequest.new KpiByLevel();
        kpiByLevel1.setLevelCode("GĐV");
        KPIPolicySaveRequest.KpiByLevel kpiByLevel2 = kpiPolicySaveRequest.new KpiByLevel();
        kpiByLevel2.setLevelCode("GĐM");
        Collection<KPIPolicySaveRequest.KpiByLevel> kpiByLevels = new ArrayList<>();
        kpiByLevels.add(kpiByLevel1);
        kpiByLevels.add(kpiByLevel2);
        kpiPolicySaveRequest.setTargetValues(kpiByLevels);

        String resp = restTemplate.postForObject(uri, kpiPolicySaveRequest, String.class);
        logger.info("result = " + resp);

        return null;

    }


}
