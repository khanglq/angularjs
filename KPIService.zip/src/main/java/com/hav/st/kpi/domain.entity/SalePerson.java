package com.hav.st.kpi.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hav.st.kpi.domain.BaseEntity;
import lombok.Data;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "Dim_Sale_Person")
public class SalePerson extends BaseEntity {

    @Column(name = "Sale_ID", nullable = false)
    private String saleID;

    @ToString.Exclude
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "FK_Employee_ID")
    private Employee employee;

    @Column(name = "System_Code")
    private String systemCode;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "salePerson")
    private List<Transaction> transactionList = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "salePerson")
    private List<ProductRevenueNET> productRevenueNETList = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "salePerson")
    private List<SalePersonCustomer> salePersonCustomerList = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "salePerson")
    private List<ProductRevenue> productRevenueList = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "salePerson")
    private List<KPIProductResult> kpiProductResultList = new ArrayList<>();
}
