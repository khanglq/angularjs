package com.hav.st.kpi.exception;

public class ObjectNotFound extends RuntimeException{

    private String message;

    public ObjectNotFound(String message) {
        super(message);
    }
}
