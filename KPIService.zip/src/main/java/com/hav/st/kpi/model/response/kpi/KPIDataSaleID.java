package com.hav.st.kpi.model.response.kpi;

import lombok.Data;

import java.util.Date;

@Data
public class KPIDataSaleID {
    private String kpiId;
    private String name;
    private String type;
    private Date fromDate;
    private Date toDate;
}
