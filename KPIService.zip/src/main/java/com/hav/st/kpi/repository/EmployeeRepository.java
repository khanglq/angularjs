package com.hav.st.kpi.repository;

import com.hav.st.kpi.domain.entity.Employee;

public interface EmployeeRepository extends BaseRepository<Employee, Long> {

}
