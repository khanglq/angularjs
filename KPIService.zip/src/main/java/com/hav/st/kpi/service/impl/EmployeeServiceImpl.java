package com.hav.st.kpi.service.impl;

import com.hav.st.kpi.domain.entity.Employee;
import com.hav.st.kpi.repository.EmployeeRepository;
import com.hav.st.kpi.service.EmployeeService;
import org.springframework.stereotype.Service;

import java.util.function.Function;

@Service
public class EmployeeServiceImpl extends BaseServiceImpl<Employee, Long> implements EmployeeService {
    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
        super(employeeRepository);
    }

    @Override
    public <Q> void update(Long id, Q q, Function<Q, Employee> transfer) {
        Employee employee = findById(id);
        Employee employeeReq = transfer.apply(q);
        employeeReq.setVersion(employee.getVersion());
        super.save(employeeReq);

    }
}
