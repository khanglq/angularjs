package com.hav.st.kpi.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hav.st.kpi.domain.BaseEntity;
import lombok.Data;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "Dim_Employee")
public class Employee extends BaseEntity {

    @Column(name = "EmpID")
    private String empID;

    @Column(name = "Name")
    private String name;

    @Column(name = "Address")
    private String address;

    @Column(name = "Phone_No")
    private String phoneNo;

    @Column(name = "Probation_Date")
    private Date probationDate;

    @Column(name = "Sign_Contract_Date")
    private Date signContractDate;

    @Column(name = "Exit_Date")
    private Date exitDate;

    @ToString.Exclude
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "FK_Branch_ID")
    private Branch branch;

    @ToString.Exclude
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "FK_Department_ID")
    private Department department;

    @ToString.Exclude
    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "employee")
    private List<EmployeeLeave> employeeLeaveList = new ArrayList<>();

    @ToString.Exclude
    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "employee")
    private List<SalePerson> salePersonList = new ArrayList<>();
}
