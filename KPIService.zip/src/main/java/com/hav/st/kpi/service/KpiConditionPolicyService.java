package com.hav.st.kpi.service;

import com.hav.st.kpi.domain.entity.KPIConditionPolicy;

public interface KpiConditionPolicyService extends BaseService<KPIConditionPolicy, Long> {
}
