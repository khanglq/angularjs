package com.hav.st.kpi.domain.entity;

import com.hav.st.kpi.domain.BaseEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.sql.Date;


@Data
@Entity
@Table(name = "Dim_Day_Convention")
public class DayConvention extends BaseEntity {

    @OneToOne
    @JoinColumn(name = "Product_Code", referencedColumnName = "Product_Code")
    private ProductCode productCode;

    @Column(name = "Code")
    private String code;

    @Column(name = "Description")
    protected String description;

    @Column(name = "Start_Date")
    protected Date startDate;

    @Column(name = "End_Date")
    protected Date endDate;
}
