package com.hav.st.kpi.service.impl;

import com.hav.st.kpi.exception.ObjectNotFound;
import com.hav.st.kpi.model.response.BaseResponse;
import com.hav.st.kpi.repository.BaseRepository;
import com.hav.st.kpi.service.BaseService;
import org.springframework.data.jpa.domain.Specification;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

public class BaseServiceImpl<T, ID extends Serializable> implements BaseService<T, ID> {

    private Class<T> tClass;
    private BaseRepository baseRepository;

    public BaseServiceImpl(BaseRepository baseRepository){
        this.baseRepository = baseRepository;
        tClass = (Class<T>) ((ParameterizedType)getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }

    private String getClassName(){
        return tClass.getSimpleName();
    }

    @Override
    public List<T> findAll() {
        return baseRepository.findAll();
    }

    @Override
    public T findById(ID id) {
        Optional<T> object  = baseRepository.findById(id);
        object.orElseThrow(()-> new ObjectNotFound("Object not found with " + getClassName()));
        return object.get();
    }

    @Override
    public <P> P getId(ID id, Function<T, P> transfer) {
        return transfer.apply(findById(id));
    }

    @Override
    public <Q> void save(Q q, Function<Q, T> transfer) {
        baseRepository.save(transfer.apply(q));
    }

    public void save(T t) {
        baseRepository.save(t);
    }

    @Override
    public <Q> void update(ID id, Q q, Function<Q, T> transfer) {
//        T object = findById(id);
//        tranObj = transfer.apply;
//        tranObj.update(object);
//        baseRepository.save(tranObj);
    }

    @Override
    public void delete(T t) {
        baseRepository.delete(t);
    }

    @Override
    public void delete(ID id) {
        baseRepository.delete(findById(id));
    }

    @Override
    public <P> BaseResponse<P> getByCondition(Specification<T> filter, Function<T, P> transfer) {
        List<T> data = baseRepository.findAll(filter);
        long total = baseRepository.count(filter);
        BaseResponse<P> baseResponse = new BaseResponse<>();
        List<P> dataResponse = data.stream().map(t->transfer.apply(t)).collect(Collectors.toList());
        baseResponse.setData(dataResponse);
        baseResponse.setTotalItem(total);

        return baseResponse;
    }
}
