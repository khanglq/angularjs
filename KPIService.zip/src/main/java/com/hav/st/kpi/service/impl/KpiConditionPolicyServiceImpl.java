package com.hav.st.kpi.service.impl;

import com.hav.st.kpi.domain.entity.KPIConditionPolicy;
import com.hav.st.kpi.repository.KpiConditionPolicyRepository;
import com.hav.st.kpi.service.KpiConditionPolicyService;
import org.springframework.stereotype.Service;

@Service
public class KpiConditionPolicyServiceImpl extends BaseServiceImpl<KPIConditionPolicy, Long> implements KpiConditionPolicyService {
    public KpiConditionPolicyServiceImpl(KpiConditionPolicyRepository kpiConditionPolicyRepository) {
        super(kpiConditionPolicyRepository);
    }

}
