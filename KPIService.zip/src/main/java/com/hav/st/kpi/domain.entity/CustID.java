package com.hav.st.kpi.domain.entity;

import com.hav.st.kpi.domain.BaseEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "Dim_Cust_ID")
public class CustID extends BaseEntity {

    @Column(name = "Cust_No", nullable = false)
    private String Cust_No;

    @Column(name = "System_Code", nullable = false)
    private String systemCode;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "custID")
    private List<Transaction> transactionList = new ArrayList<>();
}