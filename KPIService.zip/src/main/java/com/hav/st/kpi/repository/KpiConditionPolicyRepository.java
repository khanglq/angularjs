package com.hav.st.kpi.repository;

import com.hav.st.kpi.domain.entity.KPIConditionPolicy;

public interface KpiConditionPolicyRepository extends BaseRepository<KPIConditionPolicy, Long> {

}
