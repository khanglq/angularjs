package com.hav.st.kpi.repository.specification;

import com.hav.st.kpi.domain.entity.Employee;
import com.hav.st.kpi.model.request.employee.EmployeeFilterRequest;
import org.springframework.data.jpa.domain.Specification;

public class EmployeeSpecification {

    public static Specification<Employee> filter(EmployeeFilterRequest filter){
        return Specification.where(withName(filter.getName()));
    }


    private static Specification<Employee> withName(String name){
        if (name == null || name.isEmpty()) return null;

        return (root, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(root.get("name"), name);
    }

}
