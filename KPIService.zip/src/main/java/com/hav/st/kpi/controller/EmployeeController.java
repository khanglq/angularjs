package com.hav.st.kpi.controller;

import com.hav.st.kpi.component.tranfer.EmployeeTransform;
import com.hav.st.kpi.domain.entity.Employee;
import com.hav.st.kpi.model.request.employee.EmployeeFilterRequest;
import com.hav.st.kpi.model.request.employee.EmployeeSaveRequest;
import com.hav.st.kpi.model.response.BaseResponse;
import com.hav.st.kpi.model.response.employee.EmployeeResponse;
import com.hav.st.kpi.repository.specification.EmployeeSpecification;
import com.hav.st.kpi.service.EmployeeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@Api(value = "employee", tags = {"employee"}, description = "Employees management service")
@RestController
@Data
public class EmployeeController {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private final EmployeeService employeeService;

    private final EmployeeTransform employeeTransform;

    @ApiOperation(value = "Get Employee By ID")
    @GetMapping(value = "/kpi/employee")
    public Employee getEmployees(@RequestParam Long id){

        return employeeService.findById(id);
    }

    @GetMapping(value = "/kpi/employees")
    public BaseResponse<EmployeeResponse> getEmployees(@ModelAttribute EmployeeFilterRequest employeeFilterRequest){

        return employeeService.getByCondition(EmployeeSpecification.filter(employeeFilterRequest), employeeTransform::toResponse );
    }

    @PostMapping("/creaate-employee")
    public void create(@RequestBody EmployeeSaveRequest employee){
        employeeService.save(employee, employeeTransform::transfer);
    }

    @PostMapping("/update-employee")
    public void update(@RequestBody EmployeeSaveRequest employee){
        employeeService.update(employee.getId(), employee, employeeTransform::transfer);
    }

}
