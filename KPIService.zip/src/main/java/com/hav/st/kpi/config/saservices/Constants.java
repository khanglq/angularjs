package com.hav.st.kpi.config.saservices;

public class Constants {

    public class SPMService {
        public static final String Update_KPI_URL = "http://10.32.37.79:8082/sales-structure/{ssid}/_kpi";

        public static final String Get_KPI_URL = "http://10.32.37.79:8082/sales-structure/_kpi/{ssid}";
    }

    public class KPIService {
        public static final String API_URL = "http://localhost:8080/kpi/employee";
    }
}
