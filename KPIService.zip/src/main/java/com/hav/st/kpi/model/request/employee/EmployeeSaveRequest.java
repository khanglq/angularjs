package com.hav.st.kpi.model.request.employee;

import lombok.Data;

@Data
public class EmployeeSaveRequest {
    private Long id;
    private String empID;
    private String name;
    private String address;
    private String phoneNo;
    private String probationDate;

}
