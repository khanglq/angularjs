package com.hav.st.kpi.model.response;

import lombok.Data;

import java.util.List;

@Data
public class BaseResponse<T> {
    private long totalItem;
    private List<T> data;


}
