package com.hav.st.kpi.component.tranfer;

import com.hav.st.kpi.domain.entity.KPIConditionPolicy;
import com.hav.st.kpi.model.request.kpi.KPIPolicySaveRequest;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

@Component
public class KpiPolicyTransform {

    public KPIConditionPolicy transfer(KPIPolicySaveRequest kpiPolicySaveRequest){
        KPIConditionPolicy kpiConditionPolicy = new KPIConditionPolicy();
        BeanUtils.copyProperties(kpiPolicySaveRequest, kpiConditionPolicy);

        return kpiConditionPolicy;
    }

}
