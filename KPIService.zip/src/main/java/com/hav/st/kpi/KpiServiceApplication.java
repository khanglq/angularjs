package com.hav.st.kpi;

import com.hav.st.kpi.config.saservices.Constants;
import com.hav.st.kpi.domain.entity.Employee;
import com.hav.st.kpi.model.request.kpi.KPIPolicySaveRequest;
import com.hav.st.kpi.repository.BranchRepository;
import com.hav.st.kpi.repository.DepartmentRepository;
import com.hav.st.kpi.repository.EmployeeRepository;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
@Data
public class KpiServiceApplication implements CommandLineRunner {

	private Logger logger = LoggerFactory.getLogger(this.getClass());


	private final BranchRepository branchRepository;
	private final EmployeeRepository employeeRepository;
	private final DepartmentRepository departmentRepository;

	public static void main(String[] args) {
		SpringApplication.run(KpiServiceApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		logger.debug("Demo app...");
		logger.info("Khanglq test db: All branch 1 -> {}", branchRepository.findAll());

//		//test Branch model
//		Branch branch = branchRepository.findAll().get(0);
//		logger.info("branch.getDesc = " + branch.getDescription());
//		logger.info("employeeList 1 = " + branch.getEmployeeList().get(0).getName());
//		logger.info("employeeList 2 = " + branch.getEmployeeList().get(1).getName());
//
//		// test Employee model
//		Employee employee1 = employeeRepository.findById(13L).get();
//		logger.info("employee.getName = " + employee1.getName());
//		logger.info("branch.getName = " + employee1.getBranch().getName());
//		logger.info("branch.getDepartment = " + employee1.getDepartment().getName());
//
//		Employee employee2 = employeeRepository.findAll().get(1);
//		logger.info("employee.getName = " + employee2.getName());
//		logger.info("branch.getName = " + employee2.getBranch().getName());
//		logger.info("branch.getDepartment = " + employee1.getDepartment().getName());

		getEmployeesFromRest();
//		assignKPI("304e3e66-4a5d-4696-9bca-b7e6c4325c0e");
	}

	public void getEmployeesFromRest() {

		RestTemplate restTemplate = new RestTemplate();
		Employee employee = restTemplate.getForObject(Constants.KPIService.API_URL + "?id=13", Employee.class);
//		logger.info("result = " + restTemplate.getForObject(Constants.KPIService.API_URL + "?id=13", Employee.class));
		logger.info("result = " + employee);
	}

	public void assignKPI(String ssId) {
		Map<String, String> params = new HashMap<>();
		params.put("ssid", ssId);

		RestTemplate restTemplate = new RestTemplate();
		URI uri = UriComponentsBuilder.fromUriString(Constants.SPMService.Update_KPI_URL)
				.buildAndExpand(params)
				.toUri();
//				.queryParam("id", 13)
//				.build()
//				.toUri();
		logger.info("uri = " + uri.toString());

		//temp data
		KPIPolicySaveRequest kpiPolicySaveRequest = new KPIPolicySaveRequest();
		kpiPolicySaveRequest.setKpiId("2342");
		kpiPolicySaveRequest.setName("KPI lqk");
		kpiPolicySaveRequest.setApplyToType("NY_KPI");
		kpiPolicySaveRequest.setStartDate(new Date());
		kpiPolicySaveRequest.setEndDate(new Date());
		KPIPolicySaveRequest.KpiByLevel kpiByLevel1 = kpiPolicySaveRequest.new KpiByLevel();
		kpiByLevel1.setLevelCode("GĐV");
		KPIPolicySaveRequest.KpiByLevel kpiByLevel2 = kpiPolicySaveRequest.new KpiByLevel();
		kpiByLevel2.setLevelCode("GĐM");
		Collection<KPIPolicySaveRequest.KpiByLevel> kpiByLevels = new ArrayList<>();
		kpiByLevels.add(kpiByLevel1);
		kpiByLevels.add(kpiByLevel2);
		kpiPolicySaveRequest.setTargetValues(kpiByLevels);

		String resp = restTemplate.postForObject(uri, kpiPolicySaveRequest, String.class);
		logger.info("result = " + resp);
	}
}
