package com.hav.st.kpi.core.calculator;

import com.hav.st.kpi.core.KPIManagement;

public class KPICalculator implements KPIManagement {

    /**
     * Tính KPI theo kỳ
     * @param processDate kỳ tính KPI
     */
    public void calculateKpiByPeriod(String processDate) {

    }

    /**
     * Tính KPI theo Emmployee
     * @param processDate
     * @param saleID
     */
    public void calculateKpiByEmployee(String processDate, String saleID) {

    }

    /**
     * Số ngày thực tế để tính KPI, check cho TVĐT trước
     * @return
     */
    public int countKPIDate() {
        return 0;
    }
}
