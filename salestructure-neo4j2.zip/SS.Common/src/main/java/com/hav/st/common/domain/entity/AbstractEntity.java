package com.hav.st.common.domain.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hav.st.common.utils.DateUtil;
import lombok.Data;

@MappedSuperclass
@Data
public class AbstractEntity implements Serializable, Cloneable {

    private static final long serialVersionUID = -7625977911228503510L;

    @Column(name = "created_datetime")
    @JsonIgnore
    private Date createdDateTime;

    @Column(name = "created_by")
    @JsonIgnore
    private String createdBy;

    @Column(name = "updated_datetime")
    @JsonIgnore
    private Date updatedDateTime;

    @Column(name = "updated_by")
    @JsonIgnore
    private String updatedBy;

    @PrePersist
    public void prePersist() {
        this.setCreatedDateTime(DateUtil.nowUtc());
        this.setUpdatedDateTime(DateUtil.nowUtc());
    }

    @PreUpdate
    public void preUpdate() {
        this.setUpdatedDateTime(DateUtil.nowUtc());
    }

    @Column(name = "object_version")
    @Version
    @JsonIgnore
    private Long objectVersion;
}