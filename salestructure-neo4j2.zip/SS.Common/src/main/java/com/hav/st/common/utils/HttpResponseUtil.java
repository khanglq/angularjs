package com.hav.st.common.utils;

import com.hav.st.common.dto.ErrorMessage;
import com.hav.st.common.dto.ResponseMessageOnFailure;
import com.hav.st.common.dto.ResponseMessageOnSuccess;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class HttpResponseUtil {
    public static <T> ResponseEntity<ResponseMessageOnSuccess<T>> Success(T data, HttpStatus httpStatus) {
        return new ResponseEntity<>(new ResponseMessageOnSuccess<>(data, httpStatus), httpStatus);
    }

    public static ResponseEntity<ResponseMessageOnFailure> Error(ErrorMessage errorMessage, HttpStatus httpStatus) {
        return Error(new ResponseMessageOnFailure(errorMessage, httpStatus), httpStatus);
    }

    public static ResponseEntity<ResponseMessageOnFailure> Error(ResponseMessageOnFailure responseMessageOnFailure, HttpStatus httpStatus) {
        return new ResponseEntity<>(responseMessageOnFailure, httpStatus);
    }
}
