package com.hav.st.common.exceptions.handler;

import com.hav.st.common.dto.ErrorMessage;
import com.hav.st.common.dto.ResponseMessageOnFailure;
import com.hav.st.common.exceptions.BadDataRequestSsException;
import com.hav.st.common.exceptions.BadDataSsException;
import com.hav.st.common.exceptions.CodeBasedSsException;
import com.hav.st.common.exceptions.EntityAlreadyExistsSsException;
import com.hav.st.common.exceptions.EntityNotFoundSsException;
import com.hav.st.common.exceptions.InvalidOperationSsException;
import com.hav.st.common.exceptions.MethodNotImplementedSsException;
import com.hav.st.common.exceptions.SalesStructureException;
import com.hav.st.common.utils.HttpResponseUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.UnsatisfiedServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;

public abstract class BaseApiExceptionHandler {

    /**
     * Tất cả các Exception không được khai báo sẽ được xử lý tại đây
     * @return
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity handleAllException(Exception ex, WebRequest request) {
        ex.printStackTrace();
        return processAndBuildResponse(new Exception(HttpStatus.INTERNAL_SERVER_ERROR.toString(), ex), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(UnsatisfiedServletRequestParameterException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ResponseEntity handleUnsatisfiedServletRequestParameterException(Exception ex, WebRequest request) {
        return processAndBuildResponse(ex, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(EntityNotFoundSsException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public ResponseEntity whenEntityNotFoundSsException(Exception ex, WebRequest request) {
        return processAndBuildResponse(ex, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(EntityAlreadyExistsSsException.class)
    @ResponseStatus(value = HttpStatus.CONFLICT)
    public ResponseEntity whenEntityAlreadyExistsSsException(Exception ex, WebRequest request) {
        return processAndBuildResponse(ex, HttpStatus.CONFLICT);
    }

    @ExceptionHandler(InvalidOperationSsException.class)
    @ResponseStatus(value = HttpStatus.NOT_ACCEPTABLE)
    public ResponseEntity whenInvalidOperationSsException(Exception ex, WebRequest request) {
        return processAndBuildResponse(ex, HttpStatus.NOT_ACCEPTABLE);
    }

    @ExceptionHandler(BadDataSsException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ResponseEntity whenBadDataSsException(Exception ex, WebRequest request) {
        return processAndBuildResponse(ex, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(BadDataRequestSsException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ResponseEntity whenBadDataRequestSsException(Exception ex, WebRequest request) {
        return processAndBuildResponse(ex, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MethodNotImplementedSsException.class)
    @ResponseStatus(value = HttpStatus.NOT_IMPLEMENTED)
    public ResponseEntity whenMethodNotImplementedSsException(Exception ex, WebRequest request) {
        return processAndBuildResponse(ex, HttpStatus.NOT_IMPLEMENTED);
    }

    @ExceptionHandler(CodeBasedSsException.class)
    @ResponseStatus(value = HttpStatus.EXPECTATION_FAILED)
    public ResponseEntity whenCodeBasedSsException(Exception ex, WebRequest request) {
        CodeBasedSsException cbe = (CodeBasedSsException)ex;
        ex.printStackTrace();
        return HttpResponseUtil.Error(new ResponseMessageOnFailure(cbe.getErrorCode(), cbe.getMessage(), cbe.getReturnCode(), HttpStatus.EXPECTATION_FAILED), HttpStatus.EXPECTATION_FAILED);
    }

    @ExceptionHandler(SalesStructureException.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity defaultForSaleStructureException(Exception ex, WebRequest request) {
        return processAndBuildResponse(ex, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    protected ResponseEntity processAndBuildResponse(Exception ex, HttpStatus httpStatus) {
        ex.printStackTrace();
        return HttpResponseUtil.Error(new ErrorMessage(httpStatus.toString().toLowerCase().replaceAll("\\s", "_"), ex.getMessage()), httpStatus);
    }
}