package com.hav.st.common.rc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hav.st.common.utils.StringUtils;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalInt;
import java.util.Properties;
import java.util.stream.Collectors;

public class RcGenerator {
    @SneakyThrows
    public static void main(String[] args) {
        ObjectMapper objectMapper = new ObjectMapper();
        Properties properties = loadPropertiesFile();
        Map<Integer, RcInfo> map = new HashMap<>();
        Map<String, String> translated = new HashMap<>(properties.size());
        for (Map.Entry<Object, Object> entry : properties.entrySet()) {
            int code = Integer.parseInt(entry.getKey().toString()) * -1;
            if (map.containsKey(code))
                throw new Exception("Duplicate return code " + code);
            RcInfo rcInfo = null;
            try {
                rcInfo = objectMapper.readValue(entry.getValue().toString().trim(), RcInfo.class);
            } catch (Exception ex) {
                ex.printStackTrace();
                throw new Exception("Bad data, code " + code + ", data: " + entry.getValue());
            }
            map.put(code, rcInfo);
        }

        /*
        for (Map.Entry<Integer, RcInfo> entry : map.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue().code + ", " + entry.getValue().desc);
        }
         */

        OptionalInt optNewestGenerated = map.keySet().stream().mapToInt(x -> x).min();
        int newestGenerated = optNewestGenerated.isPresent() ? optNewestGenerated.getAsInt() : -80300;
        int nextRc = newestGenerated - 1;

        if (map.containsKey(nextRc))
            throw new Exception("Impossible!!! Map contains next rc, should not");

        String desc = null;
        do {
            System.out.println("Description:");
            desc = readLine();
        } while (StringUtils.isEmpty(desc));

        final String description = desc;

        if (map.entrySet().stream().anyMatch(x -> x.getValue().desc.equalsIgnoreCase(description)))
            throw new Exception("Duplicate description " + desc);

        String generatedCode = desc.trim().toUpperCase().replaceAll("[^A-Z0-9]", "_").replaceAll("[_]+", "_");
        System.out.println("Code:");
        System.out.println(generatedCode);

        if (map.entrySet().stream().anyMatch(x -> x.getValue().code.equalsIgnoreCase(generatedCode)))
            throw new Exception("Duplicate generated code " + generatedCode);

        RcInfo rcInfo = new RcInfo((nextRc * -1) + "_" + generatedCode, desc);
        map.put(nextRc, rcInfo);

        // write rc.properties
        String[] lines = new String[1];
        lines[0] = (nextRc * -1) + "=" + objectMapper.writeValueAsString(rcInfo);
        Files.write(Paths.get(new File("src/main/resources/rc.properties").toURI()), Arrays.asList(lines), StandardOpenOption.APPEND);


        // generate java file
        final String fileName = "ErrorMessages";
        StringBuilder sb = new StringBuilder();
        sb.append("package com.hav.st.common.rc;");
        sb.append('\n');
        sb.append("public class " + fileName + " {");
        sb.append('\n');
        for (Map.Entry<Integer, RcInfo> entry : map.entrySet()) {
            sb.append("\tpublic static final Code RC_" + entry.getValue().code + " = new Code(" + nextRc + ", \"" + entry.getValue().code + "\", \"" + entry.getValue().desc + "\");");
            sb.append('\n');
        }
        sb.append('}');

        lines[0] = sb.toString();
        Files.write(Paths.get(new File("src/main/java/com/hav/st/common/rc/" + fileName + ".java").toURI()), Arrays.asList(lines));
    }

    private static String readLine() {
        try {
            return new BufferedReader(new InputStreamReader(System.in)).readLine();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    @SneakyThrows
    private static Properties loadPropertiesFile() {
        InputStream inputStream = null;
        try {
            Properties prop = new Properties();
            String propFileName = "rc.properties";

            inputStream = RcGenerator.class.getClassLoader().getResourceAsStream(propFileName);
            prop.load(inputStream);

            return prop;
        } finally {
            inputStream.close();
        }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    private static class RcInfo {
        private String code;
        private String desc;
    }
}
