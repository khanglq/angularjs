package com.hav.st.common.rc;

public class ErrorMessages {
    public static final Code RC_80301_VERY_FIRST_CODE_BASED_EXCEPTION_HELLO_S_
            = new Code(
            -80301,
            "80301_VERY_FIRST_CODE_BASED_EXCEPTION_HELLO_S_",
            "Very first code based exception, hello %s"
    );
}
