package com.hav.st.common.exceptions;

public class CodeBasedSsException extends SalesStructureException {
    private int returnCode;
    private String errorCode;

    public CodeBasedSsException(int returnCode, String errorCode, String msg) {
        super(msg);
        this.returnCode = returnCode;
        this.errorCode = errorCode;
    }

    public int getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(int returnCode) {
        this.returnCode = returnCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
}
