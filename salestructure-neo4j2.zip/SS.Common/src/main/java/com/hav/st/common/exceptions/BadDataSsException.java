package com.hav.st.common.exceptions;

public class BadDataSsException extends SalesStructureException {
    public BadDataSsException(String s) {
        super(s);
    }
}
