package com.hav.st.common.constant;

public class CommonConstant {
    public static final String API_V1 = "/api/v1";
}
