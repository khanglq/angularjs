package com.hav.st.common.controller;


import com.hav.st.common.dto.DataRequestDTO;
import com.hav.st.common.dto.ErrorMessage;
import com.hav.st.common.exceptions.BadDataRequestSsException;
import com.hav.st.common.utils.HttpResponseUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin
public abstract class BaseController {
    protected <T> void throwIfBadDTO(DataRequestDTO<T> dto) {
        if (dto == null || dto.getData() == null)
            throw new BadDataRequestSsException();
    }

    protected ResponseEntity ok() {
        return statusCodeWhenSuccess(HttpStatus.OK);
    }

    protected ResponseEntity ok(String message) {
        return statusCodeWhenSuccess(message, HttpStatus.OK);
    }

    protected <T> ResponseEntity ok(@Nullable T body) {
        return statusCodeWhenSuccess(body, HttpStatus.OK);
    }

    protected ResponseEntity created() {
        return statusCodeWhenSuccess(HttpStatus.CREATED);
    }

    protected <T> ResponseEntity created(@Nullable T body) {
        return statusCodeWhenSuccess(body, HttpStatus.CREATED);
    }

    protected ResponseEntity notFound() {
        return statusCodeWhenError(HttpStatus.NOT_FOUND);
    }

    protected ResponseEntity notFound(String message) {
        return statusCodeWhenError(message, HttpStatus.NOT_FOUND);
    }

    protected ResponseEntity conflict() {
        return statusCodeWhenError(HttpStatus.CONFLICT);
    }

    protected ResponseEntity conflict(String message) {
        return statusCodeWhenError(message, HttpStatus.CONFLICT);
    }

    protected ResponseEntity badRequest() {
        return statusCodeWhenError(HttpStatus.BAD_REQUEST);
    }

    protected ResponseEntity badRequest(String message) {
        return statusCodeWhenError(message, HttpStatus.BAD_REQUEST);
    }

    protected ResponseEntity notModified() {
        return statusCodeWhenError(HttpStatus.NOT_MODIFIED);
    }

    protected <T> ResponseEntity statusCodeWhenError(HttpStatus httpStatus) {
        return HttpResponseUtil.Error(new ErrorMessage(httpStatus.toString().toLowerCase().replaceAll("\\s", "_"), ""), httpStatus);
    }

    protected <T> ResponseEntity statusCodeWhenError(String message, HttpStatus httpStatus) {
        return HttpResponseUtil.Error(new ErrorMessage(httpStatus.toString().toLowerCase().replaceAll("\\s", "_"), message), httpStatus);
    }

    protected ResponseEntity statusCodeWhenSuccess(HttpStatus httpStatus) {
        return statusCodeWhenSuccess(httpStatus.toString().toUpperCase(), httpStatus);
    }

    protected <T> ResponseEntity statusCodeWhenSuccess(T data, HttpStatus httpStatus) {
        return HttpResponseUtil.Success(data, httpStatus);
    }
}
