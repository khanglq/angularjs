package com.hav.st.common.exceptions;

import java.util.function.Supplier;

public class EntityNotFoundSsException extends SalesStructureException {
    public EntityNotFoundSsException(String s) {
        super(s);
    }

    public static Supplier<EntityNotFoundSsException> of(Class clz, Object rid) {
        return of(clz, "cid", rid);
    }

    public static Supplier<EntityNotFoundSsException> of(Class clz, String propertyName, Object value) {
        return msg(clz.getSimpleName() + " with " + propertyName + " = '" + value + "' could not be found");
    }

    public static Supplier<EntityNotFoundSsException> msg(String message) {
        return () -> new EntityNotFoundSsException(message);
    }
}
