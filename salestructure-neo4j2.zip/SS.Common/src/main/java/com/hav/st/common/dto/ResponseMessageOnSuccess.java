package com.hav.st.common.dto;

import org.springframework.http.HttpStatus;

public class ResponseMessageOnSuccess<T> extends BaseResponseMessage<T> {
    public ResponseMessageOnSuccess(T data, HttpStatus httpStatus) {
        super(data, httpStatus.value(), 1, null);
    }
}
