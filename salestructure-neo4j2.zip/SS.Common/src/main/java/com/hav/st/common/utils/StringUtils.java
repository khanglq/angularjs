package com.hav.st.common.utils;

import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

public class StringUtils {
    public static final String EMAIL_REGEX = "^" + // begin of string marker
            "[A-Za-z0-9._%+-]+@" + // mailbox@
            "(?:[A-Za-z0-9-]+\\.)+" + // subdomain.domain.
            "(?:[A-Za-z]{2}|com|org|net|gov|mil|biz|info|mobi|name|aero|jobs|museum)" + // tld
            "$"; // end of string marker
    public static final String EMAIL_SEPARATORS = " \n\r\t\b'\",;:`<>[]{}()";
    //use to separate string values;
    public static final String EMPTY_STRING = "";
    public static final String ALPHA_NUMBERIC_REGEX = "^[a-zA-Z0-9]*$";

    public static ArrayList<String> parseEmails(String s) {
        ArrayList<String> ret = new ArrayList<>();

        StringTokenizer st = new StringTokenizer(s, EMAIL_SEPARATORS);
        while (st.hasMoreTokens()) {
            String token = st.nextToken();
            if (token.matches(EMAIL_REGEX)) {
                ret.add(token);
            }
        }
        return ret;
    }

    public static boolean isValidPassword(String str, int atLeastUpperCaseLetters, int atLeastLowerCaseLetters, int atLeastNumbers, int atLeastSpecialChars) {
        if (atLeastUpperCaseLetters > 0 || atLeastLowerCaseLetters > 0 || atLeastNumbers > 0 || atLeastSpecialChars > 0) {
            String regex = getRegexToValidate(atLeastUpperCaseLetters, atLeastLowerCaseLetters, atLeastNumbers, atLeastSpecialChars);
            return Pattern.matches(regex, str);
        } else
            return true;
    }

    public static boolean isAlphaNumberic(String str) {
        return Pattern.matches(ALPHA_NUMBERIC_REGEX, str);
    }

    /**
     * @param s
     * @return IMPORTANT NOTE: this method return NULL if the input is an empty string
     */
    public static String trim(String s) {
        return (s == null || s.trim().equals(StringUtils.EMPTY_STRING)) ? null : s.trim();
    }

    public static String nullTrim(String s) {
        return s == null ? "" : s.trim();
    }

    public static String idTrim(String s) {
        return (s == null || s.trim().equals("")) ? null : s.trim().toUpperCase();
    }

    public static String typeTrim(String s) {
        return s == null ? "" : s.trim().toUpperCase();
    }

    public static boolean isEmpty(String s) {
        return s == null || s.trim().equals("");
    }

    public static boolean isNotEmpty(String s) {
        return !isEmpty(s);
    }

    public static boolean areIdEqual(String s1, String s2) {
        return s1 == null ? s2 == null : idTrim(s1).equals(idTrim(s2));
    }

    public static String capitalize(String s) {
        if (s == null) return null;
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }

    public static boolean isValueEqualsIgnoreCase(String str1, String str2) {
        return nullTrim(str1).equalsIgnoreCase(nullTrim(str2));
    }

    public static boolean isValueEquals(String str1, String str2) {
        return nullTrim(str1).equals(nullTrim(str2));
    }

    public static boolean isValueNotEquals(String str1, String str2) {
        return !nullTrim(str1).equals(nullTrim(str2));
    }

    private static String getRegexToValidate(int atLeastUpperCaseLetters, int atLeastLowerCaseLetters, int atLeastNumbers, int atLeastSpecialChars) {
        //String ALPHA_NUMERIC_PASSWORD_REGEX = "^((?=.*[^a-zA-Z])(?=.*[a-z])(?=.*[A-Z]).{2,})$";
        final String REGEX_START = "^(";
        final String REGEX_END = ".*)$";
        final String REGEX_SUB_START = "(?=";
        final String REGEX_ANY_CHAR_AT_LEAST_ONE_OR_NONE_FOLLOWED = ".*";
        final String REGEX_UPPER_CASE_LETTER = "[A-Z]";
        final String REGEX_LOWER_CASE_LETTER = "[a-z]";
        final String REGEX_NUMERIC_DIGIT = "[0-9]";
        final String REGEX_SPECIAL_CHARACTERS = "[^a-zA-Z0-9]";

        String regex = REGEX_START;
        if (atLeastUpperCaseLetters > 0) {
            StringBuilder subRegex = new StringBuilder(REGEX_SUB_START);
            for (int i = 0; i < atLeastUpperCaseLetters; i++) {
                subRegex.append(REGEX_ANY_CHAR_AT_LEAST_ONE_OR_NONE_FOLLOWED + REGEX_UPPER_CASE_LETTER);
            }
            subRegex.append(")");
            regex += subRegex;
        }

        if (atLeastLowerCaseLetters > 0) {
            StringBuilder subRegex = new StringBuilder(REGEX_SUB_START);
            for (int i = 0; i < atLeastLowerCaseLetters; i++) {
                subRegex.append(REGEX_ANY_CHAR_AT_LEAST_ONE_OR_NONE_FOLLOWED + REGEX_LOWER_CASE_LETTER);
            }
            subRegex.append(")");
            regex += subRegex;
        }

        if (atLeastNumbers > 0) {
            StringBuilder subRegex = new StringBuilder(REGEX_SUB_START);
            for (int i = 0; i < atLeastNumbers; i++) {
                subRegex.append(REGEX_ANY_CHAR_AT_LEAST_ONE_OR_NONE_FOLLOWED + REGEX_NUMERIC_DIGIT);
            }
            subRegex.append(")");
            regex += subRegex;
        }

        if (atLeastSpecialChars > 0) {
            StringBuilder subRegex = new StringBuilder(REGEX_SUB_START);
            for (int i = 0; i < atLeastSpecialChars; i++) {
                subRegex.append(REGEX_ANY_CHAR_AT_LEAST_ONE_OR_NONE_FOLLOWED + REGEX_SPECIAL_CHARACTERS);
            }
            subRegex.append(")");
            regex += subRegex;
        }

        regex += REGEX_END;
        return regex;
    }

}
