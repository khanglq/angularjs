package com.hav.st.common.dto;

public class BaseDTO {

}
