package com.hav.st.common.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public abstract class BaseResponseMessage<T> {
    T data;

    int status; // Http status

    @JsonProperty("rc")
    int returnCode;

    ErrorMessage errorMessage;
}
