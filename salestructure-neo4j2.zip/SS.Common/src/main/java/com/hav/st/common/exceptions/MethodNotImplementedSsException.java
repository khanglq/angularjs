package com.hav.st.common.exceptions;

public class MethodNotImplementedSsException extends SalesStructureException {
    public MethodNotImplementedSsException() {
        super("This method had not been implemented, please contact developer");
    }
}
