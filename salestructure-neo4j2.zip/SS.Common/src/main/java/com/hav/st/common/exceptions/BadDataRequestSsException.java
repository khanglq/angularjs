package com.hav.st.common.exceptions;

public class BadDataRequestSsException extends BadDataSsException {
    public BadDataRequestSsException() {
        super("Bad DTO");
    }
}
