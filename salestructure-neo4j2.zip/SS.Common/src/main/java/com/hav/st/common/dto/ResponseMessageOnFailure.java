package com.hav.st.common.dto;

import org.springframework.http.HttpStatus;

public class ResponseMessageOnFailure extends BaseResponseMessage<Object> {
    public ResponseMessageOnFailure(ErrorMessage errorMessage, HttpStatus httpStatus) {
        super(null, httpStatus.value(), buildSalesStructureReturnCode(httpStatus), errorMessage);
    }

    public ResponseMessageOnFailure(String error, String errorDescription, HttpStatus httpStatus) {
        super(null, httpStatus.value(), buildSalesStructureReturnCode(httpStatus), new ErrorMessage(error, errorDescription));
    }

    public ResponseMessageOnFailure(String error, String errorDescription, int returnCode, HttpStatus httpStatus) {
        super(null, httpStatus.value(), returnCode, new ErrorMessage(error, errorDescription));
    }

    /**
     * Method này sẽ convert từ http status code sang return code của Sales Structure.
     * Ví dụ: Http Status Code 404 sẽ được convert thành -80104
     * Mã nhỏ hơn 200 thuộc loại processing info nên sẽ bị ignore.
     * Mã 200 đến 299 thuộc loại success nên sẽ có return code là 1, xử lý bên class ResponseMessageOnSuccess.
     * Từ mã 300 trở đi mới được convert thành return code theo công thức:
     * -80000 - (http status code - 300)
     * Như vậy từ return code hoàn toàn có thể truy ngược được lại xem http code nguyên gốc là gì, trừ các mã nhỏ hơn 300 và lớn hơn 599 sẽ được convert thành -80300, vì vậy mã -80300 là mã không được phép xuất hiện
     * @param httpStatus
     * @return
     */
    private static int buildSalesStructureReturnCode(HttpStatus httpStatus) {
        int httpStatusCode = httpStatus.value();
        if (httpStatusCode < 300 || httpStatusCode >= 600)
            return -80_300;
        return -79_700 - httpStatusCode;
    }
}
