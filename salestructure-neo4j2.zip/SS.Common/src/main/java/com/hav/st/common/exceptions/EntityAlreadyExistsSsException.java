package com.hav.st.common.exceptions;

public class EntityAlreadyExistsSsException extends SalesStructureException {
    public EntityAlreadyExistsSsException(String s) {
        super(s);
    }
}
