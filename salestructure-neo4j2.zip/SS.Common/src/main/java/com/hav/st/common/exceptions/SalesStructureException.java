package com.hav.st.common.exceptions;

/**
 * Delivered type of exception can be safely report message to client.
 * Delivered type of exception ONLY be used to print exception to client.
 */
public abstract class SalesStructureException extends RuntimeException {
    public SalesStructureException(String s) {
        super(s);
    }

    public SalesStructureException(String s, Throwable throwable) {
        super(s, throwable);
    }
}
