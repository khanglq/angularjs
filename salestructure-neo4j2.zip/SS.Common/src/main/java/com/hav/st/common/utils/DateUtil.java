package com.hav.st.common.utils;

import com.hav.st.common.exceptions.BadDataSsException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;

public class DateUtil {
    public static final SimpleDateFormat formatter_ddMMyyyy=new SimpleDateFormat("dd/MM/yyyy");

    public static Date fromString(String date) throws ParseException {
        return formatter_ddMMyyyy.parse(date);
    }

    public static BadDataSsException createBadDataSsExceptionWhenInvalidFormat() {
        return new BadDataSsException("Date must in format: dd/MM/yyyy");
    }

    public static String fromDate(Date date) {
        if (date == null) return null;
        return formatter_ddMMyyyy.format(date);
    }

    public static Date nowUtc() {
        return Date.from(Instant.now());
    }
}
