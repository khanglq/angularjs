package com.hav.st.common.rc;

import com.hav.st.common.exceptions.CodeBasedSsException;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Code {
    private int returnCode;
    private String errorCode;
    private String errorDescription;

    public CodeBasedSsException toException(Object...args) {
        return new CodeBasedSsException(returnCode, errorCode, String.format(errorDescription, args));
    }
}
