package com.hav.st.common.exceptions;

public class InvalidOperationSsException extends SalesStructureException {
    public InvalidOperationSsException() {
        super("Invalid operation");
    }

    public InvalidOperationSsException(String s) {
        super(s);
    }
}
