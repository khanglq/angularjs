package com.hav.st.core.service.domain.impl;

import com.hav.st.common.exceptions.InvalidOperationSsException;
import com.hav.st.core.domain.EmploymentContract;
import com.hav.st.core.entities.functional.ApprovalStates;
import com.hav.st.core.exceptions.BadDataSpmException;
import com.hav.st.core.exceptions.EntityNotFoundSpmException;
import com.hav.st.core.repository.pg.EmploymentContractPgRepository;
import com.hav.st.core.service.domain.ApprovalService;
import com.hav.st.core.service.domain.EmploymentContractService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.transaction.Transactional;
import java.math.BigInteger;
import java.util.Collection;

@Transactional
@Service
public class EmploymentContractServiceImpl implements EmploymentContractService {

    @Autowired
    private EmploymentContractPgRepository employmentContractPgRepository;

    @Autowired
    private ApprovalService approvalService;

    @Override
    public EmploymentContract add(EmploymentContract contract) {
        contract.setApprovalState(ApprovalStates.PENDING);
        contract.setContractSubType(contract.getContractType());

        com.hav.st.core.entities.pg.EmploymentContract employmentContract = EmploymentContract.toPgEntity(contract);

        verifyEmploymentContract(contract);

        employmentContractPgRepository.save(employmentContract);

        return EmploymentContract.fromEntity(employmentContract);
    }

    private void verifyEmploymentContract(EmploymentContract employmentContract) {
        if (employmentContract.getCompanySide() == null
                || StringUtils.isAnyBlank(employmentContract.getCompanySide().getName(), employmentContract.getCompanySide().getAddress(), employmentContract.getCompanySide().getPhoneNo(), employmentContract.getCompanySide().getLegalRepresentativePersonName(), employmentContract.getCompanySide().getAuthorizedRepresentativePersonName(), employmentContract.getCompanySide().getAuthorizedDocumentNo()))
            throw new BadDataSpmException("Thiếu thông tin bên A");

        if (employmentContract.getEmployeeSide() == null
                || StringUtils.isAnyBlank(employmentContract.getEmployeeSide().getEmployeeId(), employmentContract.getEmployeeSide().getName(), employmentContract.getEmployeeSide().getPermanentAddress(), employmentContract.getEmployeeSide().getContactAddress(), employmentContract.getEmployeeSide().getPhoneNo(), employmentContract.getEmployeeSide().getEmail(), employmentContract.getEmployeeSide().getTaxCode(), employmentContract.getEmployeeSide().getMoneyReceivingAccount()))
            throw new BadDataSpmException("Thiếu thông tin bên B");

        if (StringUtils.isBlank(employmentContract.getEmployeeGroup()))
            throw new BadDataSpmException("Thiếu thông tin Nhóm Nhân Sự");

        if (StringUtils.isBlank(employmentContract.getContractNo()))
            throw new BadDataSpmException("Thiếu thông tin Số Hợp Đồng");

        if (StringUtils.isBlank(employmentContract.getContractType()))
            throw new BadDataSpmException("Thiếu thông tin Loại Hợp Đồng");

        if (StringUtils.isBlank(employmentContract.getContractSubType()))
            throw new BadDataSpmException("Thiếu thông tin Loại Hợp Đồng (sub)");

        if (employmentContract.getFromDate() == null)
            throw new BadDataSpmException("Thiếu thông tin Ngày Bắt Đầu Hiệu Lực");
    }

    @Override
    public Page<EmploymentContract> findAll(Specification<com.hav.st.core.entities.pg.EmploymentContract> specification, Pageable pageable) {
        return employmentContractPgRepository
                .findAll(specification, pageable)
                .map(EmploymentContract::fromEntity);
    }

    @Override
    public void updateApprovalStateOfEmploymentContracts(Collection<EmploymentContract> employmentContracts, ApprovalStates newState, String note) {
        if (CollectionUtils.isEmpty(employmentContracts)) {
            throw new BadDataSpmException("Không có hợp đồng nhân sự cần phê duyệt");
        }

        for (EmploymentContract employmentContract : employmentContracts)
            if (StringUtils.isBlank(employmentContract.getId()))
                throw new BadDataSpmException("Thiếu id của hợp đồng nhân sự");

        if (newState == null) {
            throw new BadDataSpmException("Thiếu trạng thái phê duyệt (newState)");
        }

        if (newState == ApprovalStates.PENDING) {
            throw new BadDataSpmException("Trạng thái phê duyệt không hợp lệ (newState)");
        }

        if (newState == ApprovalStates.REJECTED && StringUtils.isBlank(note)) {
            throw new BadDataSpmException("Từ chối cần lý do");
        }

        for (EmploymentContract employmentContract : employmentContracts) {
            com.hav.st.core.entities.pg.EmploymentContract pgEntity = employmentContractPgRepository.findById(new BigInteger(employmentContract.getId()))
                    .orElseThrow(EntityNotFoundSpmException.of(com.hav.st.core.entities.pg.EmploymentContract.class, "id", employmentContract.getId()));

            if (!pgEntity.IsPending()) {
                if (pgEntity.IsApproved())
                    throw new InvalidOperationSsException("Bản ghi đã được duyệt trước đó");
                else if (pgEntity.IsRejected())
                    throw new InvalidOperationSsException("Bản ghi đã bị từ chối trước đó");
                else
                    throw new InvalidOperationSsException("Bản ghi đã được phê duyệt hoặc bị từ chối trước đó");
            }

            pgEntity.setApprovalState(newState);

            employmentContractPgRepository.save(pgEntity);

            approvalService.addHistory(employmentContract.getClass(), employmentContract.getId(), newState, note);
        }
    }
}
