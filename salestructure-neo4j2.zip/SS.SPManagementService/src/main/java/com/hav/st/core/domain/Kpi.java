package com.hav.st.core.domain;

import com.hav.st.core.utils.ReflectionUtil;
import lombok.Data;

@Data
public class Kpi extends DomainEntity {
    private String name;
    private String desc;
    private String type;

    public static Kpi fromNeo4jEntity(com.hav.st.core.entities.neo4j.node.Kpi entity) {
        Kpi domain = new Kpi();
        domain.id = entity.getCid();

        ReflectionUtil.copyProperties(entity, domain);
        return domain;
    }
}
