package com.hav.st.core.entities.neo4j.node;

import lombok.Data;
import org.neo4j.ogm.annotation.NodeEntity;

@Data
@NodeEntity(label = "Product")
public class Product extends EntityNode {

    private String productCode;

}
