package com.hav.st.core.service.domain.impl;

import com.hav.st.common.exceptions.InvalidOperationSsException;
import com.hav.st.core.domain.Kpi;
import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import com.hav.st.core.domain.Position;
import com.hav.st.core.domain.SalesStructure;
import com.hav.st.core.domain.relationship.IsManagerOf;
import com.hav.st.core.entities.functional.ApprovalStates;
import com.hav.st.core.entities.neo4j.relationship.ApplyTo;
import com.hav.st.core.entities.neo4j.relationship.Contains;
import com.hav.st.core.entities.neo4j.relationship.HasLevel;
import com.hav.st.core.entities.neo4j.relationship.Incharge;
import com.hav.st.core.exceptions.BadDataSpmException;
import com.hav.st.core.exceptions.EntityNotFoundSpmException;
import com.hav.st.core.models.CreateSalesStructureModel;
import com.hav.st.core.models.FullKpiModel;
import com.hav.st.core.models.FullLevelTreeModel;
import com.hav.st.core.models.FullSalesStructureModel;
import com.hav.st.core.models.SetManagementModel;
import com.hav.st.core.models.UpdateKpiModel;
import com.hav.st.core.repository.neo4j.node.EmployeeNeo4jRepository;
import com.hav.st.core.repository.neo4j.node.KpiNeo4jRepository;
import com.hav.st.core.repository.neo4j.node.LevelTreeNeo4jRepository;
import com.hav.st.core.repository.neo4j.node.PositionNeo4jRepository;
import com.hav.st.core.repository.neo4j.node.SalesStructureNeo4jRepository;
import com.hav.st.core.repository.neo4j.relationship.ContainsNeo4jRepository;
import com.hav.st.core.repository.neo4j.relationship.HasLevelNeo4jRepository;
import com.hav.st.core.repository.neo4j.relationship.InchargeNeo4jRepository;
import com.hav.st.core.repository.neo4j.relationship.IsManagerOfNeo4jRepository;
import com.hav.st.core.repository.neo4j.relationship.UseLevelTreeNeo4jRepository;
import com.hav.st.core.service.domain.LevelTreeService;
import com.hav.st.core.service.domain.SalesStructureService;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.transaction.NotSupportedException;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Transactional
@Service
public class SalesStructureServiceImpl implements SalesStructureService {

    private final SalesStructureNeo4jRepository salesStructureNeo4jRepository;

    private final ContainsNeo4jRepository containsNeo4jRepository;

    private final InchargeNeo4jRepository inchargeNeo4jRepository;

    private final PositionNeo4jRepository positionNeo4jRepository;

    private final EmployeeNeo4jRepository employeeNeo4jRepository;

    private final IsManagerOfNeo4jRepository isManagerOfNeo4jRepository;

    private final HasLevelNeo4jRepository hasLevelNeo4jRepository;

    private final LevelTreeNeo4jRepository levelTreeNeo4jRepository;

    private final UseLevelTreeNeo4jRepository useLevelTreeNeo4jRepository;

    private final KpiNeo4jRepository kpiNeo4jRepository;

    private final LevelTreeService levelTreeService;

    public SalesStructureServiceImpl(SalesStructureNeo4jRepository salesStructureNeo4jRepository, ContainsNeo4jRepository containsNeo4jRepository, InchargeNeo4jRepository inchargeNeo4jRepository, PositionNeo4jRepository positionNeo4jRepository, EmployeeNeo4jRepository employeeNeo4jRepository, IsManagerOfNeo4jRepository isManagerOfNeo4jRepository, HasLevelNeo4jRepository hasLevelNeo4jRepository, LevelTreeNeo4jRepository levelTreeNeo4jRepository, UseLevelTreeNeo4jRepository useLevelTreeNeo4jRepository, KpiNeo4jRepository kpiNeo4jRepository, LevelTreeService levelTreeService) {
        this.salesStructureNeo4jRepository = salesStructureNeo4jRepository;
        this.containsNeo4jRepository = containsNeo4jRepository;
        this.inchargeNeo4jRepository = inchargeNeo4jRepository;
        this.positionNeo4jRepository = positionNeo4jRepository;
        this.employeeNeo4jRepository = employeeNeo4jRepository;
        this.isManagerOfNeo4jRepository = isManagerOfNeo4jRepository;
        this.hasLevelNeo4jRepository = hasLevelNeo4jRepository;
        this.levelTreeNeo4jRepository = levelTreeNeo4jRepository;
        this.useLevelTreeNeo4jRepository = useLevelTreeNeo4jRepository;
        this.kpiNeo4jRepository = kpiNeo4jRepository;
        this.levelTreeService = levelTreeService;
    }

    @Override
    public Page<SalesStructure> findAll(Specification<com.hav.st.core.entities.neo4j.node.SalesStructure> specification, Pageable pageable) {
        /*
        return salesStructureNeo4jRepository
                .findAll(specification, pageable)
                .map(x -> SalesStructure.fromNeo4jEntity(x));

         */
        return null;
    }

    @SneakyThrows
    @Override
    public Collection<Position> addPositionsIntoSalesStructure(SalesStructure salesStructure, Collection<Position> positions) {
        if (salesStructure == null) {
            throw new BadDataSpmException("Missing sales structure");
        }

        BadDataSpmException.throwIfMissingId(salesStructure);

        if (CollectionUtils.isEmpty(positions)) {
            throw new BadDataSpmException("Require at least one position");
        }

        for (Position position : positions) {
            if (position.getFromDate() == null) {
                throw new BadDataSpmException("Missing fromDate of position");
            }
            if (StringUtils.isBlank(position.getSalesId())) {
                throw new BadDataSpmException("Missing sales id of position");
            }
            if (StringUtils.isBlank(position.getLevelCode())) {
                throw new BadDataSpmException("Missing level code of position");
            }
        }

        com.hav.st.core.entities.neo4j.node.SalesStructure nodeSalesStructureEntity = salesStructureNeo4jRepository
                .findById(salesStructure.getId(), 2)
                .orElseThrow(EntityNotFoundSpmException.of(salesStructure));

        if (nodeSalesStructureEntity.getUseLevelTree() == null) {
            throw new InvalidOperationSsException("Sale structure must be associated with a level tree in order to add positions");
        }

        if (CollectionUtils.isEmpty(nodeSalesStructureEntity.getUseLevelTree().getToNode().getAllContains())) {
            throw new InvalidOperationSsException("The level tree which is being associated with sale structure does not contains any level");
        }

        List<com.hav.st.core.entities.neo4j.node.Position> createdPositions = new ArrayList<>();

        for (Position position : positions) {
            com.hav.st.core.entities.neo4j.node.Level level = nodeSalesStructureEntity.getUseLevelTree()
                    .getToNode()
                    .getAllContains().stream().filter(x -> position.getLevelCode().equals(x.getToNode().getLevelCode()))
                    .findFirst()
                    .orElseThrow(EntityNotFoundSpmException.of(com.hav.st.core.entities.neo4j.node.Level.class, "levelCode", position.getLevelCode()))
                    .getToNode();

            com.hav.st.core.entities.neo4j.node.Employee nodeEmployeeEntity = employeeNeo4jRepository
                    .findBySalesId(position.getSalesId())
                    .orElseThrow(EntityNotFoundSpmException.of(com.hav.st.core.entities.neo4j.node.Employee.class, "salesId", position.getSalesId()));

            //
            com.hav.st.core.entities.neo4j.node.Position nodePositionEntity = new com.hav.st.core.entities.neo4j.node.Position();

            nodePositionEntity.setFromDate(position.getFromDate());
            nodePositionEntity.setToDate(position.getToDate());
            nodePositionEntity.setSalesId(position.getSalesId());

            positionNeo4jRepository.save(nodePositionEntity);
            //

            Incharge relInchargeEntity = new Incharge();

            relInchargeEntity.setFromDate(position.getFromDate());
            relInchargeEntity.setToDate(position.getToDate());

            relInchargeEntity.connects(nodeEmployeeEntity, nodePositionEntity);

            inchargeNeo4jRepository.save(relInchargeEntity);
            //

            Contains relContainsEntity = new Contains();

            relContainsEntity.connects(nodeSalesStructureEntity, nodePositionEntity);

            containsNeo4jRepository.save(relContainsEntity);
            //

            HasLevel relHasLevelEntity = new HasLevel();

            relHasLevelEntity.connects(nodePositionEntity, level);

            hasLevelNeo4jRepository.save(relHasLevelEntity);
            //

            nodePositionEntity.setIncharge(relInchargeEntity);
            nodePositionEntity.setContains(relContainsEntity);
            nodePositionEntity.setHasLevel(relHasLevelEntity);

            positionNeo4jRepository.save(nodePositionEntity);
            //

            nodeEmployeeEntity.addRelIncharge(relInchargeEntity);
            employeeNeo4jRepository.save(nodeEmployeeEntity);
            //

            nodeSalesStructureEntity.addRelContains(relContainsEntity);
            salesStructureNeo4jRepository.save(nodeSalesStructureEntity);

            createdPositions.add(nodePositionEntity);
        }

        return createdPositions.stream().map(x -> Position.fromNeo4jEntity(x)).collect(Collectors.toList());
    }

    @Override
    public void addManagementRelationship(SetManagementModel model) {
        for (SetManagementModel.RelInfo relInfo : model.getRelationshipsInfo()) {
            if (StringUtils.isBlank(relInfo.getFromSalesId()))
                throw new BadDataSpmException("Missing sales id of manager");
            if (StringUtils.isBlank(relInfo.getToSalesId()))
                throw new BadDataSpmException("Missing sales id of lower level employee");
            if (relInfo.getEffectiveDate() == null)
                throw new BadDataSpmException("Missing effective date of relationship");
            if (relInfo.getFromSalesId().equals(relInfo.getToSalesId()))
                throw new BadDataSpmException("Manager and lower level employee can not be the same");
        }

        for (SetManagementModel.RelInfo relInfo : model.getRelationshipsInfo()) {
            com.hav.st.core.entities.neo4j.node.Position fromPosition = positionNeo4jRepository
                    .findBySalesId(relInfo.getFromSalesId())
                    .orElseThrow(EntityNotFoundSpmException.ofPosition("salesId", relInfo.getFromSalesId()));

            com.hav.st.core.entities.neo4j.node.Position toPosition = positionNeo4jRepository
                    .findBySalesId(relInfo.getToSalesId())
                    .orElseThrow(EntityNotFoundSpmException.ofPosition("salesId", relInfo.getToSalesId()));

            com.hav.st.core.entities.neo4j.relationship.IsManagerOf relIsManagerOfEntity = new com.hav.st.core.entities.neo4j.relationship.IsManagerOf();
            relIsManagerOfEntity.setFromDate(relInfo.getEffectiveDate());

            relIsManagerOfEntity.connects(fromPosition, toPosition);

            fromPosition.addRelManages(relIsManagerOfEntity);
            toPosition.addRelManagedBy(relIsManagerOfEntity);

            isManagerOfNeo4jRepository.save(relIsManagerOfEntity);
        }
    }

    @Override
    public void approveManagementRelationships(Collection<IsManagerOf> relationships, ApprovalStates newState) {
        relationships.forEach(x -> BadDataSpmException.throwIfMissingId(x));

        if (newState == null || newState.isPending()) {
            throw new InvalidOperationSsException("Can only approve or reject");
        }

        for (IsManagerOf relationship : relationships) {
            com.hav.st.core.entities.neo4j.relationship.IsManagerOf relIsManagerOfEntity = isManagerOfNeo4jRepository
                    .findById(relationship.getId())
                    .orElseThrow(EntityNotFoundSpmException.of(relationship));

            if (!relIsManagerOfEntity.getApprovalState().isPending()) {
                throw new InvalidOperationSsException("Approve/Reject the Pending relationships only");
            }

            relIsManagerOfEntity.setApprovalState(newState);

            isManagerOfNeo4jRepository.save(relIsManagerOfEntity);
        }
    }

    @Override
    public void expireManagementRelationship(IsManagerOf isManagerOf) {
        BadDataSpmException.throwIfMissingId(isManagerOf);

        if (isManagerOf.getExpiryDate() == null)
            throw new BadDataSpmException("Missing expiry date");

        com.hav.st.core.entities.neo4j.relationship.IsManagerOf relIsManagerOfEntity = isManagerOfNeo4jRepository
                .findById(isManagerOf.getId(), 1)
                .orElseThrow(EntityNotFoundSpmException.of(isManagerOf));

        if (relIsManagerOfEntity.getExpiryDate() != null)
            throw new InvalidOperationSsException("Can only expires relations which doesn't have expiry date");

        if (!isManagerOf.getToDate().after(relIsManagerOfEntity.getFromDate()))
            throw new BadDataSpmException("Expiry date must after effective date");

        relIsManagerOfEntity.setExpiryDate(isManagerOf.getExpiryDate());

        isManagerOfNeo4jRepository.save(relIsManagerOfEntity);
    }

    @Override
    public SalesStructure getSalesStructure(SalesStructure salesStructure) {
        com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository.findById(salesStructure.getId(), 0)
                .orElseThrow(EntityNotFoundSpmException.of(salesStructure));

        return SalesStructure.fromNeo4jEntity(salesStructureEntity);
    }

    @Override
    public FullSalesStructureModel getFullSalesStructure(SalesStructure salesStructure) {
        com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository.findById(salesStructure.getId(), 3)
                .orElseThrow(EntityNotFoundSpmException.of(salesStructure));

        return FullSalesStructureModel.fromEntity(salesStructureEntity);
    }

    @Override
    public SalesStructure createSalesStructure(CreateSalesStructureModel createSalesStructureModel) {
        if (createSalesStructureModel.getSalesStructure() == null) {
            throw new BadDataSpmException("Missing sales structure info");
        }

        if (CollectionUtils.isEmpty(createSalesStructureModel.getLevels())) {
            throw new BadDataSpmException("Missing levels");
        }

        SalesStructure salesStructure = createSalesStructureModel.getSalesStructure();

        if (salesStructure.getFromDate() == null) {
            throw new BadDataSpmException("Missing effective date");
        }

        if (salesStructure.getToDate() != null && !salesStructure.getToDate().after(salesStructure.getFromDate())) {
            throw new BadDataSpmException("Expiry date must be greater than effective date");
        }

        if (StringUtils.isBlank(salesStructure.getName())) {
            throw new BadDataSpmException("Missing name");
        }

        LevelTree levelTree = new LevelTree();
        levelTree.setName(salesStructure.getName());
        levelTree.setDescription(salesStructure.getDescription());

        FullLevelTreeModel fullLevelTreeModel = levelTreeService.addTree(levelTree);
        if (fullLevelTreeModel == null || fullLevelTreeModel.getLevelTree() == null) {
            throw new BadDataSpmException("Cannot create level tree");
        }
        levelTree = fullLevelTreeModel.getLevelTree();

        int cnt = 1;
        for (Level level : createSalesStructureModel.getLevels()) {
            level.setLevel(cnt++);
        }
        fullLevelTreeModel = levelTreeService.addLevels(fullLevelTreeModel.getLevelTree(), createSalesStructureModel.getLevels());
        if (fullLevelTreeModel == null || fullLevelTreeModel.getLevelTree() == null || fullLevelTreeModel.getLevels().size() != createSalesStructureModel.getLevels().size()) {
            throw new BadDataSpmException("Cannot add levels to tree");
        }

        com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = SalesStructure.toNeo4jEntity(salesStructure);

        salesStructureNeo4jRepository.save(salesStructureEntity);

        updateSalesStructureSetUseLevelTree(SalesStructure.fromNeo4jEntity(salesStructureEntity), levelTree);

        return SalesStructure.fromNeo4jEntity(salesStructureEntity);
    }

    @Override
    public boolean updateSalesStructure(SalesStructure salesStructure) {
        if (salesStructure == null) {
            throw new BadDataSpmException("Sales structure is NULL");
        }

        BadDataSpmException.throwIfMissingId(salesStructure);

        if (salesStructure.getFromDate() != null) {
            throw new InvalidOperationSsException("Effective date can not be changed");
        }

        if (salesStructure.getToDate() != null) {
            throw new InvalidOperationSsException("Expiry date can not be updated via this method");
        }

        if (salesStructure.getApprovalStates() != null) {
            throw new InvalidOperationSsException("Approval state can not be updated via this method");
        }

        boolean anyUpdated = false;

        com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository.findById(salesStructure.getId(), 0)
                .orElseThrow(EntityNotFoundSpmException.of(salesStructure));

        if (!StringUtils.isBlank(salesStructure.getName()) && !StringUtils.equals(salesStructureEntity.getName(), salesStructure.getName())) {
            salesStructureEntity.setName(salesStructure.getName());
            anyUpdated = true;
        }

        if (!StringUtils.isBlank(salesStructure.getDescription()) && !StringUtils.equals(salesStructureEntity.getDescription(), salesStructure.getDescription())) {
            salesStructureEntity.setDescription(salesStructure.getDescription());
            anyUpdated = true;
        }

        salesStructureNeo4jRepository.save(salesStructureEntity);

        return anyUpdated;
    }

    @Override
    public void expireSalesStructure(SalesStructure salesStructure) {
        if (salesStructure == null)
            throw new BadDataSpmException("Sales structure is NULL");
        BadDataSpmException.throwIfMissingId(salesStructure);
        if (salesStructure.getToDate() == null)
            throw new BadDataSpmException("Missing expiry date of sale structure id " + salesStructure.getId());

        com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository.findById(salesStructure.getId(), 0)
                .orElseThrow(EntityNotFoundSpmException.of(salesStructure));

        if (salesStructureEntity.getToDate() != null)
            throw new InvalidOperationSsException("Sales structure already has expiry date (id: " + salesStructure.getId() + ")");

        if (!salesStructure.getToDate().after(salesStructureEntity.getFromDate()))
            throw new BadDataSpmException("Expiry date must after effective date");

        salesStructureEntity.setExpiryDate(salesStructure.getExpiryDate());

        salesStructureNeo4jRepository.save(salesStructureEntity);
    }

    @Override
    public void updateApprovalStateOfSalesStructures(Collection<SalesStructure> salesStructures, ApprovalStates newState) {
        if (CollectionUtils.isEmpty(salesStructures)) {
            throw new BadDataSpmException("Missing sales structures");
        }

        salesStructures.forEach(x -> BadDataSpmException.throwIfMissingId(x));

        if (newState == null) {
            throw new BadDataSpmException("Approval state must not be null");
        }

        if (newState == ApprovalStates.PENDING) {
            throw new BadDataSpmException("New approval state can not be PENDING");
        }

        for (SalesStructure salesStructure : salesStructures) {
            com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository.findById(salesStructure.getId(), 1)
                    .orElseThrow(EntityNotFoundSpmException.of(salesStructure));

            if (!salesStructureEntity.IsPending()) {
                throw new InvalidOperationSsException("Can only change approval state of PENDING sales structures");
            }

            if (salesStructureEntity.getFromDate() == null && newState.isApproved()) {
                throw new InvalidOperationSsException("Sales structure must have effective date in order to be approved");
            }

            if (salesStructureEntity.getUseLevelTree() == null && newState.isApproved()) {
                throw new InvalidOperationSsException("Sales structure must have level tree in order to be approved");
            }

            salesStructureEntity.setApprovalState(newState);

            salesStructureNeo4jRepository.save(salesStructureEntity);
        }
    }

    @Override
    public void updateApprovalStateOfPositions(Collection<Position> positions, ApprovalStates newState) {
        if (CollectionUtils.isEmpty(positions))
            throw new BadDataSpmException("Missing positions");

        positions.forEach(x -> BadDataSpmException.throwIfMissingId(x));

        if (newState == null)
            throw new BadDataSpmException("Approval state must not be null");

        if (newState == ApprovalStates.PENDING)
            throw new BadDataSpmException("New approval state can not be PENDING");

        for (Position position : positions) {
            com.hav.st.core.entities.neo4j.node.Position positionEntity = positionNeo4jRepository.findById(position.getId(), 1)
                    .orElseThrow(EntityNotFoundSpmException.of(position));

            if (!positionEntity.IsPending())
                throw new InvalidOperationSsException("Can only change approval state of PENDING positions");

            if (positionEntity.getHasLevel() == null && newState.isApproved())
                throw new InvalidOperationSsException("Position must have associated level in order to be approved");

            positionEntity.setApprovalState(newState);

            positionNeo4jRepository.save(positionEntity);
        }
    }

    @Override
    public void expirePositions(Collection<Position> positions) {
        for (Position position : positions) {
            if (StringUtils.isBlank(position.getId()))
                throw new BadDataSpmException("Missing position id");
            if (position.getToDate() == null)
                throw new BadDataSpmException("Missing expiry date");
        }

        if (positions.stream().anyMatch(x -> StringUtils.isBlank(x.getId())))
            throw new BadDataSpmException("Missing position id");

        for (Position position : positions) {
            com.hav.st.core.entities.neo4j.node.Position positionEntity = positionNeo4jRepository.findById(position.getId(), 0)
                    .orElseThrow(EntityNotFoundSpmException.of(position));

            if (positionEntity.getToDate() != null)
                throw new InvalidOperationSsException("Position already has expiry date (id: " + position.getId() + ")");

            if (!position.getToDate().after(positionEntity.getFromDate()))
                throw new InvalidOperationSsException("Expiry date must after effective date");

            positionEntity.setExpiryDate(position.getExpiryDate());

            positionNeo4jRepository.save(positionEntity);
        }
    }

    @Override
    public void updateSalesStructureSetUseLevelTree(SalesStructure salesStructure, LevelTree levelTree) {
        com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository.findById(salesStructure.getId())
                .orElseThrow(EntityNotFoundSpmException.of(salesStructure));
        com.hav.st.core.entities.neo4j.node.LevelTree levelTreeEntity = levelTreeNeo4jRepository.findById(levelTree.getId())
                .orElseThrow(EntityNotFoundSpmException.of(levelTree));

        if (salesStructureEntity.getUseLevelTree() != null)
            throw new InvalidOperationSsException("Sales structure already have level tree");

        if (levelTreeEntity.getUseLevelTree() != null)
            throw new InvalidOperationSsException("Level tree already attached to a sales structure");

        com.hav.st.core.entities.neo4j.relationship.UseLevelTree relUseLevelTree = new com.hav.st.core.entities.neo4j.relationship.UseLevelTree();
        relUseLevelTree.connects(salesStructureEntity, levelTreeEntity);

        useLevelTreeNeo4jRepository.save(relUseLevelTree);
    }

    @Override
    public Collection<Level> getLevelsWithinSalesStructure(SalesStructure salesStructure) {
        BadDataSpmException.throwIfMissingId(salesStructure);

        com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository
                .findById(salesStructure.getId())
                .orElseThrow(EntityNotFoundSpmException.of(salesStructure));

        return salesStructureEntity
                .getUseLevelTree().getToNode()
                .getAllContains().stream()
                .map(x -> Level.fromEntity(x.getToNode()))
                .collect(Collectors.toList());
    }

    @Override
    public FullKpiModel getKpi(Kpi kpi) {
        BadDataSpmException.throwIfMissingId(kpi);

        com.hav.st.core.entities.neo4j.node.Kpi kpiEntity = kpiNeo4jRepository.findById(kpi.getId(), 2)
                .orElseThrow(EntityNotFoundSpmException.of(com.hav.st.core.entities.neo4j.node.Kpi.class, kpi.getId()));

        return FullKpiModel.fromEntity(kpiEntity);
    }

    @Override
    public FullKpiModel createKpiForSalesStructure(UpdateKpiModel model) {

        //validation
        if (StringUtils.isBlank(model.getSalesStructureId())) {
            throw new BadDataSpmException("Missing sales structure id");
        }

        if (StringUtils.isNotBlank(model.getKpiId())) {
            throw new BadDataSpmException("KPI creation does not accept provided id");
        }

        if (StringUtils.isBlank(model.getName())) {
            throw new BadDataSpmException("Missing KPI name");
        }

        if (StringUtils.isBlank(model.getType())) {
            throw new BadDataSpmException("Missing KPI type");
        }

        if (model.getFromDate() == null) {
            throw new BadDataSpmException("Missing effective date");
        }

        if (model.getToDate() != null && !model.getFromDate().before(model.getToDate())) {
            throw new BadDataSpmException("Effective date must before expiry date");
        }

        if (CollectionUtils.isEmpty(model.getTargetValues())) {
            throw new BadDataSpmException("Missing target values");
        }

        SalesStructure salesStructure = new SalesStructure();
        salesStructure.setId(model.getSalesStructureId());

        com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureEntity = salesStructureNeo4jRepository
                .findById(salesStructure.getId(), 3)
                .orElseThrow(EntityNotFoundSpmException.of(salesStructure));

        Collection<String> levelsCode = salesStructureEntity
                .getUseLevelTree().getToNode()
                .getAllContains().stream()
                .map(x -> x.getToNode().getLevelCode())
                .collect(Collectors.toList());

        for (UpdateKpiModel.KpiByLevel targetValue : model.getTargetValues()) {
            if (StringUtils.isBlank(targetValue.getLevelCode())) {
                throw new BadDataSpmException("Missing level code");
            }
            if (!levelsCode.contains(targetValue.getLevelCode())) {
                throw new EntityNotFoundSpmException("Level code: " + targetValue.getLevelCode());
            }
        }
        // end of validation

        com.hav.st.core.entities.neo4j.node.Kpi kpi = new com.hav.st.core.entities.neo4j.node.Kpi();
        kpi.setName(model.getName());
        kpi.setDesc(model.getDesc());
        kpi.setType(model.getType());
        kpi.setFromDate(model.getFromDate());
        kpi.setToDate(model.getToDate());

        for (com.hav.st.core.entities.neo4j.node.Level level : salesStructureEntity
                .getUseLevelTree().getToNode()
                .getAllContains().stream()
                .map(x -> x.getToNode()).collect(Collectors.toList())) {

            com.hav.st.core.entities.neo4j.relationship.ApplyTo applyTo = new com.hav.st.core.entities.neo4j.relationship.ApplyTo();

            Optional<UpdateKpiModel.KpiByLevel> kpiByLevel = model.getTargetValues().stream().filter(x -> level.getLevelCode().equals(x.getLevelCode())).findFirst();
            if (kpiByLevel.isPresent()) {
                applyTo.setTarget(kpiByLevel.get().getTarget());
                applyTo.setWeight(kpiByLevel.get().getWeight());
            }

            applyTo.connects(kpi, level);

            kpi.addRelApplyTo(applyTo);
            level.addRelApplyTo(applyTo);
        }

        kpiNeo4jRepository.save(kpi);

        return FullKpiModel.fromEntity(kpi);
    }

    @Override
    public FullKpiModel updateKpiForSalesStructure(UpdateKpiModel model) {

        //validation
        if (StringUtils.isBlank(model.getSalesStructureId())) {
            throw new BadDataSpmException("Missing sales structure id");
        }

        if (StringUtils.isBlank(model.getKpiId())) {
            throw new BadDataSpmException("Require ID of target KPI");
        }

        com.hav.st.core.entities.neo4j.node.Kpi kpi = kpiNeo4jRepository.findById(model.getKpiId(), 3)
                .orElseThrow(EntityNotFoundSpmException.of(com.hav.st.core.entities.neo4j.node.Kpi.class, model.getKpiId()));

        if (kpi.getAllApplyTo().size() == 0)
            throw new BadDataSpmException("Target KPI does not refer to any node");

        SalesStructure salesStructure = new SalesStructure();
        salesStructure.setId(model.getSalesStructureId());

        com.hav.st.core.entities.neo4j.node.LevelTree levelTree = levelTreeNeo4jRepository.findById(kpi.getAllApplyTo().get(0).getToNode().getContains().getFromNode().getCid(), 2).get();
        if (!levelTree.getUseLevelTree().getFromNode().getCid().equals(salesStructure.getId())) {
            throw new InvalidOperationSsException("Target KPI does not connect to level tree of target sales structure");
        }

        List<com.hav.st.core.entities.neo4j.node.Level> levels = kpi.getAllApplyTo().get(0).getToNode().getContains()
                .getFromNode()
                .getAllContains().stream()
                .map(x -> x.getToNode())
                .collect(Collectors.toList());

        Set<String> levelCodes = levels.stream()
                .map(x -> x.getLevelCode())
                .collect(Collectors.toSet());

        if (model.getFromDate() != null && model.getFromDate() != kpi.getFromDate())
            throw new BadDataSpmException("Cannot change effective date");

        if (model.getToDate() != null && model.getToDate() != kpi.getToDate())
            throw new BadDataSpmException("Cannot change expiry date via this method");

        if (StringUtils.isNotBlank(model.getName()) && !model.getName().equals(kpi.getName())) {
            kpi.setName(model.getName());
        }

        if (StringUtils.isNotBlank(model.getDesc()) && !model.getDesc().equals(kpi.getDesc())) {
            kpi.setName(model.getDesc());
        }

        if (!CollectionUtils.isEmpty(model.getTargetValues())) {
            for (UpdateKpiModel.KpiByLevel targetValue : model.getTargetValues()) {
                if (StringUtils.isBlank(targetValue.getLevelCode())) {
                    throw new BadDataSpmException("Missing level code");
                }
                if (!levelCodes.contains(targetValue.getLevelCode())) {
                    throw new EntityNotFoundSpmException("Level code: " + targetValue.getLevelCode());
                }

                Optional<ApplyTo> relApplyToEntity = kpi.getAllApplyTo().stream().filter(x -> targetValue.getLevelCode().equals(x.getToNode().getLevelCode())).findFirst();
                if (relApplyToEntity.isPresent()) {
                    relApplyToEntity.get().setTarget(targetValue.getTarget());
                    relApplyToEntity.get().setWeight(targetValue.getWeight());
                } else {
                    com.hav.st.core.entities.neo4j.node.Level level = levels.stream().filter(x -> targetValue.getLevelCode().equals(x.getLevelCode())).findFirst().get();

                    com.hav.st.core.entities.neo4j.relationship.ApplyTo applyTo = new com.hav.st.core.entities.neo4j.relationship.ApplyTo();
                    applyTo.setTarget(targetValue.getTarget());
                    applyTo.setWeight(targetValue.getWeight());
                    applyTo.connects(kpi, level);

                    kpi.addRelApplyTo(applyTo);
                    level.addRelApplyTo(applyTo);
                }
            }
        }

        kpiNeo4jRepository.save(kpi);

        return FullKpiModel.fromEntity(kpi);
    }
}
