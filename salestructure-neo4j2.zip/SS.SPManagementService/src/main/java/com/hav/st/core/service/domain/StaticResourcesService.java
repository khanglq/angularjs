package com.hav.st.core.service.domain;

import com.hav.st.core.domain.StaticResource;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;

public interface StaticResourcesService {
    List<StaticResource> getResource(String...groups);
    List<StaticResource> findAll(Specification<com.hav.st.core.entities.pg.StaticResource> specification);
}
