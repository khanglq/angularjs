package com.hav.st.core.entities.specification;

import com.hav.st.core.entities.pg.EmploymentContract;

public class EmploymentContractSpecificationBuilder extends AbstractSpecificationBuilder<EmploymentContract, EmploymentContractSpecification> {
    @Override
    protected EmploymentContractSpecification createSpecification(SearchCriteria searchCriteria) {
        return new EmploymentContractSpecification(searchCriteria);
    }
}
