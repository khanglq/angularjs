package com.hav.st.core.service.domain.impl;

import com.hav.st.common.exceptions.EntityAlreadyExistsSsException;
import com.hav.st.common.exceptions.InvalidOperationSsException;
import com.hav.st.core.domain.Employee;
import com.hav.st.core.entities.functional.ApprovalStates;
import com.hav.st.core.exceptions.BadDataSpmException;
import com.hav.st.core.exceptions.EntityNotFoundSpmException;
import com.hav.st.core.service.db.neo4j.EmployeeNeo4jService;
import com.hav.st.core.service.db.pg.EmployeeAddressPgService;
import com.hav.st.core.service.db.pg.EmployeeBankAccountPgService;
import com.hav.st.core.service.db.pg.EmployeePgService;
import com.hav.st.core.service.domain.ApprovalService;
import com.hav.st.core.service.domain.EmployeeService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;


@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeePgService employeePgService;

    @Autowired
    private EmployeeAddressPgService employeeAddressPgService;

    @Autowired
    private EmployeeBankAccountPgService employeeBankAccountPgService;

    @Autowired
    private EmployeeNeo4jService employeeNeo4jService;

    @Autowired
    private ApprovalService approvalService;

    @Override
    public Employee add(Employee employee) {
        employee.setApprovalState(ApprovalStates.PENDING);

        validateNewEmployee(employee);

        CompletableFuture<Void> saveToPgFuture = CompletableFuture.runAsync(() -> {
            com.hav.st.core.entities.pg.Employee pgEntity = Employee.toPgEntity(employee);
            employeePgService.save(pgEntity);
            if (!CollectionUtils.isEmpty(pgEntity.getAddresses()))
                employeeAddressPgService.saveAll(pgEntity.getAddresses());
            if (!CollectionUtils.isEmpty(pgEntity.getBankAccounts()))
                employeeBankAccountPgService.saveAll(pgEntity.getBankAccounts());
        });

        CompletableFuture<Void> saveToNeo4jFuture = CompletableFuture.runAsync(() -> {
            employeeNeo4jService.save(Employee.toNeo4jEntity(employee));
        });

        CompletableFuture.allOf(saveToPgFuture, saveToNeo4jFuture).join();
        return findByEmpId(employee.getEmployeeId());
    }

    @Override
    public Page<Employee> findAll(Specification<com.hav.st.core.entities.pg.Employee> specification, Pageable pageable) {
        return employeePgService
                .findAll(specification, pageable)
                .map(this::convertPgEntityToDomain);
    }

    @Override
    public Employee findOne(Specification<com.hav.st.core.entities.pg.Employee> specification) {
        com.hav.st.core.entities.pg.Employee employeePgEntity = employeePgService.findOne(specification);
        if (employeePgEntity == null)
            return null;
        return convertPgEntityToDomain(employeePgEntity);
    }

    private Employee convertPgEntityToDomain(final com.hav.st.core.entities.pg.Employee employeePgEntity) {
        Optional<com.hav.st.core.entities.neo4j.node.Employee> neo4jEntity = employeeNeo4jService.findByEmpId(employeePgEntity.getEmployeeId());
        if (!neo4jEntity.isPresent())
            throw new EntityNotFoundSpmException("Inconsistency data across databases, employee = " + employeePgEntity.getEmployeeId());
        return Employee.fromEntity(neo4jEntity.get(), employeePgEntity);
    }

    private void validateNewEmployee(Employee employee) {
        if (employee == null) {
            throw new BadDataSpmException("Thông tin không hợp lệ (is null)");
        }

        if (StringUtils.isBlank(employee.getEmployeeId())) {
            throw new BadDataSpmException("ID nhân sự");
        }

        if (StringUtils.isBlank(employee.getSalesId())) {
            throw new BadDataSpmException("Sales ID");
        }

        if (StringUtils.isBlank(employee.getName())) {
            throw new BadDataSpmException("Tên nhân sự");
        }

        if (employee.getDateOfBirth() == null) {
            throw new BadDataSpmException("Ngày sinh");
        }

        if (StringUtils.isBlank(employee.getGender())) {
            throw new BadDataSpmException("Giới tính");
        }

        if (StringUtils.isAnyBlank(employee.getPaperType(), employee.getPaperCode(), employee.getPaperIssueLocation())) {
            throw new BadDataSpmException("Giấy tờ");
        }

        if (employee.getPaperIssueDate() == null) {
            throw new BadDataSpmException("Giấy tờ");
        }

        if (StringUtils.isBlank(employee.getManagedByCompany())) {
            throw new BadDataSpmException("Đơn vị quản lý");
        }

        if (StringUtils.isBlank(employee.getPhoneNo())) {
            throw new BadDataSpmException("Điện thoại");
        }

        if (StringUtils.isBlank(employee.getEmail())) {
            throw new BadDataSpmException("Email");
        }

        if (employeePgService.findByEmpId(employee.getEmployeeId()).isPresent()
                || employeeNeo4jService.findByEmpId(employee.getEmployeeId()).isPresent()
        ) {
            throw new EntityAlreadyExistsSsException("Nhân sự đã tốn tại: " + employee.getEmployeeId());
        }

        if (CollectionUtils.isEmpty(employee.getAddresses()))
            throw new BadDataSpmException("Cần ít nhất một địa chỉ");

        if (employee.getAddresses().stream().filter(x -> x.isDefault()).count() != 1)
            throw new BadDataSpmException("Cần 1 địa chỉ mặc định");

        if (employee.getAddresses().stream().anyMatch(x -> StringUtils.isAnyBlank(x.getType(), x.getCity(), x.getDistrict(), x.getWard(), x.getAddress())))
            throw new BadDataSpmException("Không được để trống bất kì thông tin nào thuộc mục 'Địa chỉ'");

        if (CollectionUtils.isEmpty(employee.getBankAccounts()))
            throw new BadDataSpmException("Cần ít nhất một tài khoản ngân hàng");

        if (employee.getBankAccounts().stream().filter(x -> x.isDefault()).count() != 1)
            throw new BadDataSpmException("Cần 1 tài khoản ngân hàng mặc định");

        if (employee.getBankAccounts().stream().anyMatch(x -> StringUtils.isAnyBlank(x.getBankName(), x.getCity(), x.getBranch(), x.getHolderName(), x.getHolderAccountNumber())))
            throw new BadDataSpmException("Không được để trống bất kì thông tin nào thuộc mục 'Tài khoản ngân hàng'");
    }

    @Override
    public Employee findByEmpId(String empId) {
        com.hav.st.core.entities.neo4j.node.Employee employeeNeo4jEntity = employeeNeo4jService.findByEmpId(empId)
                .orElseThrow(EntityNotFoundSpmException.of(com.hav.st.core.entities.neo4j.node.Employee.class, "empid", empId));
        com.hav.st.core.entities.pg.Employee employeePgEntity = employeePgService.findByEmpId(empId)
                .orElseThrow(EntityNotFoundSpmException.of(com.hav.st.core.entities.pg.Employee.class, "empid", empId));

        return Employee.fromEntity(employeeNeo4jEntity, employeePgEntity);
    }

    @Override
    public void updateApprovalStateOfEmployees(Collection<Employee> employees, ApprovalStates newState, String note) {
        if (CollectionUtils.isEmpty(employees)) {
            throw new BadDataSpmException("Không có nhân sự cần phê duyệt");
        }

        employees.forEach(x -> BadDataSpmException.throwIfMissingEmployeeId(x));

        if (newState == null) {
            throw new BadDataSpmException("Thiếu trạng thái phê duyệt (newState)");
        }

        if (newState == ApprovalStates.PENDING) {
            throw new BadDataSpmException("Trạng thái phê duyệt không hợp lệ (newState)");
        }

        if (newState == ApprovalStates.REJECTED && StringUtils.isBlank(note)) {
            throw new BadDataSpmException("Từ chối cần lý do");
        }

        for (Employee employee : employees) {
            com.hav.st.core.entities.pg.Employee employeeNeo4jEntity = employeePgService.findByEmpId(employee.getEmployeeId())
                    .orElseThrow(EntityNotFoundSpmException.of(com.hav.st.core.entities.pg.Employee.class, "employeeId", employee.getEmployeeId()));

            if (!employeeNeo4jEntity.IsPending()) {
                if (employeeNeo4jEntity.IsApproved())
                    throw new InvalidOperationSsException("Bản ghi đã được duyệt trước đó");
                else if (employeeNeo4jEntity.IsRejected())
                    throw new InvalidOperationSsException("Bản ghi đã bị từ chối trước đó");
                else
                    throw new InvalidOperationSsException("Bản ghi đã được phê duyệt hoặc bị từ chối trước đó");
            }

            employeeNeo4jEntity.setApprovalState(newState);

            employeePgService.save(employeeNeo4jEntity);

            approvalService.addHistory(employee.getClass(), employee.getEmployeeId(), newState, note);
        }
    }
}