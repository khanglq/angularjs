package com.hav.st.core.repository.pg;

import com.hav.st.core.entities.pg.Employee;
import com.hav.st.core.entities.pg.StaticResource;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

public interface StaticResourcesPgRepository extends JpaRepository<StaticResource, BigInteger>, JpaSpecificationExecutor<StaticResource> {
    @Query("SELECT u FROM StaticResource u WHERE u.group = :group")
    List<StaticResource> findByGroup(@Param("group") String group);

    @Query("SELECT u FROM StaticResource u WHERE u.group = :group AND u.subGroup1 = :subGroup1")
    List<StaticResource> findByGroups(@Param("group") String group, @Param("subGroup1") String subGroup1);

    @Query("SELECT u FROM StaticResource u WHERE u.group = :group AND u.subGroup1 = :subGroup1 AND u.subGroup2 = :subGroup2")
    List<StaticResource> findByGroups(@Param("group") String group, @Param("subGroup1") String subGroup1, @Param("subGroup2") String subGroup2);

    @Query("SELECT u FROM StaticResource u WHERE u.group = :group AND u.subGroup1 = :subGroup1 AND u.subGroup2 = :subGroup2 AND u.subGroup3 = :subGroup3")
    List<StaticResource> findByGroups(@Param("group") String group, @Param("subGroup1") String subGroup1, @Param("subGroup2") String subGroup2, @Param("subGroup3") String subGroup3);
}