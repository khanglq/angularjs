package com.hav.st.core.service.db.pg;

import com.hav.st.core.entities.pg.EmployeeBankAccount;
import com.hav.st.core.repository.pg.EmployeeBankAccountPgRepository;
import com.hav.st.core.service.db.GenericDbService;

import java.util.Collection;
import java.util.UUID;

public interface EmployeeBankAccountPgService extends GenericDbService<EmployeeBankAccount, UUID, EmployeeBankAccountPgRepository> {
    void saveAll(Collection<EmployeeBankAccount> EmployeeBankAccountes);
}
