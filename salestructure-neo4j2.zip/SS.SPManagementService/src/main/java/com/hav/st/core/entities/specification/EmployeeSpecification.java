package com.hav.st.core.entities.specification;

import com.hav.st.core.entities.pg.Employee;
import org.springframework.data.jpa.domain.Specification;

public class EmployeeSpecification extends AbstractSpecification<Employee> implements Specification<Employee> {
    public EmployeeSpecification(SearchCriteria criteria) {
        super(criteria);
    }
}
