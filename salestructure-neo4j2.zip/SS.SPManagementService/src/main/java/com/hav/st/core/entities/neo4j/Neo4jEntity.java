package com.hav.st.core.entities.neo4j;

import com.hav.st.common.utils.DateUtil;
import com.hav.st.core.entities.functional.ApprovalStates;
import com.hav.st.core.entities.functional.Expirable;
import com.hav.st.core.entities.functional.Neo4jIdStrategy;
import lombok.Data;
import lombok.NonNull;
import org.apache.commons.lang3.StringUtils;
import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.text.ParseException;
import java.time.Instant;
import java.util.Date;

@Data
public abstract class Neo4jEntity {

    @Id
    @GeneratedValue(strategy = Neo4jIdStrategy.class)
    protected String cid;

    protected Date createdDate;
    protected Date lastUpdatedDate;

    private String approvalStates;
    private Date fromDate;
    private Date toDate;

    public ApprovalStates getApprovalState() {
        return ApprovalStates.of(approvalStates);
    }

    public void setApprovalState(ApprovalStates state) {
        this.approvalStates = state == null ? null : state.getShortName();
    }

    public void setFromDate(Date date) {
        fromDate = date;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setToDate(Date date) {
        toDate = date;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        throw new NotImplementedException();
        /*
        try {
            setFromDate(StringUtils.isBlank(effectiveDate) ? null : DateUtil.fromString(effectiveDate));
        } catch (ParseException ex) {
            throw DateUtil.createBadDataSsExceptionWhenInvalidFormat();
        }
        */
    }

    public String getEffectiveDate() {
        throw new NotImplementedException();
        //return getFromDate() == null ? null : DateUtil.fromDate(getFromDate());
    }

    public void setExpiryDate(String expiryDate) {
        throw new NotImplementedException();
        /*
        try {
            setToDate(StringUtils.isBlank(expiryDate) ? null : DateUtil.fromString(expiryDate));
        } catch (ParseException ex) {
            throw DateUtil.createBadDataSsExceptionWhenInvalidFormat();
        }
        */
    }

    public String getExpiryDate() {
        throw new NotImplementedException();
        //return getToDate() == null ? null : DateUtil.fromDate(getToDate());
    }

    public boolean isExpired() {
        if (this instanceof Expirable == false)
            return false;
        return toDate != null && toDate.toInstant().isBefore(Instant.now());
    }

    public boolean isExpiredAt(@NonNull Date date) {
        if (this instanceof Expirable == false)
            return false;
        return toDate != null && toDate.before(date);
    }
}