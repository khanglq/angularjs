package com.hav.st.core.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import javax.validation.constraints.NotBlank;

@Data
@Configuration
@ConfigurationProperties(prefix = "postgres")
@EnableConfigurationProperties
public class PostgresProperties {

    @NotBlank
    private String driver;
    @NotBlank
    private String url;
    @NotBlank
    private String userName;
    @NotBlank
    private String password;
    private Hibernate hibernate;

    @Data
    public static class Hibernate
    {
        private String dialect;

        @Value("show_sql")
        private String showSql;

        @Value("format_sql")
        private String formatSql;

        @Value("ddl-auto")
        private String ddlAuto;

        private Jdbc jdbc;

        @Data
        public static class Jdbc
        {
            private Lob lob;

            @Data
            public static class Lob
            {
                private String non_contextual_creation;
            }
        }
    }
}
