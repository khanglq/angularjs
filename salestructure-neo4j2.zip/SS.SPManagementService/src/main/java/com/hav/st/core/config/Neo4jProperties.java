package com.hav.st.core.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import javax.validation.constraints.NotBlank;

@Data
@Configuration
@ConfigurationProperties(prefix = "neo4j")
@EnableConfigurationProperties
public class Neo4jProperties {
    @NotBlank
    private String uri;
    @NotBlank
    private String userName;
    @NotBlank
    private String password;
    private Encryption encryption;

    @Data
    public static class Encryption
    {
        private String level;
    }
}
