package com.hav.st.core.domain.relationship;

import com.hav.st.core.domain.DomainEntity;
import lombok.Data;

@Data
public class ApplyTo extends DomainEntity {
}
