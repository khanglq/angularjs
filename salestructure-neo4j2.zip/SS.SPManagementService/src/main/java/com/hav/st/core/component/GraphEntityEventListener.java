package com.hav.st.core.component;

import com.hav.st.core.entities.functional.Approvable;
import com.hav.st.core.entities.functional.ApprovalStates;
import com.hav.st.core.entities.neo4j.Neo4jEntity;
import org.neo4j.ogm.session.event.Event;
import org.neo4j.ogm.session.event.EventListener;

import java.util.Date;

public class GraphEntityEventListener implements EventListener {
    @Override
    public void onPostSave(Event event) {
        if (event.getObject() instanceof Neo4jEntity) {
            Neo4jEntity entity = (Neo4jEntity) event.getObject();
            if (entity.getCid() == null) {
                entity.setCreatedDate(new Date());
            }
            entity.setLastUpdatedDate(new Date());
        }
    }

    @Override
    public void onPreSave(Event event) {
        if (event.getObject() instanceof Neo4jEntity) {
            Neo4jEntity entity = (Neo4jEntity) event.getObject();
            if (entity.getCid() != null) {
                entity.setCreatedDate(new Date());
            }
        }

        if (event.getObject() instanceof Approvable) {
            Approvable approvable = (Approvable) event.getObject();
            if (approvable.getApprovalState() == null) {
                approvable.setApprovalState(ApprovalStates.PENDING);
            }
        }
    }

    @Override
    public void onPreDelete(Event event) {

    }

    @Override
    public void onPostDelete(Event event) {

    }
}
