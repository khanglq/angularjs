package com.hav.st.core.service.domain;

import com.hav.st.core.domain.ApprovalHistory;
import com.hav.st.core.entities.functional.ApprovalStates;

public interface ApprovalService {
    ApprovalHistory addHistory(Class<?> clz, String id, ApprovalStates status, String note);
}
