package com.hav.st.core.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
public class UnsetManagementModel {

    private List<RelInfo> relationshipsInfo;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RelInfo
    {
        private String fromSalesId;
        private String toSalesId;
        private Date expiryDate;
    }
}
