package com.hav.st.core.entities.pg;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

@Data
@Entity
@Table(name = "dim_employee_bank_account")
public class EmployeeBankAccount extends PostgresEntity {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "pk_id", updatable = false, nullable = false)
    private BigInteger id;

    @ManyToOne
    @JoinColumn(name = "fk_employee_id")
    private Employee employee;

    @NotNull
    @Column(name = "bank_name", nullable = false)
    private String bankName;

    @NotNull
    @Column(name = "city", nullable = false)
    private String city;

    @NotNull
    @Column(name = "branch", nullable = false)
    private String branch;

    @NotNull
    @Column(name = "holder_name", nullable = false)
    private String holderName;

    @NotNull
    @Column(name = "holder_account_no", nullable = false)
    private String holderAccountNo;

    @Column(name = "is_default")
    private boolean isDefault;
}
