package com.hav.st.core.entities.neo4j.node;

import com.hav.st.core.entities.neo4j.Neo4jEntity;
import lombok.Data;
import org.neo4j.ogm.annotation.NodeEntity;

@Data
@NodeEntity
public abstract class EntityNode extends Neo4jEntity {

}
