package com.hav.st.core.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collection;
import java.util.Date;

@Data
public class UpdateKpiModel {
    private String salesStructureId;
    private String kpiId;
    private String name;
    private String desc;
    private String type;
    private Date fromDate;
    private Date toDate;
    private Collection<KpiByLevel> targetValues;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class KpiByLevel
    {
        private String levelCode;
        private double target;
        private double weight;
    }
}
