package com.hav.st.core.service.domain;

import com.hav.st.core.domain.Employee;
import com.hav.st.core.domain.Kpi;
import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import com.hav.st.core.domain.Position;
import com.hav.st.core.domain.SalesStructure;
import com.hav.st.core.domain.relationship.IsManagerOf;
import com.hav.st.core.entities.functional.ApprovalStates;
import com.hav.st.core.models.CreateSalesStructureModel;
import com.hav.st.core.models.FullKpiModel;
import com.hav.st.core.models.FullSalesStructureModel;
import com.hav.st.core.models.SetManagementModel;
import com.hav.st.core.models.UpdateKpiModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import java.util.Collection;

public interface SalesStructureService {
    Page<SalesStructure> findAll(Specification<com.hav.st.core.entities.neo4j.node.SalesStructure> specification, Pageable pageable);
    Collection<Position> addPositionsIntoSalesStructure(SalesStructure salesStructure, Collection<Position> positions);
    void addManagementRelationship(SetManagementModel model);
    void approveManagementRelationships(Collection<IsManagerOf> relationships, ApprovalStates newState);
    void expireManagementRelationship(IsManagerOf isManagerOf);
    SalesStructure getSalesStructure(SalesStructure salesStructure);
    FullSalesStructureModel getFullSalesStructure(SalesStructure salesStructure);
    SalesStructure createSalesStructure(CreateSalesStructureModel createSalesStructureModel);
    boolean updateSalesStructure(SalesStructure salesStructure);
    void expireSalesStructure(SalesStructure salesStructure);
    void updateApprovalStateOfSalesStructures(Collection<SalesStructure> salesStructures, ApprovalStates newState);
    void updateApprovalStateOfPositions(Collection<Position> positions, ApprovalStates newState);
    void expirePositions(Collection<Position> positions);
    void updateSalesStructureSetUseLevelTree(SalesStructure salesStructure, LevelTree levelTree);
    Collection<Level> getLevelsWithinSalesStructure(SalesStructure salesStructure);
    FullKpiModel getKpi(Kpi kpi);
    FullKpiModel createKpiForSalesStructure(UpdateKpiModel model);
    FullKpiModel updateKpiForSalesStructure(UpdateKpiModel model);
}
