package com.hav.st.core.domain;

import com.hav.st.core.entities.functional.Approvable;
import lombok.Data;

import java.util.Date;

@Data
public class ApprovalHistory extends DomainEntity implements Approvable {

    private ApprovalReference reference;
    private String note;
    private Date createdDate;

    public void setReference(Class<?> clz, String id) {
        ApprovalReference reference = new ApprovalReference();
        reference.setType(clz.getName());
        reference.setId(id);
        this.reference = reference;
    }

    @Data
    public static class ApprovalReference {
        private String type;
        private String id;
    }

    public static com.hav.st.core.entities.pg.ApprovalHistory toPgEntity(ApprovalHistory approvalHistory) {
        com.hav.st.core.entities.pg.ApprovalHistory pgEntity = new com.hav.st.core.entities.pg.ApprovalHistory();
        pgEntity.setReferenceType(approvalHistory.getReference().getType());
        pgEntity.setReferenceId(approvalHistory.getReference().getId());
        pgEntity.setStatus(approvalHistory.getApprovalStates());
        pgEntity.setNote(approvalHistory.getNote());
        pgEntity.setCreatedDate(approvalHistory.getCreatedDate());
        return pgEntity;
    }

    public static ApprovalHistory fromEntity(com.hav.st.core.entities.pg.ApprovalHistory approvalHistoryPgEntity) {
        ApprovalHistory domainEntity = new ApprovalHistory();
        domainEntity.setReference(new ApprovalReference());
        domainEntity.getReference().setType(approvalHistoryPgEntity.getReferenceType());
        domainEntity.getReference().setId(approvalHistoryPgEntity.getReferenceId());
        domainEntity.setNote(approvalHistoryPgEntity.getNote());
        domainEntity.setCreatedDate(approvalHistoryPgEntity.getCreatedDate());
        return domainEntity;
    }
}
