package com.hav.st.core.repository.pg;

import com.hav.st.core.entities.pg.EmployeeAddress;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface EmployeeAddressPgRepository extends JpaRepository<EmployeeAddress, UUID> {
}
