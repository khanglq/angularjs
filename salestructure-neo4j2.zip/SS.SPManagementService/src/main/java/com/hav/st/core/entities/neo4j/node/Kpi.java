package com.hav.st.core.entities.neo4j.node;

import com.hav.st.core.entities.neo4j.relationship.ApplyTo;
import lombok.Data;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import java.util.ArrayList;
import java.util.List;

@Data
@NodeEntity(label = "Kpi")
public class Kpi extends EntityNode {
    private String name;
    private String desc;
    private String type;

    @Relationship(type = "APPLY_TO")
    private List<ApplyTo> allApplyTo;

    public void addRelApplyTo(ApplyTo applyTo) {
        if (allApplyTo == null) {
            allApplyTo = new ArrayList<>();
        }
        allApplyTo.add(applyTo);
    }
}
