package com.hav.st.core.service.db.pg.impl;

import com.hav.st.core.entities.pg.EmployeeBankAccount;
import com.hav.st.core.repository.pg.EmployeeBankAccountPgRepository;
import com.hav.st.core.service.db.GenericDbServiceImpl;
import com.hav.st.core.service.db.pg.EmployeeBankAccountPgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
@Transactional("jpaTransactionManager")
public class EmployeeBankAccountPgServiceImpl extends GenericDbServiceImpl<EmployeeBankAccount, UUID, EmployeeBankAccountPgRepository> implements EmployeeBankAccountPgService {

    @Autowired
    private EmployeeBankAccountPgRepository repository;

    @Override
    protected EmployeeBankAccountPgRepository getRepository() {
        return repository;
    }
}
