package com.hav.st.core.entities.pg;

import com.hav.st.core.entities.functional.Approvable;
import com.hav.st.core.entities.functional.ApprovalStates;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;
import java.util.Collection;
import java.util.Date;

@Data
@Entity
@Table(name = "dim_employee")
public class Employee extends PostgresEntity implements Approvable {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "pk_id", updatable = false, nullable = false)
    private BigInteger id;

    @NotNull
    @Column(name = "empid", nullable = false)
    private String employeeId;

    @NotNull
    @Column(name = "sales_id", nullable = false)
    private String salesId;

    @NotNull
    @Column(name = "approval_states", nullable = false)
    private String approvalStates;

    @NotNull
    @Column(name = "name", nullable = false)
    private String name;

    @NotNull
    @Column(name = "dob", nullable = false)
    private Date dateOfBirth;

    @NotNull
    @Column(name = "gender", nullable = false)
    private String gender;

    @NotNull
    @Column(name = "paper_type", nullable = false)
    private String paperType;

    @NotNull
    @Column(name = "paper_code", nullable = false)
    private String paperCode;

    @Column(name = "paper_code_normalized")
    private String paperCodeNormalized;

    @NotNull
    @Column(name = "paper_issue_date", nullable = false)
    private Date paperIssueDate;

    @NotNull
    @Column(name = "paper_issue_location", nullable = false)
    private String paperIssueLocation;

    @NotNull
    @Column(name = "managed_by_company", nullable = false)
    private String managedByCompany;

    @NotNull
    @Column(name = "emp_group", nullable = false)
    private String group;

    @NotNull
    @Column(name = "department", nullable = false)
    private String department;

    @NotNull
    @Column(name = "branch", nullable = false)
    private String branch;

    @NotNull
    @Column(name = "email", nullable = false)
    private String email;

    @NotNull
    @Column(name = "phone_no", nullable = false)
    private String phoneNo;

    @Column(name = "phone_no_normalized")
    private String phoneNoNormalized;

    @Column(name = "note", length = 1000)
    private String note;

    @OneToMany(mappedBy = "employee")
    private Collection<EmployeeAddress> addresses;

    @OneToMany(mappedBy = "employee")
    private Collection<EmployeeBankAccount> bankAccounts;

    public void setPaperCodeAndNormalizeIt(String paperCode) {
        this.setPaperCode(paperCode);
        if (paperCode == null)
            this.setPaperCodeNormalized(null);
        else
            this.setPaperCodeNormalized(paperCode.toUpperCase().replaceAll("[^0-9A-Z]", ""));
    }

    public void setPhoneNoAndNormalizeIt(String phoneNumber) {
        this.setPhoneNo(phoneNumber);
        if (phoneNumber == null)
            this.setPhoneNoNormalized(null);
        else
            this.setPhoneNoNormalized(phoneNumber.replaceAll("[^0-9]", ""));
    }

    @Override
    public ApprovalStates getApprovalState() {
        return ApprovalStates.of(approvalStates);
    }

    @Override
    public void setApprovalState(ApprovalStates state) {
        this.approvalStates = state == null ? null : state.getShortName();
    }
}