package com.hav.st.core.service.domain.impl;

import com.hav.st.core.domain.StaticResource;
import com.hav.st.core.exceptions.BadDataSpmException;
import com.hav.st.core.repository.pg.StaticResourcesPgRepository;
import com.hav.st.core.service.domain.StaticResourcesService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Transactional
@Service
public class StaticResourcesServiceImpl implements StaticResourcesService {

    @Autowired
    private StaticResourcesPgRepository staticResourcesPgRepository;

    private final Map<String, List<StaticResource>> cache = new HashMap<>();

    @Override
    public List<StaticResource> getResource(String... groups) {
        List<String> preworkedGroups = Arrays.asList(groups)
                .stream()
                .filter(x -> StringUtils.isNotBlank(x))
                .map(x -> x.trim())
                .collect(Collectors.toList());

        if (preworkedGroups.size() < 1)
            throw new BadDataSpmException("Cần thông tin group");

        String cacheKey = buildCacheKey(preworkedGroups);

        if (cache.containsKey(cacheKey))
            return cache.get(cacheKey);

        List<com.hav.st.core.entities.pg.StaticResource> resources;
        if (preworkedGroups.size() == 1)
            resources = staticResourcesPgRepository.findByGroup(preworkedGroups.get(0));
        else if (preworkedGroups.size() == 2)
            resources = staticResourcesPgRepository.findByGroups(preworkedGroups.get(0), preworkedGroups.get(1));
        else if (preworkedGroups.size() == 3)
            resources = staticResourcesPgRepository.findByGroups(preworkedGroups.get(0), preworkedGroups.get(1), preworkedGroups.get(2));
        else if (preworkedGroups.size() == 4)
            resources = staticResourcesPgRepository.findByGroups(preworkedGroups.get(0), preworkedGroups.get(1), preworkedGroups.get(2), preworkedGroups.get(3));
        else
            throw new BadDataSpmException("Sai số lượng group");
        List<StaticResource> result = resources.stream()
                .map(StaticResource::fromEntity)
                .collect(Collectors.toList());
        if (result.size() < 1)
            return result;

        cache.put(cacheKey, result);

        return result;
    }

    private String buildCacheKey(List<String> preworkedGroups) {
        StringBuilder sbKey = new StringBuilder();
        sbKey.append(preworkedGroups.get(0));
        sbKey.append(',');
        if (preworkedGroups.size() > 1)
            sbKey.append(preworkedGroups.get(1));
        sbKey.append(',');
        if (preworkedGroups.size() > 2)
            sbKey.append(preworkedGroups.get(2));
        sbKey.append(',');
        if (preworkedGroups.size() > 3)
            sbKey.append(preworkedGroups.get(3));
        return sbKey.toString();
    }

    @Override
    public List<StaticResource> findAll(Specification<com.hav.st.core.entities.pg.StaticResource> specification) {
        return staticResourcesPgRepository
                .findAll(specification)
                .stream()
                .map(StaticResource::fromEntity)
                .collect(Collectors.toList());
    }
}
