package com.hav.st.core.entities.pg;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigInteger;

@Data
@Entity
@Table(name = "dim_static_resources")
public class StaticResource extends PostgresEntity {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "pk_id", updatable = false, nullable = false)
    private BigInteger id;

    @Column(name = "group", updatable = false, nullable = false, length = 30)
    private String group;

    @Column(name = "sub_group_1", updatable = false, length = 50)
    private String subGroup1;

    @Column(name = "sub_group_2", updatable = false, length = 50)
    private String subGroup2;

    @Column(name = "sub_group_3", updatable = false, length = 50)
    private String subGroup3;

    @Column(name = "value", updatable = false, nullable = false, length = 50)
    private String value;

    @Column(name = "description", updatable = false, nullable = false, length = 255)
    private String description;
}
