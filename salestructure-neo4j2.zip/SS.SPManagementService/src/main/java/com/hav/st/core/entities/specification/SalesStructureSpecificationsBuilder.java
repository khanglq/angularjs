package com.hav.st.core.entities.specification;

import com.hav.st.core.entities.neo4j.node.SalesStructure;

public class SalesStructureSpecificationsBuilder extends AbstractSpecificationBuilder<SalesStructure, SalesStructureSpecification> {
    @Override
    protected SalesStructureSpecification createSpecification(SearchCriteria searchCriteria) {
        return new SalesStructureSpecification(searchCriteria);
    }
}