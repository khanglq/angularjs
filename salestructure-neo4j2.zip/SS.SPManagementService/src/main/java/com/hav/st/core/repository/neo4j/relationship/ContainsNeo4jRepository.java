package com.hav.st.core.repository.neo4j.relationship;

import com.hav.st.core.entities.neo4j.relationship.Contains;
import org.springframework.data.neo4j.repository.Neo4jRepository;

public interface ContainsNeo4jRepository extends Neo4jRepository<Contains, String> {
}
