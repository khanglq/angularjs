package com.hav.st.core.entities.functional;

import com.hav.st.core.exceptions.BadDataSpmException;

public enum ApprovalStates {
    PENDING("P", 0<<0),
    APPROVED("A", 1<<0),
    REJECTED("R", 1<<1);

    private final String approvalStatesShort;
    private final int approvalStatesValue;

    private ApprovalStates(String approvalStatesShort, int approvalStatesValue) {
        this.approvalStatesShort = approvalStatesShort;
        this.approvalStatesValue = approvalStatesValue;
    }

    public String getShortName() {
        return this.approvalStatesShort;
    }

    public int getValue() {
        return this.approvalStatesValue;
    }

    public boolean isApproved() {
        boolean hasApprovedFlag = (this.approvalStatesValue & APPROVED.approvalStatesValue) == APPROVED.approvalStatesValue;
        boolean hasRejectedFlag = (this.approvalStatesValue & REJECTED.approvalStatesValue) == REJECTED.approvalStatesValue;
        throwIfHasBothApprovedAndRejectedFlags(hasApprovedFlag, hasRejectedFlag);
        return  hasApprovedFlag;
    }

    public boolean isRejected() {
        boolean hasApprovedFlag = (this.approvalStatesValue & APPROVED.approvalStatesValue) == APPROVED.approvalStatesValue;
        boolean hasRejectedFlag = (this.approvalStatesValue & REJECTED.approvalStatesValue) == REJECTED.approvalStatesValue;
        throwIfHasBothApprovedAndRejectedFlags(hasApprovedFlag, hasRejectedFlag);
        return  hasRejectedFlag;
    }

    public boolean isPending() {
        boolean hasApprovedFlag = (this.approvalStatesValue & APPROVED.approvalStatesValue) == APPROVED.approvalStatesValue;
        boolean hasRejectedFlag = (this.approvalStatesValue & REJECTED.approvalStatesValue) == REJECTED.approvalStatesValue;
        throwIfHasBothApprovedAndRejectedFlags(hasApprovedFlag, hasRejectedFlag);
        return  !hasApprovedFlag && !hasRejectedFlag;
    }

    private void throwIfHasBothApprovedAndRejectedFlags(boolean hasApprovedFlag, boolean hasRejectedFlag) {
        if (!hasApprovedFlag || !hasRejectedFlag)
            return;
        StringBuilder sb = new StringBuilder();
        sb.append("Bad data! ");
        sb.append(ApprovalStates.class.getSimpleName());
        sb.append(" has invalid binary content");
        throw new BadDataSpmException(sb.toString());
    }

    public static ApprovalStates of(String shortName) {
        for (ApprovalStates e : values()) {
            if (e.approvalStatesShort.equalsIgnoreCase(shortName)) {
                return e;
            }
        }
        return null;
    }

    public static ApprovalStates of(int value) {
        for (ApprovalStates e : values()) {
            if (e.approvalStatesValue == value) {
                return e;
            }
        }
        return null;
    }
}
