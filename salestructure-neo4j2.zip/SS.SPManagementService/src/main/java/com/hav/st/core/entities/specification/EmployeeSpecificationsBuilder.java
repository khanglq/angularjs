package com.hav.st.core.entities.specification;

import com.hav.st.core.entities.pg.Employee;

public class EmployeeSpecificationsBuilder extends AbstractSpecificationBuilder<Employee, EmployeeSpecification> {
    @Override
    protected EmployeeSpecification createSpecification(SearchCriteria searchCriteria) {
        return new EmployeeSpecification(searchCriteria);
    }
}