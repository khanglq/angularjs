package com.hav.st.core.service.db;

import org.springframework.data.repository.CrudRepository;

import java.util.Collection;

public abstract class GenericDbServiceImpl<T, ID, TRepo extends CrudRepository<T, ID>> implements GenericDbService<T, ID, TRepo> {
    protected abstract TRepo getRepository();

    @Override
    public void save(T entity) {
        getRepository().save(entity);
    }

    @Override
    public void saveAll(Collection<T> entities) {
        getRepository().saveAll(entities);
    }
}