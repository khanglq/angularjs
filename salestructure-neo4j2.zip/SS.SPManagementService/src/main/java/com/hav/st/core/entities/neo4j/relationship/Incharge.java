package com.hav.st.core.entities.neo4j.relationship;

import com.hav.st.core.entities.functional.Expirable;
import com.hav.st.core.entities.neo4j.node.Employee;
import com.hav.st.core.entities.neo4j.node.Position;
import lombok.Data;
import org.neo4j.ogm.annotation.RelationshipEntity;

@Data
@RelationshipEntity(type = "INCHARGE")
public class Incharge extends EntityRelationship<Employee, Position> implements Expirable {

}