package com.hav.st.core.models;

import lombok.Data;

@Data
public class LinkingModel<TFrom, TTo> {
    private TFrom from;
    private TTo to;
}
