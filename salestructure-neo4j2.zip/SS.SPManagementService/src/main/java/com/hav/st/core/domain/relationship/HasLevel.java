package com.hav.st.core.domain.relationship;

import com.hav.st.core.domain.DomainEntity;
import lombok.Data;

@Data
public class HasLevel extends DomainEntity {
    private String fromPositionId;
    private String toLevelId;

    public static HasLevel fromNeo4jEntity(com.hav.st.core.entities.neo4j.relationship.HasLevel entity) {
        HasLevel domain = new HasLevel();
        domain.setId(entity.getCid());

        domain.setFromPositionId(entity.getFromNode().getCid());
        domain.setToLevelId(entity.getToNode().getCid());
        return domain;
    }
}