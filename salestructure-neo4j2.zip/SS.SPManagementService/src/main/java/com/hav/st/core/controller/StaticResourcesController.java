package com.hav.st.core.controller;

import com.hav.st.common.dto.ResponseMessageOnSuccess;
import com.hav.st.core.domain.StaticResource;
import com.hav.st.core.entities.specification.StaticResourceSpecificationBuilder;
import com.hav.st.core.service.domain.StaticResourcesService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Api(value = "static", tags = {"/static v1"}, description = "Static resources")
@RestController
@RequestMapping("/api/v1/static")
public class StaticResourcesController extends BaseController {
    @Autowired
    private StaticResourcesService staticResourcesService;

    @ApiOperation(value = "Get static resources of specific group")
    @GetMapping("/{group}")
    public ResponseEntity<ResponseMessageOnSuccess<List<StaticResource>>> getStaticResourcesOfGroup(
            @PathVariable("group") String group,
            @RequestParam(value = "sub", required = false) Set<String> subGroups
    ) {
        List<StaticResource> result;
        if (CollectionUtils.isEmpty(subGroups)) {
            result = staticResourcesService.getResource(group);
        } else {
            ArrayList<String> groups = new ArrayList<>();
            groups.add(group);
            groups.addAll(subGroups);
            result = staticResourcesService.getResource(groups.toArray(new String[groups.size()]));
        }
        return ok(result);
    }

    @ApiOperation(value = "Get static resource of specific group using filter")
    @GetMapping(params = "cmd=search")
    public ResponseEntity<ResponseMessageOnSuccess<List<StaticResource>>> searchStaticResources(
            @RequestParam(value = "filter") String filter) {

        StaticResourceSpecificationBuilder builder = new StaticResourceSpecificationBuilder();
        applyFiltersIntoSpecificationBuilder(filter, builder);

        Specification<com.hav.st.core.entities.pg.StaticResource> build = builder.build();
        if (build == null)
            return ok(new ArrayList<>());
        
        return ok(staticResourcesService.findAll(build));
    }
}
