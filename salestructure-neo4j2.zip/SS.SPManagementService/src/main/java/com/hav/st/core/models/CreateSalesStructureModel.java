package com.hav.st.core.models;

import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.SalesStructure;
import lombok.Data;

import java.util.Collection;

@Data
public class CreateSalesStructureModel {
    private SalesStructure salesStructure;
    private Collection<Level> levels;
}