package com.hav.st.core.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.Properties;

@Configuration
@EnableJpaRepositories(
        basePackages = "com.hav.st.core.repository.pg",
        entityManagerFactoryRef = "jpaEntityManagerFactory",
        transactionManagerRef = "jpaTransactionManager"
)
@EnableTransactionManagement
public class PgConfiguration {

    @Autowired
    private PostgresProperties postgresProperties;

    @Bean
    @Primary
    public LocalSessionFactoryBean jpaEntityManagerFactory() {
        LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
        sessionFactory.setDataSource(dataSource());
        sessionFactory.setPackagesToScan(new String[]{
                "com.hav.st.core.entities.pg"
        });
        sessionFactory.setHibernateProperties(hibernateProperties());
        return sessionFactory;
    }

    @Bean
    @Primary
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(postgresProperties.getDriver());
        dataSource.setUrl(postgresProperties.getUrl());
        dataSource.setUsername(postgresProperties.getUserName());
        dataSource.setPassword(postgresProperties.getPassword());
        return dataSource;
    }

    private Properties hibernateProperties() {
        PostgresProperties.Hibernate hibernate = postgresProperties.getHibernate();

        Properties properties = new Properties();
        properties.put("hibernate.dialect", hibernate.getDialect());
        properties.put("hibernate.show_sql", hibernate.getShowSql());
        properties.put("hibernate.format_sql", hibernate.getFormatSql());
        properties.put("hibernate.ddl-auto", hibernate.getDdlAuto());
        properties.put("hibernate.jdbc.lob.non_contextual_creation", hibernate.getJdbc().getLob().getNon_contextual_creation());
        return properties;
    }

    @Bean
    @Primary
    public PlatformTransactionManager jpaTransactionManager(EntityManagerFactory jpaEntityManagerFactory) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(jpaEntityManagerFactory);
        return transactionManager;
    }
}
