package com.hav.st.core.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hav.st.common.utils.DateUtil;
import com.hav.st.core.entities.functional.Approvable;
import com.hav.st.core.entities.functional.Expirable;
import com.hav.st.core.entities.pg.EmployeeAddress;
import com.hav.st.core.entities.pg.EmployeeBankAccount;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Data
public class Employee extends DomainEntity implements Expirable, Approvable {

    @NotNull
    private String employeeId; // mã nhân viên

    @NotNull
    private String salesId; // Sales ID

    @NotNull
    private String name; // tên

    @NotNull
    @JsonIgnore
    private Date dateOfBirth; // ngày sinh

    public void setDob(String dob) {
        try {
            this.dateOfBirth = DateUtil.fromString(dob);
        } catch (ParseException ex) {
            throw DateUtil.createBadDataSsExceptionWhenInvalidFormat();
        }
    }

    public String getDob() {
        return DateUtil.fromDate(this.dateOfBirth);
    }

    @NotNull
    private String gender; // giới tính

    @NotNull
    private String paperType; // loại giấy tờ

    @NotNull
    private String paperCode; // số giấy tờ

    @NotNull
    @JsonIgnore
    private Date paperIssueDate; // ngày phát hành

    public void setPid(String pid) {
        try {
            this.paperIssueDate = DateUtil.fromString(pid);
        } catch (ParseException ex) {
            throw DateUtil.createBadDataSsExceptionWhenInvalidFormat();
        }
    }

    public String getPid() {
        return DateUtil.fromDate(this.paperIssueDate);
    }

    @NotNull
    private String paperIssueLocation; // nơi phát hành

    @NotNull
    private String managedByCompany; // đơn vị quản lý

    private String group; // nhóm nhân sự

    private String department; // phòng ban

    private String branch; // chi nhánh

    @NotNull
    private String phoneNo; // số điện thoại

    @NotNull
    private String email; // email

    private String note; // ghi chú

    @NotEmpty
    private List<AddressInfo> addresses;

    @NotEmpty
    private List<BankAccountInfo> bankAccounts;

    public static com.hav.st.core.entities.pg.Employee toPgEntity(Employee employee) {
        com.hav.st.core.entities.pg.Employee employeeEntity = new com.hav.st.core.entities.pg.Employee();
        employeeEntity.setEmployeeId(employee.getEmployeeId());
        employeeEntity.setSalesId(employee.getSalesId());
        employeeEntity.setName(employee.getName());
        employeeEntity.setApprovalState(employee.getApprovalState());
        employeeEntity.setDateOfBirth(employee.getDateOfBirth());
        employeeEntity.setGender(employee.getGender());
        employeeEntity.setPaperType(employee.getPaperType());
        employeeEntity.setPaperCodeAndNormalizeIt(employee.getPaperCode());
        employeeEntity.setPaperIssueDate(employee.getPaperIssueDate());
        employeeEntity.setPaperIssueLocation(employee.getPaperIssueLocation());
        employeeEntity.setManagedByCompany(employee.getManagedByCompany());
        employeeEntity.setGroup(employee.getGroup());
        employeeEntity.setDepartment(employee.getDepartment());
        employeeEntity.setBranch(employee.getBranch());
        employeeEntity.setPhoneNoAndNormalizeIt(employee.getPhoneNo());
        employeeEntity.setEmail(employee.getEmail());
        employeeEntity.setNote(employee.getNote());

        if (employee.getAddresses() != null)
            employeeEntity.setAddresses(employee.getAddresses().stream().map(x -> {
                EmployeeAddress addr = new EmployeeAddress();
                addr.setDefault(x.isDefault());
                addr.setEmployee(employeeEntity);
                addr.setType(x.getType());
                addr.setCity(x.getCity());
                addr.setDistrict(x.getDistrict());
                addr.setWard(x.getWard());
                addr.setAddress(x.getAddress());
                return addr;
            }).collect(Collectors.toList()));

        if (employee.getBankAccounts() != null)
            employeeEntity.setBankAccounts(employee.getBankAccounts().stream().map(x -> {
                EmployeeBankAccount acc = new EmployeeBankAccount();
                acc.setDefault(x.isDefault());
                acc.setEmployee(employeeEntity);
                acc.setBankName(x.getBankName());
                acc.setCity(x.getCity());
                acc.setBranch(x.getBranch());
                acc.setHolderName(x.getHolderName());
                acc.setHolderAccountNo(x.getHolderAccountNumber());
                return acc;
            }).collect(Collectors.toList()));

        return employeeEntity;
    }

    public static com.hav.st.core.entities.neo4j.node.Employee toNeo4jEntity(Employee employee) {
        com.hav.st.core.entities.neo4j.node.Employee nodeEmployeeEntity = new com.hav.st.core.entities.neo4j.node.Employee();
        nodeEmployeeEntity.setEmployeeId(employee.getEmployeeId());
        nodeEmployeeEntity.setSalesId(employee.getSalesId());
        nodeEmployeeEntity.setFromDate(employee.getFromDate());
        return nodeEmployeeEntity;
    }

    public static Employee fromEntity(com.hav.st.core.entities.neo4j.node.Employee employeeNeo4jEntity, com.hav.st.core.entities.pg.Employee employeePgEntity) {
        Employee employee = new Employee();
        employee.setId(employeeNeo4jEntity.getCid());

        // copy from neo4j
        employee.setEmployeeId(employeeNeo4jEntity.getEmployeeId());
        employee.setSalesId(employeeNeo4jEntity.getSalesId());
        employee.setFromDate(employeeNeo4jEntity.getFromDate());

        // copy from pg
        employee.setName(employeePgEntity.getName());
        employee.setApprovalState(employeePgEntity.getApprovalState());
        employee.setDateOfBirth(employeePgEntity.getDateOfBirth());
        employee.setGender(employeePgEntity.getGender());
        employee.setPaperType(employeePgEntity.getPaperType());
        employee.setPaperCode(employeePgEntity.getPaperCode());
        employee.setPaperIssueDate(employeePgEntity.getPaperIssueDate());
        employee.setPaperIssueLocation(employeePgEntity.getPaperIssueLocation());
        employee.setManagedByCompany(employeePgEntity.getManagedByCompany());
        employee.setGroup(employeePgEntity.getGroup());
        employee.setDepartment(employeePgEntity.getDepartment());
        employee.setBranch(employeePgEntity.getBranch());
        employee.setPhoneNo(employeePgEntity.getPhoneNo());
        employee.setEmail(employeePgEntity.getEmail());
        employee.setNote(employeePgEntity.getNote());

        if (employeePgEntity.getAddresses() != null)
            employee.setAddresses(employeePgEntity.getAddresses().stream().map(x -> {
                AddressInfo addressInfo = new AddressInfo();
                addressInfo.setDefault(x.isDefault());
                addressInfo.setType(x.getType());
                addressInfo.setCity(x.getCity());
                addressInfo.setDistrict(x.getDistrict());
                addressInfo.setWard(x.getWard());
                addressInfo.setAddress(x.getAddress());
                return addressInfo;
            }).collect(Collectors.toList()));

        if (employeePgEntity.getBankAccounts() != null)
            employee.setBankAccounts(employeePgEntity.getBankAccounts().stream().map(x -> {
                BankAccountInfo accountInfo = new BankAccountInfo();
                accountInfo.setDefault(x.isDefault());
                accountInfo.setBankName(x.getBankName());
                accountInfo.setCity(x.getCity());
                accountInfo.setBranch(x.getBranch());
                accountInfo.setHolderName(x.getHolderName());
                accountInfo.setHolderAccountNumber(x.getHolderAccountNo());
                return accountInfo;
            }).collect(Collectors.toList()));

        return employee;
    }

    @Data
    public static class AddressInfo {
        @JsonProperty("default")
        private boolean isDefault;
        private String type;
        private String city;
        private String district;
        private String ward;
        private String address;
    }

    @Data
    public static class BankAccountInfo {
        @JsonProperty("default")
        private boolean isDefault;
        private String bankName;
        private String city;
        private String branch;
        private String holderName;
        private String holderAccountNumber;
    }
}
