package com.hav.st.core.repository.pg;

import com.hav.st.core.entities.pg.EmployeeBankAccount;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface EmployeeBankAccountPgRepository extends JpaRepository<EmployeeBankAccount, UUID> {
}
