package com.hav.st.core.repository.pg;

import com.hav.st.core.entities.pg.EmploymentContract;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.math.BigInteger;

public interface EmploymentContractPgRepository extends JpaRepository<EmploymentContract, BigInteger>, JpaSpecificationExecutor<EmploymentContract> {
}
