package com.hav.st.core.exceptions;

import com.hav.st.common.exceptions.EntityNotFoundSsException;
import com.hav.st.core.domain.DomainEntity;

import java.util.function.Supplier;

public class EntityNotFoundSpmException extends EntityNotFoundSsException {
    public EntityNotFoundSpmException(String s) {
        super(s);
    }

    public static Supplier<EntityNotFoundSsException> of(DomainEntity domain) {
        return of(domain.getClass(), "cid", domain.getId());
    }

    public static Supplier<EntityNotFoundSsException> ofPosition(String propertyName, Object value) {
        return of(com.hav.st.core.entities.neo4j.node.Position.class, propertyName, value);
    }

    public static Supplier<EntityNotFoundSsException> of(Class clz, Object rid) {
        return of(clz, "cid", rid);
    }

    public static Supplier<EntityNotFoundSsException> of(Class clz, String propertyName, Object value) {
        return msg(clz.getSimpleName() + " with " + propertyName + " = '" + value + "' could not be found");
    }

    public static Supplier<EntityNotFoundSsException> msg(String message) {
        return () -> new EntityNotFoundSpmException(message);
    }
}
