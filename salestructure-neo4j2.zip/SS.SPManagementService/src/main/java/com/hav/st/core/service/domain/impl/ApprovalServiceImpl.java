package com.hav.st.core.service.domain.impl;

import com.hav.st.common.utils.DateUtil;
import com.hav.st.core.domain.ApprovalHistory;
import com.hav.st.core.entities.functional.ApprovalStates;
import com.hav.st.core.exceptions.BadDataSpmException;
import com.hav.st.core.repository.pg.ApprovalHistoryPgRepository;
import com.hav.st.core.service.domain.ApprovalService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Transactional
@Service
public class ApprovalServiceImpl implements ApprovalService {

    @Autowired
    private ApprovalHistoryPgRepository approvalHistoryPgRepository;

    @Override
    public ApprovalHistory addHistory(Class<?> clz, String id, ApprovalStates status, String note) {
        if (status != ApprovalStates.APPROVED && status != ApprovalStates.REJECTED)
            throw new BadDataSpmException("Trạng thái duyệt không hợp lệ");

        if (status == ApprovalStates.REJECTED && StringUtils.isBlank(note))
            throw new BadDataSpmException("Từ chối cần lý do");

        ApprovalHistory approvalHistory = new ApprovalHistory();
        approvalHistory.setReference(clz, id);
        approvalHistory.setApprovalState(status);
        approvalHistory.setNote(note);
        return addHistory(approvalHistory);
    }

    private ApprovalHistory addHistory(ApprovalHistory approvalHistory) {
        com.hav.st.core.entities.pg.ApprovalHistory pgEntity = ApprovalHistory.toPgEntity(approvalHistory);
        pgEntity.setCreatedDate(DateUtil.nowUtc());
        approvalHistoryPgRepository.save(pgEntity);
        return ApprovalHistory.fromEntity(pgEntity);
    }
}
