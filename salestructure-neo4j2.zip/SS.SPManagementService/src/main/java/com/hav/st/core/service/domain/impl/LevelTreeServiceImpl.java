package com.hav.st.core.service.domain.impl;

import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import com.hav.st.core.entities.neo4j.relationship.ContainsLevel;
import com.hav.st.core.exceptions.BadDataSpmException;
import com.hav.st.core.exceptions.EntityNotFoundSpmException;
import com.hav.st.core.models.FullLevelTreeModel;
import com.hav.st.core.repository.neo4j.node.LevelTreeNeo4jRepository;
import com.hav.st.core.service.domain.LevelTreeService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Transactional
@Service
public class LevelTreeServiceImpl implements LevelTreeService {

    private LevelTreeNeo4jRepository levelTreeNeo4jRepository;

    public LevelTreeServiceImpl(LevelTreeNeo4jRepository levelTreeNeo4jRepository) {
        this.levelTreeNeo4jRepository = levelTreeNeo4jRepository;
    }

    @Override
    public FullLevelTreeModel getTree(LevelTree levelTree) {
        com.hav.st.core.entities.neo4j.node.LevelTree levelTreeEntity = levelTreeNeo4jRepository.findById(levelTree.getId(), 1)
                .orElseThrow(EntityNotFoundSpmException.of(levelTree));

        return FullLevelTreeModel.fromEntity(levelTreeEntity);
    }

    @Override
    public FullLevelTreeModel addTree(LevelTree levelTree) {
        if (StringUtils.isBlank(levelTree.getName())) {
            throw new BadDataSpmException("Missing name");
        }

        com.hav.st.core.entities.neo4j.node.LevelTree levelTreeEntity = LevelTree.toNeo4jEntity(levelTree);

        levelTreeNeo4jRepository.save(levelTreeEntity);

        return FullLevelTreeModel.fromEntity(levelTreeEntity);
    }

    @Override
    public boolean updateTreePartially(LevelTree levelTree) {

        BadDataSpmException.throwIfMissingId(levelTree);

        boolean anyUpdated = false;

        com.hav.st.core.entities.neo4j.node.LevelTree levelTreeEntity = levelTreeNeo4jRepository.findById(levelTree.getId(), 0)
                .orElseThrow(EntityNotFoundSpmException.of(com.hav.st.core.entities.neo4j.node.LevelTree.class, levelTree.getId()));

        if (!StringUtils.isBlank(levelTree.getName()) && !StringUtils.equals(levelTree.getName(), levelTreeEntity.getName())) {
            levelTreeEntity.setName(levelTree.getName());
            anyUpdated = true;
        }

        if (!StringUtils.isBlank(levelTree.getDescription()) && !StringUtils.equals(levelTree.getDescription(), levelTreeEntity.getDescription())) {
            levelTreeEntity.setDescription(levelTree.getDescription());
            anyUpdated = true;
        }

        levelTreeNeo4jRepository.save(levelTreeEntity);

        return anyUpdated;
    }

    @Override
    public FullLevelTreeModel addLevels(LevelTree levelTree, Collection<Level> levels) {
        if (CollectionUtils.isEmpty(levels)) {
            throw new BadDataSpmException("Require at least one level");
        }

        HashSet<String> distinctLevelCode = new HashSet<>();
        HashSet<Integer> distinctLevel = new HashSet<>();

        // validation + normalization
        for (Level level : levels) {
            if (StringUtils.isBlank(level.getName())) {
                throw new BadDataSpmException("Missing name");
            }
            if (StringUtils.isBlank(level.getLevelCode())) {
                throw new BadDataSpmException("Missing level code");
            }
            if (!distinctLevelCode.add(level.getLevelCode().toUpperCase())) {
                throw new BadDataSpmException("Duplicate level code " + level.getLevelCode());
            }
            if (level.getLevel() < 1) {
                throw new BadDataSpmException("Missing level no");
            }
            if (!distinctLevel.add(level.getLevel())) {
                throw new BadDataSpmException("Duplicate level no " + level.getLevel());
            }

            // normalize
            level.setLevelCode(level.getLevelCode().trim().toUpperCase());
        }

        com.hav.st.core.entities.neo4j.node.LevelTree nodeLevelTreeEntity = levelTreeNeo4jRepository
                .findById(levelTree.getId(), 1)
                .orElseThrow(EntityNotFoundSpmException.of(levelTree));

        int maxLevel = levels.stream().map(x -> x.getLevel()).max(Integer::compare).get();
        if (!CollectionUtils.isEmpty(nodeLevelTreeEntity.getAllContains())) {
            maxLevel = Math.max(
                    maxLevel,
                    nodeLevelTreeEntity.getAllContains().stream().map(x -> x.getToNode().getLevel()).max(Integer::compare).get()
            );
        }

        List<com.hav.st.core.entities.neo4j.relationship.ContainsLevel> newAllContains = new ArrayList<>();
        for (int lvlNo = 1; lvlNo <= maxLevel; lvlNo++)
        {
            final int lno = lvlNo;
            Optional<Level> toBeAdded = levels.stream().filter(x -> x.getLevel() == lno).findFirst();
            if (toBeAdded.isPresent()) {
                com.hav.st.core.entities.neo4j.node.Level nodeLevelEntity = Level.toNeo4jEntity(toBeAdded.get());

                ContainsLevel contains = new ContainsLevel();
                contains.connects(nodeLevelTreeEntity, nodeLevelEntity);

                nodeLevelEntity.setContains(contains);

                newAllContains.add(contains);
            }

            if (!CollectionUtils.isEmpty(nodeLevelTreeEntity.getAllContains())) {
                Optional<ContainsLevel> existingLevel = nodeLevelTreeEntity.getAllContains().stream().filter(x -> x.getToNode().getLevel() == lno).findFirst();
                if (existingLevel.isPresent()) {
                    newAllContains.add(existingLevel.get());
                }
            }
        }

        // re-tag level no
        int previousLevel = newAllContains.get(0).getToNode().getLevel();
        for (ContainsLevel newContains : newAllContains.stream().skip(1).collect(Collectors.toList())) {
            int level = newContains.getToNode().getLevel();

            assert level >= previousLevel;

            if (level == previousLevel) {
                level++;
            }

            newContains.getToNode().setLevel(level);
            previousLevel = level;
        }

        // patch new data
        nodeLevelTreeEntity.setAllContains(newAllContains);

        // re-validate level code
        distinctLevelCode = new HashSet<>();
        for (com.hav.st.core.entities.neo4j.node.Level level : nodeLevelTreeEntity.getAllContains().stream().map(x -> x.getToNode()).collect(Collectors.toList())) {
            if (!distinctLevelCode.add(level.getLevelCode().toUpperCase())) {
                throw new BadDataSpmException("Duplicate level code " + level.getLevelCode());
            }
        }

        // persist
        levelTreeNeo4jRepository.save(nodeLevelTreeEntity);

        return FullLevelTreeModel.fromEntity(nodeLevelTreeEntity);
    }
}
