package com.hav.st.core.domain;

import com.hav.st.core.entities.functional.Approvable;
import com.hav.st.core.entities.functional.Expirable;
import com.hav.st.core.utils.ReflectionUtil;
import lombok.Data;

@Data
public class Position extends DomainEntity implements Approvable, Expirable {

    private String salesId;
    private String levelCode;

    public static Position fromNeo4jEntity(com.hav.st.core.entities.neo4j.node.Position entity) {
        Position domain = new Position();
        domain.setId(entity.getCid());

        if (entity.getHasLevel() != null) {
            domain.setLevelCode(entity.getHasLevel().getToNode().getLevelCode());
        }

        ReflectionUtil.copyProperties(entity, domain);
        return domain;
    }
}
