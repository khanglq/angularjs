package com.hav.st.core.repository.neo4j.node;

import com.hav.st.core.entities.neo4j.node.SalesStructure;
import org.springframework.data.neo4j.repository.Neo4jRepository;

public interface SalesStructureNeo4jRepository extends Neo4jRepository<SalesStructure, String> {

}
