package com.hav.st.core.repository.pg;

import com.hav.st.core.entities.pg.ApprovalHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface ApprovalHistoryPgRepository extends JpaRepository<ApprovalHistory, UUID> {
    @Query("SELECT u FROM ApprovalHistory u WHERE u.referenceType = :reference_type AND u.referenceId = :reference_id")
    List<ApprovalHistory> findByReference(@Param("reference_type") String referenceType, @Param("reference_id") String referenceId);
}