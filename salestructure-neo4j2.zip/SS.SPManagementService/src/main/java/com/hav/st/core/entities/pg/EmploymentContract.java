package com.hav.st.core.entities.pg;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hav.st.core.entities.functional.Approvable;
import com.hav.st.core.entities.functional.ApprovalStates;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigInteger;
import java.util.Date;

@Data
@Entity
@Table(name = "dim_employment_contract")
public class EmploymentContract extends PostgresEntity implements Approvable {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "pk_id", updatable = false, nullable = false)
    private BigInteger id;


    @Column(name = "company_name", nullable = false)
    private String companyName;

    @Column(name = "company_address", nullable = false)
    private String companyAddress;

    @Column(name = "company_phone_no", nullable = false)
    private String companyPhoneNo;

    @Column(name = "company_legal_representative_person_name", nullable = false)
    private String companyLegalRepresentativePersonName;

    @Column(name = "company_authorized_representative_person_name", nullable = false)
    private String companyAuthorizedRepresentativePersonName;

    @Column(name = "company_authorized_representative_document_no", nullable = false)
    private String companyAuthorizedRepresentativeDocumentNo;

    @Column(name = "employee_id", nullable = false)
    private String employeeId;

    @Column(name = "employee_name", nullable = false)
    private String employeeName;

    @Column(name = "employee_permanent_address", nullable = false)
    private String employeePermanentAddress;

    @Column(name = "employee_contact_address", nullable = false)
    private String employeeContactAddress;

    @Column(name = "employee_phone_no", nullable = false)
    private String employeePhoneNo;

    @Column(name = "employee_email", nullable = false)
    private String employeeEmail;

    @Column(name = "employee_tax_code", nullable = false)
    private String employeeTaxCode;

    @Column(name = "employee_money_receiving_account", nullable = false)
    private String employeeMoneyReceivingAccount;

    @Column(name = "employee_group", nullable = false)
    private String employeeGroup;

    @Column(name = "number", nullable = false)
    private String contractNumber;

    public void setContractNumberAndNormalizeIt(String contractNumber) {
        this.contractNumber = contractNumber;
        if (StringUtils.isBlank(contractNumber))
            this.normalizedContractNumber = null;
        else
            this.normalizedContractNumber = contractNumber.toUpperCase().replaceAll("\\s", "");
    }

    @Column(name = "normalized_number", nullable = false)
    private String normalizedContractNumber;

    @Column(name = "type", nullable = false)
    private String contractType;

    @Column(name = "sub_type", nullable = false)
    private String contractSubType;

    @Column(name = "effective_date", nullable = false)
    private Date contractEffectiveDate;

    @Column(name = "expiry_date")
    private Date contractExpiryDate;

    @Column(name = "approval_state", nullable = false)
    private String approvalStates;

    @JsonIgnore
    public ApprovalStates getApprovalState() {
        return ApprovalStates.of(approvalStates);
    }

    @JsonIgnore
    public void setApprovalState(ApprovalStates state) {
        this.approvalStates = state == null ? null : state.getShortName();
    }
}
