package com.hav.st.core.exceptions;

import com.hav.st.common.exceptions.BadDataSsException;
import com.hav.st.core.domain.DomainEntity;
import com.hav.st.core.domain.Employee;
import org.apache.commons.lang3.StringUtils;

public class BadDataSpmException extends BadDataSsException {
    public BadDataSpmException(String s) {
        super(s);
    }
    public static <T extends DomainEntity> void throwIfMissingId(T domainEntity) {
        if (StringUtils.isBlank(domainEntity.getId()))
            throw new BadDataSpmException("Missing id");
    }

    public static void throwIfMissingEmployeeId(Employee employee) {
        if (StringUtils.isBlank(employee.getEmployeeId()))
            throw new BadDataSpmException("Missing id");
    }
}
