package com.hav.st.core.utils;

import org.springframework.beans.BeanUtils;

public class ReflectionUtil {
    public static void copyProperties(Object source, Object target) {
        BeanUtils.copyProperties(source, target, "effectiveDate", "expiryDate");
    }
}
