package com.hav.st.core.exceptions.handler;

import com.hav.st.common.exceptions.handler.BaseApiExceptionHandler;
import com.hav.st.core.exceptions.BadDataSpmException;
import com.hav.st.core.exceptions.EntityNotFoundSpmException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

@RestControllerAdvice
public class ApiExceptionHandler extends BaseApiExceptionHandler {

    @ExceptionHandler(EntityNotFoundSpmException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public ResponseEntity whenEntityNotFoundSpmException(Exception ex, WebRequest request) {
        return super.whenEntityNotFoundSsException(ex, request);
    }

    @ExceptionHandler(BadDataSpmException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ResponseEntity whenBadDataSpmException(Exception ex, WebRequest request) {
        return super.whenBadDataSsException(ex, request);
    }
}