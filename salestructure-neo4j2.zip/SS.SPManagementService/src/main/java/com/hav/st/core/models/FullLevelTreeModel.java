package com.hav.st.core.models;

import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import lombok.Data;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Data
public class FullLevelTreeModel {
    private LevelTree levelTree;
    private Collection<Level> levels;

    public static FullLevelTreeModel fromEntity(com.hav.st.core.entities.neo4j.node.LevelTree levelTree) {
        FullLevelTreeModel model = new FullLevelTreeModel();
        model.setLevelTree(LevelTree.fromEntity(levelTree));

        List<Level> levels;
        if (CollectionUtils.isEmpty(levelTree.getAllContains())) {
            levels = new ArrayList<>();
        } else {
            levels = levelTree.getAllContains().stream().map(x -> Level.fromEntity(x.getToNode())).collect(Collectors.toList());
        }
        model.setLevels(levels);
        return model;
    }
}
