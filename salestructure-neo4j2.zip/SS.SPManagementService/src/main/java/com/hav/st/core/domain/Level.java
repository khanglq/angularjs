package com.hav.st.core.domain;

import com.hav.st.core.utils.ReflectionUtil;
import lombok.Data;

@Data
public class Level extends DomainEntity {

    private int level;
    private String levelCode;
    private String name;

    public static com.hav.st.core.entities.neo4j.node.Level toNeo4jEntity(Level domain) {
        com.hav.st.core.entities.neo4j.node.Level entity = new com.hav.st.core.entities.neo4j.node.Level();

        ReflectionUtil.copyProperties(domain, entity);
        return entity;
    }

    public static Level fromEntity(com.hav.st.core.entities.neo4j.node.Level entity) {
        Level domain = new Level();
        domain.id = entity.getCid();

        ReflectionUtil.copyProperties(entity, domain);
        return domain;
    }
}
