package com.hav.st.core.entities.neo4j.node;

import com.hav.st.core.entities.neo4j.relationship.ApplyTo;
import com.hav.st.core.entities.neo4j.relationship.ContainsLevel;
import com.hav.st.core.entities.neo4j.relationship.HasLevel;
import lombok.Data;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import java.util.ArrayList;
import java.util.List;

@Data
@NodeEntity(label = "Level")
public class Level extends EntityNode {

    private int level;
    private String levelCode;
    private String name;

    @Relationship(type = "CONTAINS_LEVEL", direction = Relationship.INCOMING)
    private ContainsLevel contains;

    @Relationship(type = "HAS_LEVEL")
    private List<HasLevel> allHasLevels;

    @Relationship(type = "APPLY_TO", direction = Relationship.INCOMING)
    private List<ApplyTo> allApplyTo;

    public void addRelHasLevel(HasLevel hasLevel) {
        if (allHasLevels == null) {
            allHasLevels = new ArrayList<>();
        }
        allHasLevels.add(hasLevel);
    }

    public void addRelApplyTo(ApplyTo applyTo) {
        if (allApplyTo == null) {
            allApplyTo = new ArrayList<>();
        }
        allApplyTo.add(applyTo);
    }
}
