package com.hav.st.core.domain;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class StaticResource extends DomainEntity {
    @NotNull
    private String group;

    private String subGroup1;

    private String subGroup2;

    private String subGroup3;

    @NotNull
    private String value;

    @NotNull
    private String description;

    public static StaticResource fromEntity(com.hav.st.core.entities.pg.StaticResource pgEntity) {
        StaticResource domain = new StaticResource();
        domain.setGroup(pgEntity.getGroup());
        domain.setSubGroup1(pgEntity.getSubGroup1());
        domain.setSubGroup2(pgEntity.getSubGroup2());
        domain.setSubGroup3(pgEntity.getSubGroup3());
        domain.setValue(pgEntity.getValue());
        domain.setDescription(pgEntity.getDescription());
        return domain;
    }
}
