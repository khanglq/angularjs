package com.hav.st.core.controller;

import com.hav.st.core.entities.pg.PostgresEntity;
import com.hav.st.core.entities.specification.AbstractSpecification;
import com.hav.st.core.entities.specification.AbstractSpecificationBuilder;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@CrossOrigin
public abstract class BaseController extends com.hav.st.common.controller.BaseController {
    protected <T, TS extends AbstractSpecification<T>, TB extends AbstractSpecificationBuilder<T, TS>> void applyFiltersIntoSpecificationBuilder(String filter, TB builder) {
        Pattern pattern = Pattern.compile("(\\w+?)(:|<|>|=)([^,]+?),");
        Matcher matcher = pattern.matcher(filter + ",");
        while (matcher.find()) {
            builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
        }
    }
}
