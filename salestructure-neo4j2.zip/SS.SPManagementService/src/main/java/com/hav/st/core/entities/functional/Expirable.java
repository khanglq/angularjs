package com.hav.st.core.entities.functional;

import lombok.NonNull;

import java.util.Date;

public interface Expirable {
    void setFromDate(@NonNull Date date);
    Date getFromDate();
    void setToDate(Date date);
    Date getToDate();
    void setExpiryDate(String expiryDate);
    String getExpiryDate();
    boolean isExpiredAt(Date date);
}
