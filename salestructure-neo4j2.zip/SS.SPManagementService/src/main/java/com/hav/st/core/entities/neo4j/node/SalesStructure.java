package com.hav.st.core.entities.neo4j.node;

import com.hav.st.core.entities.functional.Approvable;
import com.hav.st.core.entities.functional.Expirable;
import com.hav.st.core.entities.neo4j.relationship.Contains;
import com.hav.st.core.entities.neo4j.relationship.UseLevelTree;
import lombok.Data;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import java.util.ArrayList;
import java.util.List;

@Data
@NodeEntity(label = "SalesStructure")
public class SalesStructure extends EntityNode implements Approvable, Expirable {

    private String name;
    private String description;

    @Relationship(type = "CONTAINS")
    private List<Contains> allContains;

    @Relationship(type = "USE_LEVEL_TREE")
    private UseLevelTree useLevelTree;

    public void addRelContains(Contains contains) {
        if (allContains == null) {
            allContains = new ArrayList<>();
        }
        allContains.add(contains);
    }
}
