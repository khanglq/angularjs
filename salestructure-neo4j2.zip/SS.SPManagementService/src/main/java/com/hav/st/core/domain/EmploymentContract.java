package com.hav.st.core.domain;

import com.hav.st.core.entities.functional.Approvable;
import com.hav.st.core.entities.functional.Expirable;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import javax.validation.constraints.NotNull;
import java.math.BigInteger;

@Data
public class EmploymentContract extends DomainEntity implements Expirable, Approvable {

    @NotNull
    private CompanySide companySide;
    @NotNull
    private EmployeeSide employeeSide;
    @NotNull
    private String employeeGroup;
    @NotNull
    private String contractNo;
    @NotNull
    private String contractType;

    private String contractSubType;

    @Data
    public static class CompanySide {
        @NotNull
        private String name;
        @NotNull
        private String address;
        @NotNull
        private String phoneNo;
        @NotNull
        private String legalRepresentativePersonName;
        @NotNull
        private String authorizedRepresentativePersonName;
        @NotNull
        private String authorizedDocumentNo;
    }

    @Data
    public static class EmployeeSide {
        @NotNull
        private String employeeId;
        @NotNull
        private String name;
        @NotNull
        private String permanentAddress;
        @NotNull
        private String contactAddress;
        @NotNull
        private String phoneNo;
        @NotNull
        private String email;
        @NotNull
        private String taxCode;
        @NotNull
        private String moneyReceivingAccount;
    }

    public static com.hav.st.core.entities.pg.EmploymentContract toPgEntity(EmploymentContract contract) {
        com.hav.st.core.entities.pg.EmploymentContract pgEntity = new com.hav.st.core.entities.pg.EmploymentContract();

        if (StringUtils.isNotBlank(contract.getId()))
            pgEntity.setId(new BigInteger(contract.getId()));

        pgEntity.setCompanyName(contract.getCompanySide().getName());
        pgEntity.setCompanyAddress(contract.getCompanySide().getAddress());
        pgEntity.setCompanyPhoneNo(contract.getCompanySide().getPhoneNo());
        pgEntity.setCompanyLegalRepresentativePersonName(contract.getCompanySide().getLegalRepresentativePersonName());
        pgEntity.setCompanyAuthorizedRepresentativePersonName(contract.getCompanySide().getAuthorizedRepresentativePersonName());
        pgEntity.setCompanyAuthorizedRepresentativeDocumentNo(contract.getCompanySide().getAuthorizedDocumentNo());

        pgEntity.setEmployeeId(contract.getEmployeeSide().getEmployeeId());
        pgEntity.setEmployeeName(contract.getEmployeeSide().getName());
        pgEntity.setEmployeePermanentAddress(contract.getEmployeeSide().getPermanentAddress());
        pgEntity.setEmployeeContactAddress(contract.getEmployeeSide().getContactAddress());
        pgEntity.setEmployeePhoneNo(contract.getEmployeeSide().getPhoneNo());
        pgEntity.setEmployeeEmail(contract.getEmployeeSide().getEmail());
        pgEntity.setEmployeeTaxCode(contract.getEmployeeSide().getTaxCode());
        pgEntity.setEmployeeMoneyReceivingAccount(contract.getEmployeeSide().getMoneyReceivingAccount());

        pgEntity.setEmployeeGroup(contract.getEmployeeGroup());
        pgEntity.setContractNumberAndNormalizeIt(contract.getContractNo());
        pgEntity.setContractType(contract.getContractType());
        pgEntity.setContractSubType(contract.getContractSubType());
        pgEntity.setContractEffectiveDate(contract.getFromDate());
        pgEntity.setContractExpiryDate(contract.getToDate());
        pgEntity.setApprovalState(contract.getApprovalState());
        return pgEntity;
    }

    public static EmploymentContract fromEntity(com.hav.st.core.entities.pg.EmploymentContract pgEntity) {
        EmploymentContract domain = new EmploymentContract();

        if (pgEntity.getId() != null && pgEntity.getId().compareTo(BigInteger.ZERO) > 0)
            domain.setId(pgEntity.getId().toString());

        domain.setCompanySide(new CompanySide());
        domain.setEmployeeSide(new EmployeeSide());

        domain.getCompanySide().setName(pgEntity.getCompanyName());
        domain.getCompanySide().setAddress(pgEntity.getCompanyAddress());
        domain.getCompanySide().setPhoneNo(pgEntity.getCompanyPhoneNo());
        domain.getCompanySide().setLegalRepresentativePersonName(pgEntity.getCompanyLegalRepresentativePersonName());
        domain.getCompanySide().setAuthorizedRepresentativePersonName(pgEntity.getCompanyAuthorizedRepresentativePersonName());
        domain.getCompanySide().setAuthorizedDocumentNo(pgEntity.getCompanyAuthorizedRepresentativeDocumentNo());

        domain.getEmployeeSide().setEmployeeId(pgEntity.getEmployeeId());
        domain.getEmployeeSide().setName(pgEntity.getEmployeeName());
        domain.getEmployeeSide().setPermanentAddress(pgEntity.getEmployeePermanentAddress());
        domain.getEmployeeSide().setContactAddress(pgEntity.getEmployeeContactAddress());
        domain.getEmployeeSide().setPhoneNo(pgEntity.getEmployeePhoneNo());
        domain.getEmployeeSide().setEmail(pgEntity.getEmployeeEmail());
        domain.getEmployeeSide().setTaxCode(pgEntity.getEmployeeTaxCode());
        domain.getEmployeeSide().setMoneyReceivingAccount(pgEntity.getEmployeeMoneyReceivingAccount());

        domain.setEmployeeGroup(pgEntity.getEmployeeGroup());
        domain.setContractNo(pgEntity.getContractNumber());
        domain.setContractType(pgEntity.getContractType());
        domain.setContractSubType(pgEntity.getContractSubType());
        domain.setFromDate(pgEntity.getContractEffectiveDate());
        domain.setToDate(pgEntity.getContractExpiryDate());
        domain.setApprovalState(pgEntity.getApprovalState());

        return domain;
    }
}
