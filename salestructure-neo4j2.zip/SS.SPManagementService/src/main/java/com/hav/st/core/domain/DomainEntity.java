package com.hav.st.core.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hav.st.common.utils.DateUtil;
import com.hav.st.core.entities.functional.ApprovalStates;
import com.hav.st.core.entities.functional.Expirable;
import lombok.Data;
import lombok.NonNull;
import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;
import java.time.Instant;
import java.util.Date;

@Data
public abstract class DomainEntity {

    protected String id;
    private String approvalStates;
    @JsonIgnore
    private Date fromDate;
    private Date toDate;

    @JsonIgnore
    public ApprovalStates getApprovalState() {
        return ApprovalStates.of(approvalStates);
    }

    @JsonIgnore
    public void setApprovalState(ApprovalStates state) {
        this.approvalStates = state == null ? null : state.getShortName();
    }

    @JsonIgnore
    public void setFromDate(Date date) {
        fromDate = date;
    }

    @JsonIgnore
    public Date getFromDate() {
        return fromDate;
    }

    @JsonIgnore
    public void setToDate(Date date) {
        toDate = date;
    }

    @JsonIgnore
    public Date getToDate() {
        return toDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        try {
            setFromDate(StringUtils.isBlank(effectiveDate) ? null : DateUtil.fromString(effectiveDate));
        } catch (ParseException ex) {
            throw DateUtil.createBadDataSsExceptionWhenInvalidFormat();
        }
    }

    public String getEffectiveDate() {
        return getFromDate() == null ? null : DateUtil.fromDate(getFromDate());
    }

    public void setExpiryDate(String expiryDate) {
        try {
            setToDate(StringUtils.isBlank(expiryDate) ? null : DateUtil.fromString(expiryDate));
        } catch (ParseException ex) {
            throw DateUtil.createBadDataSsExceptionWhenInvalidFormat();
        }
    }

    public String getExpiryDate() {
        return getToDate() == null ? null : DateUtil.fromDate(getToDate());
    }

    @JsonIgnore
    public boolean isExpired() {
        if (this instanceof Expirable == false)
            return false;
        return toDate != null && toDate.toInstant().isBefore(Instant.now());
    }

    public boolean isExpiredAt(@NonNull Date date) {
        if (this instanceof Expirable == false)
            return false;
        return toDate != null && toDate.before(date);
    }
}