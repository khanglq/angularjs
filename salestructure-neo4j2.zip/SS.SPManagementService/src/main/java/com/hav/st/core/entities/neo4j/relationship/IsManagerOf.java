package com.hav.st.core.entities.neo4j.relationship;

import com.hav.st.core.entities.functional.Approvable;
import com.hav.st.core.entities.functional.Expirable;
import com.hav.st.core.entities.neo4j.node.Position;
import lombok.Data;
import org.neo4j.ogm.annotation.RelationshipEntity;

@Data
@RelationshipEntity(type = "IS_MANAGER_OF")
public class IsManagerOf extends EntityRelationship<Position, Position> implements Expirable, Approvable {

}