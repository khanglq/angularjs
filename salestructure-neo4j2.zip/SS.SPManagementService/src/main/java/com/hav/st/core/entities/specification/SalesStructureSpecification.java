package com.hav.st.core.entities.specification;

import com.hav.st.core.entities.neo4j.node.SalesStructure;
import com.hav.st.core.entities.pg.Employee;
import org.springframework.data.jpa.domain.Specification;

public class SalesStructureSpecification extends AbstractSpecification<SalesStructure> implements Specification<SalesStructure> {
    public SalesStructureSpecification(SearchCriteria criteria) {
        super(criteria);
    }
}
