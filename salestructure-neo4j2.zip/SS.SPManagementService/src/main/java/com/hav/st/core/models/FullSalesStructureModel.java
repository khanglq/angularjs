package com.hav.st.core.models;

import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import com.hav.st.core.domain.Position;
import com.hav.st.core.domain.SalesStructure;
import com.hav.st.core.domain.relationship.HasLevel;
import com.hav.st.core.domain.relationship.IsManagerOf;
import com.hav.st.core.entities.neo4j.relationship.ContainsLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Data
@NoArgsConstructor
public class FullSalesStructureModel {
    private SalesStructure salesStructure;
    private LevelTree levelTree;
    private Collection<Level> levels;
    private Collection<Position> positions;
    private Collection<HasLevel> hasLevels;
    private Collection<IsManagerOf> isManagerOfs;
    private Collection<String> kpiIds;

    public static FullSalesStructureModel fromEntity(com.hav.st.core.entities.neo4j.node.SalesStructure salesStructureNeo4jEntity) {
        FullSalesStructureModel fullSalesStructureModel = new FullSalesStructureModel();
        fullSalesStructureModel.setSalesStructure(SalesStructure.fromNeo4jEntity(salesStructureNeo4jEntity));

        if (salesStructureNeo4jEntity.getUseLevelTree() != null) {
            fullSalesStructureModel.setLevelTree(LevelTree.fromEntity(salesStructureNeo4jEntity.getUseLevelTree().getToNode()));

            List<ContainsLevel> allContains = salesStructureNeo4jEntity.getUseLevelTree().getToNode().getAllContains();
            if (!CollectionUtils.isEmpty(allContains)) {
                List<com.hav.st.core.entities.neo4j.node.Level> levelEntities = allContains.stream().map(x -> x.getToNode()).collect(Collectors.toList());
                fullSalesStructureModel.setLevels(levelEntities.stream().map(x -> Level.fromEntity(x)).collect(Collectors.toList()));
                fullSalesStructureModel.setKpiIds(
                        levelEntities.stream()
                                .filter(x -> !CollectionUtils.isEmpty(x.getAllApplyTo()))
                                .flatMap(x -> x.getAllApplyTo().stream())
                                .map(x -> x.getFromNode().getCid())
                                .collect(Collectors.toSet())
                );
            }
        }

        if (!CollectionUtils.isEmpty(salesStructureNeo4jEntity.getAllContains())) {
            List<com.hav.st.core.entities.neo4j.node.Position> positionEntities = salesStructureNeo4jEntity.getAllContains().stream().map(x -> x.getToNode()).collect(Collectors.toList());
            fullSalesStructureModel.setPositions(positionEntities.stream().map(x -> Position.fromNeo4jEntity(x)).collect(Collectors.toList()));
            fullSalesStructureModel.setHasLevels(positionEntities.stream().filter(x -> x.getHasLevel() != null).map(x -> HasLevel.fromNeo4jEntity(x.getHasLevel())).collect(Collectors.toList()));
            fullSalesStructureModel.setIsManagerOfs(
                    positionEntities.stream()
                            .map(x -> {
                                if (!CollectionUtils.isEmpty(x.getManages()) && !CollectionUtils.isEmpty(x.getManagedBy()))
                                    return Stream.concat(x.getManages().stream(), x.getManagedBy().stream());
                                else if (!CollectionUtils.isEmpty(x.getManages()))
                                    return x.getManages().stream();
                                else if (!CollectionUtils.isEmpty(x.getManagedBy()))
                                    return x.getManagedBy().stream();
                                else
                                    return Stream.of((com.hav.st.core.entities.neo4j.relationship.IsManagerOf) null);
                            })
                            .filter(x -> x != null)
                            .flatMap(x -> x)
                            .filter(x -> x != null)
                            .map(x -> IsManagerOf.fromNeo4jEntity(x))
                            .filter(distinctByKey(IsManagerOf::getId))
                            .collect(Collectors.toList())
            );
        }

        return fullSalesStructureModel;
    }

    private static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(keyExtractor.apply(t));
    }
}
