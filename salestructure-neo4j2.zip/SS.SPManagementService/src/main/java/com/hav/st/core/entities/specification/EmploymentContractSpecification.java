package com.hav.st.core.entities.specification;

import com.hav.st.core.entities.pg.EmploymentContract;
import org.springframework.data.jpa.domain.Specification;

public class EmploymentContractSpecification extends AbstractSpecification<EmploymentContract> implements Specification<EmploymentContract> {
    public EmploymentContractSpecification(SearchCriteria criteria) {
        super(criteria);
    }
}