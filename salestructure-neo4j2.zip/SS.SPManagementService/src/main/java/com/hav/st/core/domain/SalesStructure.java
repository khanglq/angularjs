package com.hav.st.core.domain;

import com.hav.st.core.entities.functional.Approvable;
import com.hav.st.core.entities.functional.Expirable;
import com.hav.st.core.utils.ReflectionUtil;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.util.Date;

@Data
public class SalesStructure extends DomainEntity implements Approvable, Expirable {

    private String name;
    private String description;
    protected Date createdDate;
    protected Date lastUpdatedDate;

    public static com.hav.st.core.entities.neo4j.node.SalesStructure toNeo4jEntity(SalesStructure domain) {
        com.hav.st.core.entities.neo4j.node.SalesStructure entity = new com.hav.st.core.entities.neo4j.node.SalesStructure();

        ReflectionUtil.copyProperties(domain, entity);
        return entity;
    }

    public static SalesStructure fromNeo4jEntity(com.hav.st.core.entities.neo4j.node.SalesStructure entity) {
        SalesStructure domain = new SalesStructure();
        domain.id = entity.getCid();

        ReflectionUtil.copyProperties(entity, domain);
        return domain;
    }
}
