package com.hav.st.core;

import com.hav.st.core.component.GraphEntityEventListener;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.neo4j.ogm.session.SessionFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.PostConstruct;


/**
 * @author Minhdd
 */
@SpringBootApplication
public class SalesStructureServiceApplication {

    private static final Logger logger = LogManager.getLogger(SalesStructureServiceApplication.class);

    private final SessionFactory neo4jSessionFactory;

    public SalesStructureServiceApplication(SessionFactory sessionFactory) {
        this.neo4jSessionFactory = sessionFactory;
    }

    @PostConstruct
    public void registerEventlistener() {
        neo4jSessionFactory.register(new GraphEntityEventListener());
    }

    public static void main(String[] args) {
        SpringApplication.run(SalesStructureServiceApplication.class, args);
    }
}