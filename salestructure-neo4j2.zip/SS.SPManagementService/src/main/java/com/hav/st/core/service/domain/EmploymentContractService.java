package com.hav.st.core.service.domain;

import com.hav.st.core.domain.EmploymentContract;
import com.hav.st.core.entities.functional.ApprovalStates;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import java.util.Collection;

public interface EmploymentContractService {
    EmploymentContract add(EmploymentContract contract);
    Page<EmploymentContract> findAll(Specification<com.hav.st.core.entities.pg.EmploymentContract> specification, Pageable pageable);
    void updateApprovalStateOfEmploymentContracts(Collection<EmploymentContract> employmentContracts, ApprovalStates newState, String note);
}
