package com.hav.st.core.controller;

import com.hav.st.common.dto.DataRequestDTO;
import com.hav.st.common.dto.ResponseMessageOnSuccess;
import com.hav.st.core.domain.Employee;
import com.hav.st.core.domain.Kpi;
import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import com.hav.st.core.domain.Position;
import com.hav.st.core.domain.SalesStructure;
import com.hav.st.core.domain.relationship.IsManagerOf;
import com.hav.st.core.entities.specification.EmployeeSpecificationsBuilder;
import com.hav.st.core.entities.specification.SalesStructureSpecificationsBuilder;
import com.hav.st.core.models.ApprovalModel;
import com.hav.st.core.models.CreateSalesStructureModel;
import com.hav.st.core.models.FullKpiModel;
import com.hav.st.core.models.FullSalesStructureModel;
import com.hav.st.core.models.LinkingModel;
import com.hav.st.core.models.SetManagementModel;
import com.hav.st.core.models.UpdateKpiModel;
import com.hav.st.core.service.domain.SalesStructureService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;

@Api(value = "sales-structure", tags = {"/sales-structures v1"}, description = "Sales structures management service")
@RestController
@RequestMapping("/api/v1/sales-structures")
public class SalesStructureController extends BaseController {

    private static final Logger logger = LogManager.getLogger(SalesStructureController.class);
    private SalesStructureService salesStructureService;


    public SalesStructureController(SalesStructureService salesStructureService) {
        this.salesStructureService = salesStructureService;
    }

    @ApiOperation(value = "Get all sales structures")
    @GetMapping(params = "cmd=search")
    public ResponseEntity<ResponseMessageOnSuccess<Page<SalesStructure>>> searchSalesStructure(
            @RequestParam(value = "filter", required = false) String filter, Pageable pageable) {

        SalesStructureSpecificationsBuilder builder = new SalesStructureSpecificationsBuilder();
        applyFiltersIntoSpecificationBuilder(filter, builder);

        return ok(salesStructureService.findAll(builder.build(), pageable));
    }

    @ApiOperation(value = "Get specific sales structure")
    @GetMapping(value = "/{salesStructureId}")
    public ResponseEntity<ResponseMessageOnSuccess<SalesStructure>> getSalesStructure(@PathVariable("salesStructureId") String salesStructureId) {
        logger.warn("getSalesStructure " + salesStructureId);
        SalesStructure salesStructure = new SalesStructure();
        salesStructure.setId(salesStructureId);
        return ok(salesStructureService.getSalesStructure(salesStructure));
    }

    @ApiOperation(value = "Get full details of a specific sales structure")
    @GetMapping(value = "/{salesStructureId}", params = "full=true")
    public ResponseEntity<ResponseMessageOnSuccess<FullSalesStructureModel>> getFullSalesStructure(@PathVariable("salesStructureId") String salesStructureId) {
        SalesStructure salesStructure = new SalesStructure();
        salesStructure.setId(salesStructureId);
        return ok(salesStructureService.getFullSalesStructure(salesStructure));
    }

    @ApiOperation(value = "Create new sales structure")
    @PostMapping(params = "cmd=create")
    public ResponseEntity<ResponseMessageOnSuccess<SalesStructure>> createSalesStructure(@RequestBody DataRequestDTO<CreateSalesStructureModel> dtoCreateSalesStructure) {
        throwIfBadDTO(dtoCreateSalesStructure);
        return created(salesStructureService.createSalesStructure(dtoCreateSalesStructure.getData()));
    }

    @ApiOperation(value = "Update sales structure partially")
    @PatchMapping(params = "cmd=update")
    public ResponseEntity<ResponseMessageOnSuccess<String>> updateSalesStructurePartially(@RequestBody DataRequestDTO<SalesStructure> dtoSalesStructure) {
        throwIfBadDTO(dtoSalesStructure);
        return salesStructureService.updateSalesStructure(dtoSalesStructure.getData())
                ? ok()
                : notModified();
    }

    @ApiOperation(value = "Approve sales structures")
    @PostMapping(params = "cmd=approve")
    public ResponseEntity<ResponseMessageOnSuccess<String>> approveSalesStructures(@RequestBody DataRequestDTO<ApprovalModel<SalesStructure>> dtoApprovalModel) {
        throwIfBadDTO(dtoApprovalModel);
        salesStructureService.updateApprovalStateOfSalesStructures(dtoApprovalModel.getData().getCollection(), dtoApprovalModel.getData().getApprovalState());
        return ok();
    }

    @ApiOperation(value = "Expire sales structure")
    @DeleteMapping(params = "cmd=expire")
    public ResponseEntity<ResponseMessageOnSuccess<String>> expireSalesStructure(@RequestBody DataRequestDTO<SalesStructure> dtoSalesStructure) {
        throwIfBadDTO(dtoSalesStructure);
        salesStructureService.expireSalesStructure(dtoSalesStructure.getData());
        return ok();
    }

    @ApiOperation(value = "Link sales structure with level tree")
    @PostMapping(params = {"cmd=link", "cmdType=level-tree"})
    public ResponseEntity<ResponseMessageOnSuccess<String>> updateSalesStructureSetUseLevelTree(@RequestBody DataRequestDTO<LinkingModel<SalesStructure, LevelTree>> dtoLinkingModel) {
        throwIfBadDTO(dtoLinkingModel);
        salesStructureService.updateSalesStructureSetUseLevelTree(dtoLinkingModel.getData().getFrom(), dtoLinkingModel.getData().getTo());
        return ok();
    }

    @ApiOperation(value = "Add multiple positions into specific sales structure")
    @PostMapping(params = {"cmd=create", "cmdType=positions"})
    public ResponseEntity<ResponseMessageOnSuccess<Collection<Position>>> addPositionsIntoSpecificSalesStructure(@RequestBody DataRequestDTO<LinkingModel<SalesStructure, Collection<Position>>> dtoLinkingModel) {
        throwIfBadDTO(dtoLinkingModel);
        return created(salesStructureService.addPositionsIntoSalesStructure(dtoLinkingModel.getData().getFrom(), dtoLinkingModel.getData().getTo()));
    }

    @ApiOperation(value = "Approve positions")
    @PostMapping(value = "/positions", params = "cmd=approve")
    public ResponseEntity<ResponseMessageOnSuccess<String>> approvePositions(@RequestBody DataRequestDTO<ApprovalModel<Position>> dtoApprovalModel) {
        throwIfBadDTO(dtoApprovalModel);
        salesStructureService.updateApprovalStateOfPositions(dtoApprovalModel.getData().getCollection(), dtoApprovalModel.getData().getApprovalState());
        return ok();
    }

    @ApiOperation(value = "Expire positions")
    @DeleteMapping(value = "/positions", params = "cmd=expire")
    public ResponseEntity<ResponseMessageOnSuccess<String>> expirePositions(@RequestBody DataRequestDTO<Collection<Position>> dtoPositions) {
        throwIfBadDTO(dtoPositions);
        salesStructureService.expirePositions(dtoPositions.getData());
        return ok();
    }

    @ApiOperation(value = "Setup new management relationship between pairs of position in batch")
    @PostMapping(value = "/positions", params = {"cmd=link", "cmdType=management"})
    public ResponseEntity<ResponseMessageOnSuccess<String>> addRelationIsManagerOf(@RequestBody DataRequestDTO<SetManagementModel> dtoSetManagementModel) {
        throwIfBadDTO(dtoSetManagementModel);
        salesStructureService.addManagementRelationship(dtoSetManagementModel.getData());
        return created();
    }

    @ApiOperation(value = "Approve relationship between pairs of position in batch")
    @PostMapping(value = "/positions", params = {"cmd=approve", "cmdType=management"})
    public ResponseEntity<ResponseMessageOnSuccess<String>> approveRelationIsManagerOf(@RequestBody DataRequestDTO<ApprovalModel<IsManagerOf>> dtoApprovalModel) {
        throwIfBadDTO(dtoApprovalModel);
        salesStructureService.approveManagementRelationships(dtoApprovalModel.getData().getCollection(), dtoApprovalModel.getData().getApprovalState());
        return ok();
    }

    @ApiOperation(value = "Unset management relationship using id of IS_MANAGER_OF relationship")
    @DeleteMapping(value = "/positions", params = {"cmd=link", "cmdType=management"})
    public ResponseEntity<ResponseMessageOnSuccess<String>> expireRelationIsManagerOf(@RequestBody DataRequestDTO<IsManagerOf> dtoIsManagerOf) {
        throwIfBadDTO(dtoIsManagerOf);
        salesStructureService.expireManagementRelationship(dtoIsManagerOf.getData());
        return ok();
    }

    @ApiOperation(value = "Get levels within sales structure")
    @GetMapping("/{salesStructureId}/levels")
    public ResponseEntity<ResponseMessageOnSuccess<Collection<Level>>> getLevelsWithinSalesStructure(@PathVariable("salesStructureId") String salesStructureId) {
        SalesStructure salesStructure = new SalesStructure();
        salesStructure.setId(salesStructureId);
        return ok(salesStructureService.getLevelsWithinSalesStructure(salesStructure));
    }

    @ApiOperation(value = "Create KPI")
    @PostMapping(value = "/kpi", params = "cmd=create")
    public ResponseEntity<ResponseMessageOnSuccess<FullKpiModel>> createKpiForSalesStructure(@RequestBody DataRequestDTO<UpdateKpiModel> dtoUpdateKpiModel) {
        throwIfBadDTO(dtoUpdateKpiModel);
        return created(salesStructureService.createKpiForSalesStructure(dtoUpdateKpiModel.getData()));
    }

    @ApiOperation(value = "Update KPI target values")
    @PostMapping(value = "/kpi", params = "cmd=update")
    public ResponseEntity<ResponseMessageOnSuccess<FullKpiModel>> updateKpi(@RequestBody DataRequestDTO<UpdateKpiModel> dtoUpdateKpiModel) {
        throwIfBadDTO(dtoUpdateKpiModel);
        return ok(salesStructureService.updateKpiForSalesStructure(dtoUpdateKpiModel.getData()));
    }

    @ApiOperation(value = "Get specific KPI")
    @GetMapping("/kpi/{kpiId}")
    public ResponseEntity<ResponseMessageOnSuccess<FullKpiModel>> getKpi(@PathVariable("kpiId") String kpiId) {
        Kpi kpi = new Kpi();
        kpi.setId(kpiId);
        return ok(salesStructureService.getKpi(kpi));
    }
}
