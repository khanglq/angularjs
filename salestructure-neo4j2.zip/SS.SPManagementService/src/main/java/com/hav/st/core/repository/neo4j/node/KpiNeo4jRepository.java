package com.hav.st.core.repository.neo4j.node;

import com.hav.st.core.entities.neo4j.node.Kpi;
import org.springframework.data.neo4j.repository.Neo4jRepository;

public interface KpiNeo4jRepository extends Neo4jRepository<Kpi, String> {
}
