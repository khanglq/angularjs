package com.hav.st.core.service.db.pg.impl;

import com.hav.st.core.entities.pg.EmployeeAddress;
import com.hav.st.core.repository.pg.EmployeeAddressPgRepository;
import com.hav.st.core.service.db.GenericDbServiceImpl;
import com.hav.st.core.service.db.pg.EmployeeAddressPgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
@Transactional("jpaTransactionManager")
public class EmployeeAddressPgServiceImpl extends GenericDbServiceImpl<EmployeeAddress, UUID, EmployeeAddressPgRepository> implements EmployeeAddressPgService {

    @Autowired
    private EmployeeAddressPgRepository repository;

    @Override
    protected EmployeeAddressPgRepository getRepository() {
        return repository;
    }
}
