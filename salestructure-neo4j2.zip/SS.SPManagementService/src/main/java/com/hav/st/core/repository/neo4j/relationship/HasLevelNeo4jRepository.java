package com.hav.st.core.repository.neo4j.relationship;

import com.hav.st.core.entities.neo4j.relationship.HasLevel;
import org.springframework.data.neo4j.repository.Neo4jRepository;

public interface HasLevelNeo4jRepository extends Neo4jRepository<HasLevel, String> {
}
