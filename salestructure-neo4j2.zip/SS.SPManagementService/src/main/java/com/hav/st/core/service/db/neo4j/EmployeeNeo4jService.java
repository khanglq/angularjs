package com.hav.st.core.service.db.neo4j;

import com.hav.st.core.entities.neo4j.node.Employee;
import com.hav.st.core.repository.neo4j.node.EmployeeNeo4jRepository;
import com.hav.st.core.service.db.GenericDbService;

import java.util.Collection;
import java.util.Optional;

public interface EmployeeNeo4jService extends GenericDbService<Employee, String, EmployeeNeo4jRepository> {
    void save(Employee employee);
    void saveAll(Collection<Employee> employees);
    Optional<Employee> findByEmpId(String employeeId);
}