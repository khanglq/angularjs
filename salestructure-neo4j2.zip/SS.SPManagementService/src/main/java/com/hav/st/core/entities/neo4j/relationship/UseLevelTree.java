package com.hav.st.core.entities.neo4j.relationship;

import com.hav.st.core.entities.neo4j.node.LevelTree;
import com.hav.st.core.entities.neo4j.node.SalesStructure;
import lombok.Data;
import org.neo4j.ogm.annotation.RelationshipEntity;

@Data
@RelationshipEntity(type = "USE_LEVEL_TREE")
public class UseLevelTree extends EntityRelationship<SalesStructure, LevelTree> {

}