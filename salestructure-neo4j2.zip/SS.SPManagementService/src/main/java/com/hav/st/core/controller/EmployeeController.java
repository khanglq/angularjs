package com.hav.st.core.controller;

import com.hav.st.common.dto.DataRequestDTO;
import com.hav.st.common.dto.ResponseMessageOnSuccess;
import com.hav.st.core.domain.Employee;
import com.hav.st.core.domain.EmploymentContract;
import com.hav.st.core.entities.specification.EmployeeSpecificationsBuilder;
import com.hav.st.core.entities.specification.EmploymentContractSpecificationBuilder;
import com.hav.st.core.exceptions.EntityNotFoundSpmException;
import com.hav.st.core.models.ApprovalModel;
import com.hav.st.core.service.domain.EmployeeService;
import com.hav.st.core.service.domain.EmploymentContractService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Api(value = "employee", tags = {"/employees v1"}, description = "Employees management service")
@RestController
@RequestMapping("/api/v1/employees")
public class EmployeeController extends BaseController {

    private static final Logger logger = LogManager.getLogger(EmployeeController.class);
    private EmployeeService employeeService;
    private EmploymentContractService employmentContractService;


    public EmployeeController(EmployeeService employeeService, EmploymentContractService employmentContractService) {
        this.employeeService = employeeService;
        this.employmentContractService = employmentContractService;
    }

    @ApiOperation(value = "Get Employee By ID")
    @GetMapping("/{empId}")
    public ResponseEntity<ResponseMessageOnSuccess<Employee>> getEmployeeById(@PathVariable("empId") String empId) {
        return ok(employeeService.findByEmpId(empId));
    }

    @ApiOperation(value = "Get all employees")
    @GetMapping(params = "cmd=search")
    public ResponseEntity<ResponseMessageOnSuccess<Page<Employee>>> searchEmployees(
            @RequestParam(value = "filter", required = false) String filter, Pageable pageable) {

        EmployeeSpecificationsBuilder builder = new EmployeeSpecificationsBuilder();
        applyFiltersIntoSpecificationBuilder(filter, builder);

        return ok(employeeService.findAll(builder.build(), pageable));
    }

    @ApiOperation(value = "Search employee")
    @GetMapping(params = {"cmd=search", "cmdType=single"})
    public ResponseEntity<ResponseMessageOnSuccess<Employee>> searchEmployee(
            @RequestParam(value = "filter", required = false) String filter) {

        EmployeeSpecificationsBuilder builder = new EmployeeSpecificationsBuilder();
        applyFiltersIntoSpecificationBuilder(filter, builder);

        Employee employee = employeeService.findOne(builder.build());
        if (employee == null)
            throw new EntityNotFoundSpmException("Không tìm thấy nhân viên phù hợp điều kiện");

        return ok(employee);
    }

    @ApiOperation(value = "Create employee")
    @PostMapping(params = "cmd=create")
    public ResponseEntity<ResponseMessageOnSuccess<Employee>> createEmployees(@RequestBody DataRequestDTO<Employee> dtoEmployee) {
        throwIfBadDTO(dtoEmployee);
        return created(employeeService.add(dtoEmployee.getData()));
    }

    @ApiOperation(value = "Approve employees")
    @PostMapping(params = "cmd=approve")
    public ResponseEntity<ResponseMessageOnSuccess<String>> approveEmployees(@RequestBody DataRequestDTO<ApprovalModel<Employee>> dtoApprovalModel) {
        throwIfBadDTO(dtoApprovalModel);
        employeeService.updateApprovalStateOfEmployees(dtoApprovalModel.getData().getCollection(), dtoApprovalModel.getData().getApprovalState(), dtoApprovalModel.getData().getNote());
        return ok();
    }

    @ApiOperation(value = "Create employment contract")
    @PostMapping(value = "/_contract", params = "cmd=create")
    public ResponseEntity<ResponseMessageOnSuccess<EmploymentContract>> createEmploymentContract(@RequestBody DataRequestDTO<EmploymentContract> dtoEmploymentContract) {
        throwIfBadDTO(dtoEmploymentContract);
        return created(employmentContractService.add(dtoEmploymentContract.getData()));
    }

    @ApiOperation(value = "Approve employment contracts")
    @PostMapping(value = "/_contract", params = "cmd=approve")
    public ResponseEntity<ResponseMessageOnSuccess<String>> approveEmploymentContracts(@RequestBody DataRequestDTO<ApprovalModel<EmploymentContract>> dtoApprovalModel) {
        throwIfBadDTO(dtoApprovalModel);
        employmentContractService.updateApprovalStateOfEmploymentContracts(dtoApprovalModel.getData().getCollection(), dtoApprovalModel.getData().getApprovalState(), dtoApprovalModel.getData().getNote());
        return ok();
    }

    @ApiOperation(value = "Get all employment contracts")
    @GetMapping(value = "/_contract", params = "cmd=search")
    public ResponseEntity<ResponseMessageOnSuccess<Page<EmploymentContract>>> searchEmploymentContracts(
            @RequestParam(value = "filter", required = false) String filter, Pageable pageable) {

        EmploymentContractSpecificationBuilder builder = new EmploymentContractSpecificationBuilder();
        applyFiltersIntoSpecificationBuilder(filter, builder);

        return ok(employmentContractService.findAll(builder.build(), pageable));
    }
}