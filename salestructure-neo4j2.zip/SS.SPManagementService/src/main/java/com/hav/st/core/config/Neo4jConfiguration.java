package com.hav.st.core.config;

import org.neo4j.ogm.session.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.neo4j.repository.config.EnableNeo4jRepositories;
import org.springframework.data.neo4j.transaction.Neo4jTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableNeo4jRepositories(
        basePackages = {"com.hav.st.core.repository.neo4j.node", "com.hav.st.core.repository.neo4j.relationship"},
        sessionFactoryRef = "neo4jSessionFactory",
        transactionManagerRef = "neo4jTransactionManager"
)
@EnableTransactionManagement
public class Neo4jConfiguration {

    @Autowired
    private Neo4jProperties properties;

    @Bean
    public SessionFactory neo4jSessionFactory() {
        // with domain entity base package(s)
        return new SessionFactory(configuration(), "com.hav.st.core.entities.neo4j.node","com.hav.st.core.entities.neo4j.relationship");
    }

    @Bean
    public org.neo4j.ogm.config.Configuration configuration() {
        org.neo4j.ogm.config.Configuration configuration = new org.neo4j.ogm.config.Configuration.Builder()
                .uri(properties.getUri())
                .credentials(properties.getUserName(), properties.getPassword())
                .build();
        return configuration;
    }

    @Bean
    public Neo4jTransactionManager neo4jTransactionManager() {
        return new Neo4jTransactionManager(neo4jSessionFactory());
    }
}
