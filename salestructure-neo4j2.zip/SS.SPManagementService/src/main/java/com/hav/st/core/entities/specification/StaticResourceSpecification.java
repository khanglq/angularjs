package com.hav.st.core.entities.specification;

import com.hav.st.core.entities.pg.StaticResource;
import org.springframework.data.jpa.domain.Specification;

public class StaticResourceSpecification extends AbstractSpecification<StaticResource> implements Specification<StaticResource> {
    public StaticResourceSpecification(SearchCriteria criteria) {
        super(criteria);
    }
}
