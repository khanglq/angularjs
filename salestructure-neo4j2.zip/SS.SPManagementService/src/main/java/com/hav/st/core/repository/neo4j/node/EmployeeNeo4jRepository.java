package com.hav.st.core.repository.neo4j.node;

import com.hav.st.core.entities.neo4j.node.Employee;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.Optional;

/**
 * @author Minhdd
 */
public interface EmployeeNeo4jRepository extends Neo4jRepository<Employee, String> {

    @Query("MATCH (m:Employee) WHERE m.empid = {empId} RETURN m ")
    Optional<Employee> findByEmpId(@Param("empId") String empId);

    @Query("MATCH (m:Employee) WHERE m.salesId = {salesId} RETURN m ")
    Optional<Employee> findBySalesId(@Param("salesId") String salesId);

    @Override
    @Query("MATCH (m:Employee) RETURN m LIMIT {limit}")
    Collection<Employee> findAll(@Param("limit") int limit);

//    @Query("MATCH (employee:Employee), (manager:Employee) WHERE employee.empId = {0} AND manager.empId = {1} \n" +
//            "CREATE (employee)-[:REPORTS_TO]->(manager)\n" +
//            "RETURN employee,manager")
//    void addNewEmployee(String employeeId, String managerId);
//
//    @Query("MATCH (employee:Employee), (manager:Employee) WHERE employee.empId = {0} AND manager.empId = {1} \n" +
//            "CREATE (employee)-[:{2}]->(manager)\n" +
//            "RETURN employee,manager")
//    void updateRel(String employeeId, String managerId, String relName);
}