package com.hav.st.core.entities.specification;

import com.hav.st.core.entities.pg.StaticResource;

public class StaticResourceSpecificationBuilder extends AbstractSpecificationBuilder<StaticResource, StaticResourceSpecification> {
    @Override
    protected StaticResourceSpecification createSpecification(SearchCriteria searchCriteria) {
        return new StaticResourceSpecification(searchCriteria);
    }
}
