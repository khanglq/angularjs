package com.hav.st.core.repository.neo4j.relationship;

import com.hav.st.core.entities.neo4j.relationship.UseLevelTree;
import org.springframework.data.neo4j.repository.Neo4jRepository;

public interface UseLevelTreeNeo4jRepository extends Neo4jRepository<UseLevelTree, String> {
}
