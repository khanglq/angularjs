package com.hav.st.core.service.domain;

import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import com.hav.st.core.models.FullLevelTreeModel;

import java.util.Collection;

public interface LevelTreeService {
    FullLevelTreeModel getTree(LevelTree levelTree);
    FullLevelTreeModel addTree(LevelTree levelTree);
    boolean updateTreePartially(LevelTree levelTree);
    FullLevelTreeModel addLevels(LevelTree levelTree, Collection<Level> levels);
}
