package com.hav.st.core.service.db.pg;

import com.hav.st.core.entities.pg.EmployeeAddress;
import com.hav.st.core.repository.pg.EmployeeAddressPgRepository;
import com.hav.st.core.service.db.GenericDbService;

import java.util.Collection;
import java.util.UUID;

public interface EmployeeAddressPgService extends GenericDbService<EmployeeAddress, UUID, EmployeeAddressPgRepository> {
    void saveAll(Collection<EmployeeAddress> employeeAddresses);
}
