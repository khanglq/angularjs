package com.hav.st.core.service.db.neo4j.impl;

import com.hav.st.core.entities.neo4j.node.Employee;
import com.hav.st.core.repository.neo4j.node.EmployeeNeo4jRepository;
import com.hav.st.core.service.db.GenericDbServiceImpl;
import com.hav.st.core.service.db.neo4j.EmployeeNeo4jService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@Transactional("neo4jTransactionManager")
public class EmployeeNeo4jServiceImpl extends GenericDbServiceImpl<Employee, String, EmployeeNeo4jRepository> implements EmployeeNeo4jService {

    @Autowired
    private EmployeeNeo4jRepository repository;

    @Override
    protected EmployeeNeo4jRepository getRepository() {
        return repository;
    }

    @Override
    public Optional<Employee> findByEmpId(String employeeId) {
        return repository.findByEmpId(employeeId);
    }
}