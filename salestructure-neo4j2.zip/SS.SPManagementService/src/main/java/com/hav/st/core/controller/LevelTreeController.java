package com.hav.st.core.controller;

import com.hav.st.common.dto.DataRequestDTO;
import com.hav.st.common.dto.ResponseMessageOnSuccess;
import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import com.hav.st.core.models.FullLevelTreeModel;
import com.hav.st.core.service.domain.LevelTreeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;

@Api(value = "level-tree", tags = {"/level-trees v1"}, description = "Levels management service")
@RestController
@RequestMapping("/api/v1/level-trees")
public class LevelTreeController extends BaseController {

    private static final Logger logger = LogManager.getLogger(LevelTreeController.class);
    private LevelTreeService levelTreeService;

    public LevelTreeController(LevelTreeService levelTreeService) {
        this.levelTreeService = levelTreeService;
    }

    @ApiOperation(value = "Get Specific Level Tree")
    @GetMapping("/{treeId}")
    public ResponseEntity<ResponseMessageOnSuccess<FullLevelTreeModel>> getSpecificLevelTree(@PathVariable("treeId") String treeId) {
        LevelTree levelTree = new LevelTree();
        levelTree.setId(treeId);
        return ok(levelTreeService.getTree(levelTree));
    }

    @ApiOperation(value = "Create new level tree")
    @PostMapping(params = "cmd=create")
    public ResponseEntity<ResponseMessageOnSuccess<FullLevelTreeModel>> createNewLevelTree(@RequestBody DataRequestDTO<LevelTree> dtoLevelTree) {
        throwIfBadDTO(dtoLevelTree);
        return created(levelTreeService.addTree(dtoLevelTree.getData()));
    }

    @ApiOperation(value = "Update level tree partially")
    @PatchMapping(params = "cmd=update")
    public ResponseEntity<ResponseMessageOnSuccess<String>> updateTreePartially(@RequestBody DataRequestDTO<LevelTree> dtoLevelTree) {
        throwIfBadDTO(dtoLevelTree);
        return levelTreeService.updateTreePartially(dtoLevelTree.getData()) ? ok() : notModified();
    }

    @ApiOperation(value = "Add levels to tree")
    @PostMapping(value = "/{treeId}/_levels", params = "cmd=create")
    public ResponseEntity<ResponseMessageOnSuccess<FullLevelTreeModel>> addLevelsToTree(@PathVariable("treeId") String treeId, @RequestBody DataRequestDTO<Collection<Level>> dtoLevels) {
        throwIfBadDTO(dtoLevels);

        LevelTree levelTree = new LevelTree();
        levelTree.setId(treeId);
        return created(levelTreeService.addLevels(levelTree, dtoLevels.getData()));
    }
}
