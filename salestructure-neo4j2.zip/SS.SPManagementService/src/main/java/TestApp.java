import lombok.SneakyThrows;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class TestApp {
    @SneakyThrows
    public static void main(String[] args) {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        Request request = new Request.Builder()
                .url("http://10.32.37.71:8000/salestructure/employees/EMP078")
                .method("GET", null)
                .addHeader("apiKey", "c2FsZXN0cnVjdHVyZQ==")
                .addHeader("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MDAwNjg0ODYsInVzZXJfbmFtZSI6ImFkbWluIiwiYXV0aG9yaXRpZXMiOlsiUk9MRV9BRE1JTiJdLCJqdGkiOiJiN2ViNGUzZC05NmQ1LTQ2MGItYWZkZS03ZDZmMWQ3ZTUyYjEiLCJjbGllbnRfaWQiOiJzYWxlcy1zdHJ1Y3R1cmUtd2ViIiwic2NvcGUiOlsicmVhZCIsIndyaXRlIl19.SCBknSedEHZfZFjepQlLjFywpeRN5CCssHyEU1H3F1Y")
                .build();
        Map<Integer, Integer> statusCounter = new ConcurrentHashMap<>();

        for (int i = 1; i <= 50; i++) {
            client.newCall(request).enqueue(new Callback() {


                @Override
                public void onFailure(final Call call, IOException e) {
                    statusCounter.computeIfPresent(-1, (k, v) -> v + 1);
                    statusCounter.computeIfAbsent(-1, k -> 1);
                }

                @Override
                public void onResponse(Call call, final Response response) throws IOException {
                    statusCounter.computeIfPresent(response.code(), (k, v) -> v + 1);
                    statusCounter.computeIfAbsent(response.code(), k -> 1);
                }
            });
        }

        Thread.sleep(30_000);
        for (Map.Entry<Integer, Integer> kvp : statusCounter.entrySet()) {
            System.out.println(String.format("%3d %d", kvp.getKey(), kvp.getValue()));
        }
    }
}
