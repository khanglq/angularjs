package utils;

import com.hav.st.core.domain.Employee;
import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import com.hav.st.core.domain.Position;
import com.hav.st.core.domain.SalesStructure;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Collectors;

public class GeneratorUtil {
    public static String random5Digits() {
        return String.valueOf((10000 + rad.nextInt(90000)));
    }

    public static String randomSalesId() {
        return randomSalesId(null);
    }

    public static String randomSalesId(String suffix) {
        if (StringUtils.isBlank(suffix)) {
            suffix = random5Digits();
        }
        return "HA-" + suffix;
    }

    public static String randomEmployeeId() {
        return randomEmployeeId(null);
    }

    public static String randomEmployeeId(String suffix) {
        if (StringUtils.isBlank(suffix)) {
            suffix = random5Digits();
        }
        return "EM-" + suffix;
    }

    private static final Random rad = new Random();
    private static final String[] nameParts = new String[]{
            "Mohamed", "Youssef", "Ahmed", "Mahmoud", "Mustafa", "Yassin", "Taha", "Khaled", "Hamza", "Bilal", "Ibrahim", "Hassan", "Hussein", "Karim", "Tareq", "Abdel-Rahman", "Ali", "Omar", "Halim", "Murad", "Selim", "Abdallah", "Paulos", "Petros", "Gabreal", "Giorgis", "Yonas", "Yonathan", "Abraham", "Ammanuel", "Markos", "Michael", "Nahom", "Shaimaa", "Fatma", "Maha", "Reem", "Farida", "Aya", "Shahd", "Ashraqat", "Sahar", "Fatin", "Dalal", "Doha", "Fajr", "Suha", "Rowan", "Hosniya", "Hasnaa", "Hosna", "Gamila", "Gamalat", "Habiba", "Mariamawit", "Ruth", "Mariam", "Helen", "Christina", "Hanna", "Naomie", "Martha", "Meron", "Lidya", "Eden"
    };

    public static String randomHumanName() {
        StringBuilder sb = new StringBuilder();
        int length = rad.nextInt(4) + 2;
        do {
            sb.append(nameParts[rad.nextInt(nameParts.length)]);
            sb.append(" ");
        } while (--length > 0);
        return sb.toString().trim();
    }

    public static String randomString(int length) {
        if (length < 1)
            throw new IllegalArgumentException("length must > 0");

        StringBuilder sb = new StringBuilder();
        int remain = length;
        do {
            sb.append(UUID.randomUUID().toString().replaceAll("-", ""));
            remain -= 32;
        } while (remain > 0);

        return sb.toString().substring(0, length);
    }

    public static String randomString() {
        return randomString(8);
    }

    public static java.util.Date randomDate(int year) {
        return randomDate(year, rad.nextInt(12) + 1);
    }

    public static java.util.Date randomDate(int year, int month) {
        int day = rad.nextInt(28);
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month - 1, day);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    public static Employee randomDomainEmployee() {
        String randomDigits = random5Digits();

        Employee employee = new Employee();
        employee.setEmployeeId(randomEmployeeId(randomDigits));
        employee.setSalesId(randomSalesId(randomDigits));
        employee.setName(randomHumanName());
        employee.setPhoneNo("03333" + random5Digits());
        // TODO fix test
        /*
        employee.setAddress("Address of " + randomDigits);
        employee.setProbationDate(randomDate(2015, 6));
        employee.setFromDate(employee.getProbationDate());
         */

        return employee;
    }

    public static LevelTree randomDomainLevelTree() {
        String randomDigits = random5Digits();

        LevelTree levelTree = new LevelTree();
        levelTree.setName("Level tree " + randomDigits);
        levelTree.setDescription("Description of LT " + randomDigits);

        return levelTree;
    }

    public static Collection<Level> randomDomainLevel(int size) {
        List<Level> levels = new ArrayList<>();
        do {
            String randomCode = randomString(3);

            Level level = new Level();
            level.setName(randomCode.toLowerCase());
            level.setLevelCode(randomCode.toUpperCase());
            level.setLevel(size);

            levels.add(level);
        } while (--size > 0);

        return levels.stream().sorted(Comparator.comparingInt(Level::getLevel)).collect(Collectors.toList());
    }

    public static SalesStructure randomDomainSalesStructure() {
        String randomDigits = random5Digits();

        SalesStructure salesStructure = new SalesStructure();

        salesStructure.setName("Sales Structure " + randomDigits);
        salesStructure.setDescription("Desc of sales structure " + randomDigits);
        salesStructure.setFromDate(randomDate(2016, 3));

        return salesStructure;
    }

    public static Position randomDomainPosition(Employee employee, Level level) {
        Position position = new Position();
        position.setFromDate(employee.getFromDate());
        position.setSalesId(employee.getSalesId());
        position.setLevelCode(level.getLevelCode());

        return position;
    }
}
