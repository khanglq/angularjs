package it.controllers;

import com.hav.st.core.controller.LevelTreeController;
import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import com.hav.st.core.models.FullLevelTreeModel;
import lombok.SneakyThrows;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Arrays;
import java.util.Collection;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static utils.GeneratorUtil.random5Digits;
import static utils.GeneratorUtil.randomDomainLevel;
import static utils.GeneratorUtil.randomDomainLevelTree;
import static utils.GeneratorUtil.randomString;

public class LevelTreeControllerTest extends AbstractTest {

    @SneakyThrows
    @Test
    public void createAndGetLevelTree() {
        verifyLevelTree(createRandomLevelTree());

        String uri = "/level-tree/" + randomString() + "_NEVER_EXISTS";
        MvcResult mvcResult = mvcLevelTree.perform(
                MockMvcRequestBuilders.get(uri)
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        assertEquals(HttpStatus.NOT_FOUND.value(), mvcResult.getResponse().getStatus());
    }

    @SneakyThrows
    @Test
    public void updateLevelTree() {
        LevelTree levelTree = createRandomLevelTree();

        assertEquals(HttpStatus.NOT_MODIFIED.value(), updateLevelTree(levelTree));
        levelTree.setName("NEW TREE NAME " + random5Digits());
        assertEquals(HttpStatus.OK.value(), updateLevelTree(levelTree));
        assertEquals(HttpStatus.NOT_MODIFIED.value(), updateLevelTree(levelTree));
        String uri = "/level-tree/" + levelTree.getId();
        MvcResult mvcResult = mvcLevelTree.perform(
                MockMvcRequestBuilders.get(uri)
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals(HttpStatus.OK.value(), status);
        LevelTree resultLevelTree = super.mapFromJson(content, FullLevelTreeModel.class).getLevelTree();
        assertNotNull(resultLevelTree);
        assertEquals(resultLevelTree.getId(), levelTree.getId());
        assertEquals(resultLevelTree.getName(), levelTree.getName());
        assertEquals(resultLevelTree.getDescription(), levelTree.getDescription());
    }

    @Test
    public void addLevelToTree() {
        LevelTree levelTree = createRandomLevelTree();
        Level level = randomDomainLevel(1).stream().findFirst().get();

        level = addLevelToTree(levelTree, level);
        assertNotNull(level);
        assertNotNull(level.getId());
    }

    @Test
    public void addLevelsToTree() {
        LevelTree levelTree = createRandomLevelTree();
        Collection<Level> levels = randomDomainLevel(2);

        levels = addLevelsToTree(levelTree, levels);
        assertNotNull(levels);
        assertEquals(2, levels.size());
    }
}
