package it.controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hav.st.core.SalesStructureServiceApplication;
import com.hav.st.core.controller.EmployeeController;
import com.hav.st.core.controller.LevelTreeController;
import com.hav.st.core.controller.SalesStructureController;
import com.hav.st.core.domain.Employee;
import com.hav.st.core.domain.Level;
import com.hav.st.core.domain.LevelTree;
import com.hav.st.core.entities.functional.ApprovalStates;
import com.hav.st.core.exceptions.handler.ApiExceptionHandler;
import com.hav.st.core.models.ApprovalModel;
import com.hav.st.core.models.FullLevelTreeModel;
import lombok.SneakyThrows;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.method.annotation.ExceptionHandlerMethodResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver;
import org.springframework.web.servlet.mvc.method.annotation.ServletInvocableHandlerMethod;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static utils.GeneratorUtil.randomDomainEmployee;
import static utils.GeneratorUtil.randomDomainLevelTree;
import static utils.GeneratorUtil.randomString;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = SalesStructureServiceApplication.class)
@WebAppConfiguration
@EnableWebMvc
public abstract class AbstractTest {

    protected MockMvc mvcEmployee;
    protected MockMvc mvcLevelTree;
    protected MockMvc mvcSalesStructure;

    @Autowired
    WebApplicationContext webApplicationContext;

    @Autowired
    protected EmployeeController employeeController;

    @Autowired
    protected LevelTreeController levelTreeController;

    @Autowired
    protected SalesStructureController salesStructureController;

    @Before
    public void setUp() {
        mvcEmployee = MockMvcBuilders.standaloneSetup(employeeController)
                .setHandlerExceptionResolvers(createExceptionResolver())
                .build();

        mvcLevelTree = MockMvcBuilders.standaloneSetup(levelTreeController)
                .setHandlerExceptionResolvers(createExceptionResolver())
                .build();

        mvcSalesStructure = MockMvcBuilders.standaloneSetup(salesStructureController)
                .setHandlerExceptionResolvers(createExceptionResolver())
                .build();
    }

    private ExceptionHandlerExceptionResolver createExceptionResolver() {
        ExceptionHandlerExceptionResolver exceptionResolver = new ExceptionHandlerExceptionResolver() {
            protected ServletInvocableHandlerMethod getExceptionHandlerMethod(HandlerMethod handlerMethod, Exception exception) {
                Method method = new ExceptionHandlerMethodResolver(ApiExceptionHandler.class).resolveMethod(exception);
                return new ServletInvocableHandlerMethod(new ApiExceptionHandler(), method);
            }
        };
        exceptionResolver.afterPropertiesSet();
        return exceptionResolver;
    }

    protected String mapToJson(Object obj) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(obj);
    }

    protected <T> T mapFromJson(String json, Class<T> clazz)
            throws IOException {

        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(json, clazz);
    }

    private static final double DELTA = 1e-15;

    protected void assertEqualsDouble(double d1, double d2) {
        assertEquals(d1, d2, DELTA);
    }

    //


    @SneakyThrows
    protected Level addLevelToTree(LevelTree levelTree, Level level) {
        assertNotNull(levelTree.getId());

        String uri = "/level-tree/" + levelTree.getId() + "/_level";
        MvcResult mvcResult = mvcLevelTree.perform(
                MockMvcRequestBuilders.post(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapToJson(level))
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals(HttpStatus.CREATED.value(), status);
        Collection<Level> levels = mapFromJson(content, FullLevelTreeModel.class).getLevels();
        assertFalse(CollectionUtils.isEmpty(levels));
        Level resultLevel = levels.stream().filter(x -> x.getLevelCode().equals(level.getLevelCode())).findFirst().get();
        assertNotNull(resultLevel);

        return resultLevel;
    }

    @SneakyThrows
    protected Collection<Level> addLevelsToTree(LevelTree levelTree, Collection<Level> levels) {
        assertNotNull(levelTree.getId());

        String uri = "/level-tree/" + levelTree.getId() + "/_level/_batch";
        MvcResult mvcResult = mvcLevelTree.perform(
                MockMvcRequestBuilders.post(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapToJson(levels))
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals(HttpStatus.CREATED.value(), status);
        FullLevelTreeModel fullLevelTreeModel = mapFromJson(content, FullLevelTreeModel.class);
        assertNotNull(fullLevelTreeModel);
        assertFalse(CollectionUtils.isEmpty(fullLevelTreeModel.getLevels()));
        List<Level> collect = fullLevelTreeModel.getLevels().stream().filter(x -> levels.stream().filter(y -> y.getLevelCode().equals(x.getLevelCode())).findFirst().isPresent()).collect(Collectors.toList());
        Level[] resultLevels = collect.toArray(new Level[collect.size()]);
        assertEquals(levels.size(), resultLevels.length);
        assertNotNull(resultLevels);

        return Arrays.asList(resultLevels);
    }

    @SneakyThrows
    protected int updateLevelTree(LevelTree levelTree) {
        String uri = "/level-tree";
        MvcResult mvcResult = mvcLevelTree.perform(
                MockMvcRequestBuilders.patch(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapToJson(levelTree))
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        return mvcResult.getResponse().getStatus();
    }

    @SneakyThrows
    protected LevelTree createRandomLevelTree() {
        LevelTree levelTree = randomDomainLevelTree();

        String uri = "/level-tree";
        MvcResult mvcResult = mvcLevelTree.perform(
                MockMvcRequestBuilders.post(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapToJson(levelTree))
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals(HttpStatus.CREATED.value(), status);
        FullLevelTreeModel resultFullLevelTreeModel = mapFromJson(content, FullLevelTreeModel.class);
        assertNotNull(resultFullLevelTreeModel);
        assertNotNull(resultFullLevelTreeModel.getLevelTree());

        return resultFullLevelTreeModel.getLevelTree();
    }

    @SneakyThrows
    protected void verifyLevelTree(LevelTree levelTree) {
        assertNotNull(levelTree.getId());

        String uri = "/level-tree/" + levelTree.getId();
        MvcResult mvcResult = mvcLevelTree.perform(
                MockMvcRequestBuilders.get(uri)
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals(HttpStatus.OK.value(), status);
        FullLevelTreeModel resultFullLevelTreeModel = mapFromJson(content, FullLevelTreeModel.class);
        assertNotNull(resultFullLevelTreeModel);
        LevelTree resultLevelTree = resultFullLevelTreeModel.getLevelTree();
        assertNotNull(resultLevelTree);
        assertEquals(resultLevelTree.getId(), levelTree.getId());
        assertEquals(resultLevelTree.getName(), levelTree.getName());
        assertEquals(resultLevelTree.getDescription(), levelTree.getDescription());
    }


    @SneakyThrows
    protected int approveEmployees(Employee[] employees, ApprovalStates newState) {
        ApprovalModel<Employee> approvalModel = new ApprovalModel<>();
        approvalModel.setCollection(Arrays.asList(employees));
        approvalModel.setApprovalState(newState);

        String uri = "/employees/_approval/_batch";
        MvcResult mvcResult = mvcEmployee.perform(
                MockMvcRequestBuilders.post(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapToJson(approvalModel))
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        return mvcResult.getResponse().getStatus();
    }

    @SneakyThrows
    protected void verifyEmployee(Employee employee) {
        assertNotNull(employee.getEmployeeId());

        String uri = "/employees/" + employee.getEmployeeId();
        MvcResult mvcResult = mvcEmployee.perform(
                MockMvcRequestBuilders.get(uri)
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals(HttpStatus.OK.value(), status);
        Employee resultEmployee = mapFromJson(content, Employee.class);
        assertNotNull(resultEmployee);
        assertEquals(resultEmployee.getEmployeeId(), employee.getEmployeeId());
        assertEquals(resultEmployee.getSalesId(), employee.getSalesId());
        // TODO fix test
        /*
        assertEquals(resultEmployee.getProbationDate(), employee.getProbationDate());
        assertEquals(resultEmployee.getFromDate(), employee.getFromDate());
         */
        assertEquals(ApprovalStates.PENDING, resultEmployee.getApprovalState());
    }

    @SneakyThrows
    protected void verifyEmployeeNotExists() {
        String uri = "/employees/" + randomString(32) + "_never_exists";
        MvcResult mvcResult = mvcEmployee.perform(
                MockMvcRequestBuilders.get(uri)
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.NOT_FOUND.value(), status);
    }

    @SneakyThrows
    protected Employee createEmployee() {
        String uri = "/employees";
        MvcResult mvcResult = mvcEmployee.perform(
                MockMvcRequestBuilders.post(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapToJson(randomDomainEmployee()))
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals(HttpStatus.CREATED.value(), status);
        Employee resultEmployee = mapFromJson(content, Employee.class);
        assertNotNull(resultEmployee);
        return resultEmployee;
    }

    @SneakyThrows
    protected Employee[] createEmployeeInBatch() {
        String uri = "/employees/_batch";

        List<Employee> employees = new ArrayList<>();
        employees.add(randomDomainEmployee());
        employees.add(randomDomainEmployee());

        MvcResult mvcResult = mvcEmployee.perform(
                MockMvcRequestBuilders.post(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapToJson(employees))
                        .accept(MediaType.APPLICATION_JSON_VALUE)
        ).andReturn();

        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals(HttpStatus.CREATED.value(), status);
        Employee[] resultEmployees = mapFromJson(content, Employee[].class);
        assertNotNull(resultEmployees);
        assertTrue(resultEmployees.length == employees.size());

        return resultEmployees;
    }
}