package it.controllers;

import com.hav.st.core.domain.Employee;
import com.hav.st.core.entities.functional.ApprovalStates;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import static org.junit.Assert.assertEquals;

public class EmployeeControllerTest extends AbstractTest {

    @Test
    public void createAndGetEmployees() throws Exception {
        Employee createdEmployee = createEmployee();
        verifyEmployee(createdEmployee);
        Employee[] createdEmployees = createEmployeeInBatch();
        for (Employee employee : createdEmployees) {
            verifyEmployee(employee);
        }
        verifyEmployeeNotExists();
    }

    @Test
    public void approveEmployeesInBatch() throws Exception {
        Employee[] createdEmployees = createEmployeeInBatch();

        assertEquals(HttpStatus.BAD_REQUEST.value(), approveEmployees(createdEmployees, ApprovalStates.PENDING));
        assertEquals(HttpStatus.OK.value(), approveEmployees(createdEmployees, ApprovalStates.APPROVED));
        assertEquals(HttpStatus.NOT_ACCEPTABLE.value(), approveEmployees(createdEmployees, ApprovalStates.APPROVED));
        assertEquals(HttpStatus.NOT_ACCEPTABLE.value(), approveEmployees(createdEmployees, ApprovalStates.REJECTED));
    }
}