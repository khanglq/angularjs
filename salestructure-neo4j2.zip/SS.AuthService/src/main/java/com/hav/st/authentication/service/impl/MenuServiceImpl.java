package com.hav.st.authentication.service.impl;


import com.hav.st.authentication.domain.entity.pg.Menu;
import com.hav.st.authentication.dto.response.MenuData;
import com.hav.st.authentication.repository.MenuRepository;
import com.hav.st.authentication.service.MenuService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class MenuServiceImpl implements MenuService {

    @Autowired
    private MenuRepository menuRepository;

    //status of menu
    final int MENU_DISABLED = 0;
    final String MENU_STATUS_FRONTEND_SHOW = "show";
    final String MENU_STATUS_FRONTEND_HIDE = "hide";

    @Override
    public List<MenuData> getUserMenus(String username) {
        log.info("Getting menus of current logged-in user: " + username);
//get all menus with level 0
        List<Menu> rootMenus = menuRepository.findByParentId("root");
        if (rootMenus.isEmpty() || (rootMenus == null)) {
            log.info("No menu found in database, please make configuration for menus first.");
            return null;
        }
        List<MenuData> userMenus = new ArrayList<>();
        for (Menu rootMenu : rootMenus) {
            List<Menu> subMenus = menuRepository.findSubMenu(rootMenu.getMenuCode());
            MenuData menuData = buildMenuData(rootMenu, subMenus, username);
            userMenus.add(menuData);
        }

        return userMenus;
    }

    private MenuData buildMenuData(Menu dbMenu, List<Menu> subMenus, String username) {
        MenuData menuData = new MenuData();
        MenuData.Menu menu = new MenuData.Menu();
        menu.setName(dbMenu.getMenuName());
        menu.setUrl(dbMenu.getUrl());
        menu.setOrder(dbMenu.getOrder());
        if ("admin".equalsIgnoreCase(username)) {
            menu.setStatus(MENU_STATUS_FRONTEND_SHOW);
        } else {
            menu.setStatus(dbMenu.getStatus() == MENU_DISABLED ? MENU_STATUS_FRONTEND_HIDE : MENU_STATUS_FRONTEND_SHOW);
        }
        menuData.setMenu(menu);
        List<MenuData> subMenusData = new ArrayList<>();
        if (subMenus != null && !subMenus.isEmpty()) {
            for (Menu subMenu : subMenus) {
                MenuData subMenuData = buildMenuData(subMenu, menuRepository.findSubMenu(subMenu.getMenuCode()), username);
                subMenusData.add(subMenuData);
            }
        }
        if (subMenusData.size() > 0) {
            menu.setMenus(subMenusData);
        }
        return menuData;
    }
}
