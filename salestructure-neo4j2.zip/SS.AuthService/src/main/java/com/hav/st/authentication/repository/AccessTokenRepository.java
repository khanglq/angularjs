package com.hav.st.authentication.repository;

import com.hav.st.authentication.domain.entity.pg.OAuthAccessToken;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Transactional
@Repository
public interface AccessTokenRepository extends CrudRepository<OAuthAccessToken, String> {

    @Query("select e from OAuthAccessToken e where e.clientId=:clientId")
    List<OAuthAccessToken> findByClientId(String clientId);

    @Query("select e from OAuthAccessToken e where e.username =:username AND e.clientId=:clientId")
    List<OAuthAccessToken> findByClientIdAndUsername(String username, String clientId);

    @Query("select e from OAuthAccessToken e where e.tokenId =:tokenId")
    Optional<OAuthAccessToken> findByTokenId(String tokenId);

    @Query("select e from OAuthAccessToken e where e.refreshToken =:refreshToken")
    Optional<OAuthAccessToken> findByRefreshToken(String refreshToken);

    @Query("select e from OAuthAccessToken e where e.authenticationId =:authenticationId")
    Optional<OAuthAccessToken> findByAuthenticationId(String authenticationId);
}
