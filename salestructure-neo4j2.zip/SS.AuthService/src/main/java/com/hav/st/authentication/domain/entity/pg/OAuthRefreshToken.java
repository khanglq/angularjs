package com.hav.st.authentication.domain.entity.pg;

import com.hav.st.common.domain.entity.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "oauth_refresh_token")
public class OAuthRefreshToken extends AbstractEntity {

    @Id
    @Column(name = "token_id", length = 255)
    private String tokenId;

    //    @Lob
//    @Type(type = "org.hibernate.type.BlobType")
    @Column(name = "token")
    private byte[] token;

    //    @Lob
//    @Type(type = "org.hibernate.type.BlobType")
    @Column(name = "authentication")
    private byte[] authentication;

}
