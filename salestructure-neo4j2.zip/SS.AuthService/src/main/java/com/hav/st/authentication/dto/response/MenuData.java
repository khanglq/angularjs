package com.hav.st.authentication.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MenuData {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Menu menu;

    @Data
    public static class Menu {
        private String name;
        private String url;
        private String status;
        private int order;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private List<MenuData> menus;
    }
}