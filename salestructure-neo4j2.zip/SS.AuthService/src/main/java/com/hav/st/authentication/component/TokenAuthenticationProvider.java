package com.hav.st.authentication.component;

import com.hav.st.authentication.constant.AuthConstant;
import com.hav.st.authentication.domain.entity.pg.Authority;
import com.hav.st.authentication.domain.entity.pg.User;
import com.hav.st.authentication.repository.UserRepository;
import com.hav.st.common.utils.CryptoUtils;
import com.hav.st.common.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import javax.naming.Context;
import javax.naming.directory.InitialDirContext;
import java.util.*;

@Component(value = "tokenAuthenticationProvider")
public class TokenAuthenticationProvider implements AuthenticationProvider {

    @Autowired
    UserRepository userRepository;


    @Override
    public Authentication authenticate(Authentication authentication)
            throws AuthenticationException {
        String username = authentication.getName();
        String password = authentication.getCredentials().toString();
        if (StringUtils.isEmpty(username) || StringUtils.isEmpty(password)) {
            throw new BadCredentialsException("Invalid Username or password");
        }
        User user = userRepository.findByUsernameCaseInsensitive(username);
        if (user == null) {
            throw new BadCredentialsException("Invalid Username or password");
        }
        boolean isInvalidUsernameORPwd = false;
        if (AuthConstant.AUTH_BACK.equalsIgnoreCase(user.getAuthType())) {
            if (!user.getPassword().equals(CryptoUtils.md5(password))) {
                isInvalidUsernameORPwd = true;
            }
        } else if (AuthConstant.AUTH_LDAP.equalsIgnoreCase(user.getAuthType())) {
            if (!ldapAuth(username, password)) {
                isInvalidUsernameORPwd = true;
            }
        } else {
            throw new BadCredentialsException("Not supported authentication method");
        }
        if (isInvalidUsernameORPwd) {
            throw new BadCredentialsException("Invalid Username or password");
        }
        Collection<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        for (Authority authority : user.getAuthorities()) {
            GrantedAuthority grantedAuthority = new SimpleGrantedAuthority(authority.getName());
            grantedAuthorities.add(grantedAuthority);
        }
        Authentication auth = new UsernamePasswordAuthenticationToken(username, password, grantedAuthorities);
        return auth;
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(
                UsernamePasswordAuthenticationToken.class);
    }

    private static final String DN = "DC=vpbs,DC=com,DC=vn";
    private static String HOST = "10.32.32.11";

    private boolean ldapAuth(String username, String password) {
        Hashtable<String, Object> env = new Hashtable<>();
        String principalName = "VPBS\\" + username;
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, "ldap://" + HOST + ":389/" + DN);
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put("com.sun.jndi.ldap.connect.timeout", "5000");
        env.put(Context.SECURITY_PRINCIPAL, principalName);
        env.put(Context.SECURITY_CREDENTIALS, password);
        try {
            new InitialDirContext(env);
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
}