package com.hav.st.authentication.domain.entity.pg;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hav.st.common.domain.entity.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Date;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "oauth_access_token")
public class OAuthAccessToken extends AbstractEntity {

    @Id
    @Column(name = "token_id", length = 255)
    private String tokenId;

    @Column(name = "token")
    private byte[] token;

    @Column(name = "authentication_id", length = 255)
    private String authenticationId;

    @Column(name = "user_name", length = 255)
    private String username;

    @Column(name = "client_id", length = 255)
    private String clientId;

    @Column(name = "authentication")
    private byte[] authentication;

    @Column(name = "refresh_token", length = 255)
    private String refreshToken;

    @Column(name = "expiration")
    private Date expiration;
    @Column(name = "expiresIn")
    private int expiresIn;
    @Column(name = "tokenType")
    private String tokenType;

}
