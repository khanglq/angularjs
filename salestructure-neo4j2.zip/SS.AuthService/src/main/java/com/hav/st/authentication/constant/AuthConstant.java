package com.hav.st.authentication.constant;

public class AuthConstant {
    public static final String AUTH_LDAP = "LDAP";
    public static final String AUTH_BACK = "BACK";


    public static final String SERVICE_FRONTEND = "SaleStructureWeb";
    public static final String SERVICE_SP_MANAGEMENT = "SPManagementService";
}
