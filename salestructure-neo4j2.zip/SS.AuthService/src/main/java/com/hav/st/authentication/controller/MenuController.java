package com.hav.st.authentication.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hav.st.authentication.dto.response.MenuData;
import com.hav.st.authentication.service.MenuService;
import com.hav.st.common.constant.CommonConstant;
import com.hav.st.common.controller.BaseController;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.JsonParser;
import org.springframework.boot.json.JsonParserFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(CommonConstant.API_V1)
@Slf4j
public class MenuController extends BaseController {

    @Autowired
    MenuService menuService;

//    @GetMapping(value = "menus", produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<String> getAllMenus() {
//        return new ResponseEntity<>(jsonMenus, HttpStatus.OK);
//    }

    @GetMapping(value = "menus", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getMenusByUser(@RequestParam(defaultValue = "admin", required = false) String username) throws IOException {
//        Map<String, Object> reqBody = parseJson(jsonBody);
//        String username = (String) reqBody.get("username");

        List<MenuData> menuDataList = menuService.getUserMenus(username);
        Map<String, Object> result = new HashMap<>();
        result.put("menus", menuDataList);
        ObjectMapper objectMapper = new ObjectMapper();
        return new ResponseEntity<>(objectMapper.writeValueAsString(result), HttpStatus.OK);
    }

//    private String jsonMenus = "{ \"menus\": [{ \"menu\": { \"name\": \"Thông tin nhân sự\", \"url\": \"/employee\", \"status\": \"show\", \"order\": 1, \"menus\": [{ \"menu\": { \"name\": \"Danh sách nhân sự\", \"url\": \"/employee/list-employee\", \"status\": \"show\", \"order\": 1 } }, { \"menu\": { \"name\": \"Thêm mới nhân sự\", \"url\": \"/employee/add-employee\", \"status\": \"show\", \"order\": 2 } }, { \"menu\": { \"name\": \"Phê Duyệt\", \"url\": \"/employee/approve-employee\", \"status\": \"show\", \"order\": 3 } } ] } }, { \"menu\": { \"name\": \"Hợp đồng nhân sự\", \"url\": \"/contract\", \"status\": \"show\", \"order\": 2, \"menus\": [{ \"menu\": { \"name\": \"Danh sách hợp đồng\", \"url\": \"/contract/list-contract\", \"status\": \"show\", \"order\": 1 } }, { \"menu\": { \"name\": \"Tạo hợp đồng\", \"url\": \"/contract/create-contract\", \"status\": \"show\", \"order\": 2 } }, { \"menu\": { \"name\": \"Thanh lý\", \"url\": \"/contract/liquidate-contract\", \"status\": \"show\", \"order\": 3 } }, { \"menu\": { \"name\": \"Phê Duyệt\", \"url\": \"/contract/approve-contract\", \"status\": \"show\", \"order\": 4 } } ] } }, { \"menu\": { \"name\": \"Mô hình kinh doanh\", \"url\": \"/sale-structure\", \"status\": \"show\", \"order\": 3, \"menus\": [{ \"menu\": { \"name\": \"Danh sách mô hình\", \"url\": \"/sale-structure/list-sale-structure\", \"status\": \"show\", \"order\": 1 } }, { \"menu\": { \"name\": \"Gán mô hình\", \"url\": \"/sale-structure/assign\", \"status\": \"show\", \"order\": 2 } }, { \"menu\": { \"name\": \"Duyệt mô hình\", \"url\": \"/sale-structure/approve\", \"status\": \"show\", \"order\": 3 } } ] } }, { \"menu\": { \"name\": \"Khách hàng\", \"url\": \"/customer\", \"status\": \"show\", \"order\": 4, \"menus\": [{ \"menu\": { \"name\": \"Khách hàng\", \"url\": \"/customer/assign-customer\", \"status\": \"show\", \"order\": 1 } } ] } }, { \"menu\": { \"name\": \"Hoa Hồng-Phí QL\", \"url\": \"/fees\", \"status\": \"show\", \"order\": 5, \"menus\": [{ \"menu\": { \"name\": \"Chi trả\", \"url\": \"/fees/payment\", \"status\": \"show\", \"order\": 1 } } ] } }, { \"menu\": { \"name\": \"KPI\", \"url\": \"/kpi\", \"status\": \"show\", \"order\": 6, \"menus\": [{ \"menu\": { \"name\": \"KPI\", \"url\": \"/kpi/list-kpi\", \"status\": \"show\", \"order\": 1 } } ] } }, { \"menu\": { \"name\": \"Báo cáo\", \"url\": \"/report\", \"status\": \"show\", \"order\": 7, \"menus\": [{ \"menu\": { \"name\": \"Báo cáo\", \"url\": \"/report/report\", \"status\": \"show\", \"order\": 1 } } ] } }, { \"menu\": { \"name\": \"Hệ thống\", \"url\": \"/system\", \"status\": \"show\", \"order\": 8, \"menus\": [{ \"menu\": { \"name\": \"Hệ thống\", \"url\": \"/system/system\", \"status\": \"show\", \"order\": 1 } } ] } } ] } ";

    private Map<String, Object> parseJson(String jsonString) {
        JsonParser jsonParser = JsonParserFactory.getJsonParser();
        return jsonParser.parseMap(jsonString);
    }
}
