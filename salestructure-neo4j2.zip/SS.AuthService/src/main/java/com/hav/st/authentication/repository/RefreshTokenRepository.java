package com.hav.st.authentication.repository;

import com.hav.st.authentication.domain.entity.pg.OAuthRefreshToken;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Transactional
@Repository
public interface RefreshTokenRepository extends CrudRepository<OAuthRefreshToken, String> {
//    List<OAuthRefreshToken> findByClientId(String clientId);

    //    List<OAuthRefreshToken> findByClientIdAndUsername(String clientId, String username);
    @Query("select e from OAuthRefreshToken e where e.tokenId =:tokenId")
    Optional<OAuthRefreshToken> findByTokenId(String tokenId);

//    @Query("select e from OAuthRefreshToken e where e.tokenId =:tokenId")
//    Optional<OAuthRefreshToken> findByRefreshToken(String token);

//    Optional<OAuthRefreshToken> findByAuthenticationId(String authenticationId);

}
