package com.hav.st.authentication.service;

import com.hav.st.authentication.domain.entity.pg.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Map;

public interface UserService {

    User findById(String id);

    Page<User> getUsers(Map<String, String> filters, Pageable pageable);

    User add(User user);

}
