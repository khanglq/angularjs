package com.hav.st.authentication.repository;

import com.hav.st.authentication.domain.entity.pg.Menu;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MenuRepository extends JpaRepository<Menu, String> {

    List<Menu> findByParentId(String parentId);

    @Query("SELECT e FROM Menu e WHERE e.parentId= :menuCode ORDER BY e.order")
    List<Menu> findSubMenu(@Param("menuCode") String menuCode);
}
