package com.hav.st.authentication.domain.entity.pg;

import com.hav.st.common.domain.entity.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "oauth_approvals")
public class OAuthApprovals extends AbstractEntity {

    @Id
    @Column(name = "user_id", length = 255)
    private String userId;

    @Column(name = "client_id", length = 255)
    private String clientId;

    @Column(name = "scope", length = 255)
    private String scope;

    @Column(name = "status", length = 255)
    private String status;

    @Column(name = "expires_at", length = 255)
    private String expiresAt;

    @Column(name = "last_modified_at", length = 255)
    private Date lastModifiedAt;

}
