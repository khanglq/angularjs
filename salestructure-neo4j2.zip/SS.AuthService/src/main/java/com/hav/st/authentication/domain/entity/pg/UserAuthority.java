package com.hav.st.authentication.domain.entity.pg;

import com.hav.st.common.domain.entity.AbstractEntity;
import com.hav.st.common.domain.entity.AbstractPk;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "user_authority")
public class UserAuthority extends AbstractEntity {

    @EmbeddedId
    private Pk pk = new Pk();

    public Pk getPk() {
        return this.pk;
    }

    private void setPk(Pk pk) {

    }

    @Column(name = "description")
    private String description;
    @Column(name = "effective_from")
    private Date effectiveFrom;
    @Column(name = "effective_to")
    private Date effectiveTo;
    @Column(name = "status")
    private int status;


    @Data
    @NoArgsConstructor
    @Embeddable
    public static class Pk extends AbstractPk {
        @Column
        private String username;
        @Column
        private String authority;
    }
}
