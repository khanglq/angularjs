package com.hav.st.authentication.domain.entity.pg;

import com.hav.st.common.domain.entity.AbstractEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "feature")
public class Feature extends AbstractEntity {
    @Id
    @Column(name = "feature_code")
    String featureCode;

    @Column(name = "feature_name")
    String featureName;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "feature")
    private List<Menu> menuList = new ArrayList<>();

}
