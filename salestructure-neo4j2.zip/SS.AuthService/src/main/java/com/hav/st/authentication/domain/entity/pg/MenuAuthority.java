package com.hav.st.authentication.domain.entity.pg;

import com.hav.st.common.domain.entity.AbstractEntity;
import com.hav.st.common.domain.entity.AbstractPk;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "url_authority")
public class MenuAuthority extends AbstractEntity {

    @EmbeddedId
    private Pk pk = new Pk();

    public Pk getPk() {
        return this.pk;
    }

    private void setPk(Pk pk) {

    }


    @Data
    @NoArgsConstructor
    @Embeddable
    public static class Pk extends AbstractPk {
        @Column(name = "menu_code")
        private String menuCode;
        @Column
        private String authority;
    }
}
