package com.hav.st.authentication.domain.entity.pg;

import com.hav.st.common.domain.entity.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "menu")
public class Menu extends AbstractEntity {

    @Id
    @Column(name = "menu_code")
    String menuCode;

    @Column(name = "menu_name")
    String menuName;

    @Column(name = "url")
    String url;

    @Column(name = "status")
    int status;

    @Column(name = "menu_order")
    int order;

    @Column(name = "parent_id")
    String parentId;

    @Column(name = "method")
    String method;

    @Column(name = "service")
    String service;
//    @Column(name = "level")
//    int level;

    @ManyToOne
    @JoinColumn(name = "feature_code")
    private Feature feature;
}
