package com.hav.st.authentication.service;

import com.hav.st.authentication.dto.response.MenuData;

import java.util.List;

public interface MenuService {

    List<MenuData> getUserMenus(String username);
}
