package com.hav.st.authentication.component;

import com.hav.st.common.dto.ErrorMessage;
import com.hav.st.common.utils.HttpResponseUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.endpoint.TokenEndpoint;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.Map;

@RequestMapping
public class TokenManagement extends TokenEndpoint {

    private TokenStore tokenStore;

    public TokenManagement(TokenStore tokenStore) {
        this.tokenStore = tokenStore;
    }

    @PostMapping("/oauth/token")
    public ResponseEntity<OAuth2AccessToken> postAccessToken(Principal principal, @RequestParam Map<String, String> parameters) throws HttpRequestMethodNotSupportedException {
        return super.postAccessToken(principal, parameters);
    }

    @GetMapping("/oauth/revoke_token")
    public @ResponseBody
    ResponseEntity<HttpStatus> logout(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        if ("".equalsIgnoreCase(authHeader) || authHeader == null) {
            return badRequest("Couldn't find authorization in request header");
        }
        String tokenValue = authHeader.replace("Bearer", "").trim();
        if (!revokeToken(tokenValue)) {
            return NotFound("Token is not found");
        }
        return ok("Token is revoked");
    }

    private boolean revokeToken(String tokenValue) {
        OAuth2AccessToken accessToken = tokenStore.readAccessToken(tokenValue);
        if (accessToken == null) {
            return false;
        }
        if (accessToken.getRefreshToken() != null) {
            tokenStore.removeRefreshToken(accessToken.getRefreshToken());
        }
        tokenStore.removeAccessToken(accessToken);
        return true;
    }

    private <T> ResponseEntity ok(@Nullable T body) {
        return statusCodeWhenSuccess(body, HttpStatus.OK);
    }


    private <T> ResponseEntity statusCodeWhenSuccess(T data, HttpStatus httpStatus) {
        return HttpResponseUtil.Success(data, httpStatus);
    }

    private ResponseEntity NotFound(String message) {
        return statusCodeWhenError(message, HttpStatus.NOT_FOUND);
    }

    private <T> ResponseEntity statusCodeWhenError(String message, HttpStatus httpStatus) {
        return HttpResponseUtil.Error(new ErrorMessage(httpStatus.toString().toLowerCase().replaceAll("\\s", "_"), message), httpStatus);
    }

    protected ResponseEntity badRequest(String message) {
        return statusCodeWhenError(message, HttpStatus.BAD_REQUEST);
    }
}
