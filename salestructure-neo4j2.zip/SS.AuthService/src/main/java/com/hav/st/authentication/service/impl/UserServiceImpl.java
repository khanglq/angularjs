package com.hav.st.authentication.service.impl;

import com.hav.st.authentication.constant.AuthConstant;
import com.hav.st.authentication.domain.entity.pg.Authority;
import com.hav.st.authentication.domain.entity.pg.User;
import com.hav.st.authentication.repository.UserRepository;
import com.hav.st.authentication.exception.UserNotActivatedException;
import com.hav.st.authentication.service.UserService;
import com.hav.st.common.utils.CryptoUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.el.MethodNotFoundException;
import javax.persistence.EntityNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService, UserDetailsService {

    private final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional
    public UserDetails loadUserByUsername(final String username) {
        log.debug("Authenticating {}", username);
        String lowercaseUsername = username.toLowerCase();
        User userFromDatabase;
        if (lowercaseUsername.contains("@")) {
            userFromDatabase = userRepository.findByEmail(lowercaseUsername);
        } else {
            userFromDatabase = userRepository.findByUsernameCaseInsensitive(lowercaseUsername);
        }

        if (userFromDatabase == null) {
            throw new UsernameNotFoundException("User " + lowercaseUsername + " was not found in the database");
        } else if (!userFromDatabase.isActivated()) {
            throw new UserNotActivatedException("User " + lowercaseUsername + " is not activated");
        }

        Collection<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        for (Authority authority : userFromDatabase.getAuthorities()) {
            GrantedAuthority grantedAuthority = new SimpleGrantedAuthority(authority.getName());
            grantedAuthorities.add(grantedAuthority);
        }

        return new org.springframework.security.core.userdetails.User(userFromDatabase.getUsername(), userFromDatabase.getPassword(), grantedAuthorities);
    }

    @Override
    public User findById(String id) {
        Optional<User> optionalUser = userRepository.findById(id);
        return optionalUser.isPresent() ? optionalUser.get() : null;
    }

    @Override
    public Page<User> getUsers(Map<String, String> filters, Pageable pageable) {
        throw new MethodNotFoundException();
    }

    @Override
    public User add(User user) {
        user.setPassword(CryptoUtils.md5(user.getPassword()));
        return userRepository.save(user);
    }
}
