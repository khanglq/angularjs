package com.hav.st.authentication.controller;

import com.hav.st.authentication.domain.entity.pg.User;
import com.hav.st.authentication.service.UserService;
import com.hav.st.common.constant.CommonConstant;
import com.hav.st.common.controller.BaseController;
import com.hav.st.common.dto.ResponseMessageOnSuccess;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping(CommonConstant.API_V1 + "/user")
public class UserController extends BaseController {

    @Autowired
    UserService userService;

    @GetMapping("/{userid}")
    public ResponseEntity<ResponseMessageOnSuccess<User>> getUserById(@PathVariable("userid") String userid) {
        User user = userService.findById(userid);
        return user != null ? ok(userService.findById(userid)) : noContent("User is not found");
    }


    @GetMapping()
    public ResponseEntity<ResponseMessageOnSuccess<Page<User>>> getUsers(
            @RequestParam(value = "filter", required = false) Set<String> filters, Pageable pageable) {
        Map<String, String> mappedFilters = new HashMap<>();
        if (!CollectionUtils.isEmpty(filters)) {
            for (String filter : filters) {
                if (StringUtils.isEmpty(filter))
                    continue;
                String[] split = filter.split("=", 2);
                if (split.length != 2 || StringUtils.isEmpty(split[0]))
                    throw new IllegalArgumentException("Bad filter " + filter);
                if (StringUtils.isEmpty(split[1]))
                    throw new IllegalArgumentException("Bad filter value of " + split[0]);
                mappedFilters.put(split[0], split[1]);
            }
        }
        Page<User> users = userService.getUsers(mappedFilters, pageable);
        if (users.hasContent())
            return ok(users);
        else
            return noContent(users);
    }

    @PostMapping()
    public ResponseEntity<ResponseMessageOnSuccess<User>> createUser(@RequestBody User user) {
        return created(userService.add(user));
    }
}