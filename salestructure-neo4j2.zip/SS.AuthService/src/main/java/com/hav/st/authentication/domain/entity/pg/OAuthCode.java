package com.hav.st.authentication.domain.entity.pg;

import com.hav.st.common.domain.entity.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "oauth_code")
public class OAuthCode extends AbstractEntity {

    @Id
    @Column(name = "code", length = 255)
    private String code;

//    @Lob
//    @Type(type = "org.hibernate.type.MaterializedClobType")
//    @Column(name = "authentication")
//    private String authentication;

    @Lob
    @Type(type = "org.hibernate.type.MaterializedBlobType")
    @Column(name = "authentication")
    private byte[] authentication;
}
