package com.hav.st.authentication.domain.entity.pg;

import com.hav.st.common.domain.entity.AbstractEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "groups")
public class Group extends AbstractEntity {
    @Id
    @Column(name = "group_code")
    String groupCode;

    @Column(name = "group_name")
    String groupName;

}
