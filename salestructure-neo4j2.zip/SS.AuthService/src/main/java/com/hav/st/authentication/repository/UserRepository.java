package com.hav.st.authentication.repository;

import com.hav.st.authentication.domain.entity.pg.User;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;


public interface UserRepository extends CrudRepository<User, String> {

    @Query(" SELECT u FROM User u WHERE LOWER(u.username) = LOWER(:username)")
    User findByUsernameCaseInsensitive(@Param("username") String username);

    @Query
    User findByEmail(String email);


    @Query(" SELECT u FROM User u WHERE LOWER(u.username) = LOWER(:username) AND u.password=:password AND u.activated=true ")
    User authentication(@Param("username") String username, @Param("password") String password);
}
