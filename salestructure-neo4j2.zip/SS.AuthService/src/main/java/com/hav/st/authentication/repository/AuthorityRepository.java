package com.hav.st.authentication.repository;

import com.hav.st.authentication.domain.entity.pg.Authority;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuthorityRepository extends JpaRepository<Authority, String> {

}
