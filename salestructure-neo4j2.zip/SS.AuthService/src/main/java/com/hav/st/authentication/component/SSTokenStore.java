package com.hav.st.authentication.component;

import com.hav.st.authentication.domain.entity.pg.OAuthAccessToken;
import com.hav.st.authentication.domain.entity.pg.OAuthRefreshToken;
import com.hav.st.authentication.repository.AccessTokenRepository;
import com.hav.st.authentication.repository.RefreshTokenRepository;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2RefreshToken;
import org.springframework.security.oauth2.common.util.SerializationUtils;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.AuthenticationKeyGenerator;
import org.springframework.security.oauth2.provider.token.DefaultAuthenticationKeyGenerator;
import org.springframework.security.oauth2.provider.token.TokenStore;

import javax.persistence.EntityNotFoundException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public class SSTokenStore implements TokenStore {

    private static final Log LOG = LogFactory.getLog(SSTokenStore.class);
    private AuthenticationKeyGenerator authenticationKeyGenerator = new DefaultAuthenticationKeyGenerator();
    private AccessTokenRepository accessTokenRepository;

    private RefreshTokenRepository refreshTokenRepository;

    public SSTokenStore(AccessTokenRepository accessTokenRepository, RefreshTokenRepository refreshTokenRepository) {
        this.accessTokenRepository = accessTokenRepository;
        this.refreshTokenRepository = refreshTokenRepository;
    }

    @Override
    public OAuth2Authentication readAuthentication(OAuth2AccessToken token) {
        return this.readAuthentication(token.getValue());
    }

    @Override
    public OAuth2Authentication readAuthentication(String token) {
        OAuth2Authentication authentication = null;
        try {
            Optional<OAuthAccessToken> accessTokenOptional = this.accessTokenRepository.findByTokenId(extractTokenKey(token));
            if (accessTokenOptional.isPresent()) {
                authentication = deserializeAuthentication(accessTokenOptional.get().getAuthentication());
            } else {
                throw new EmptyResultDataAccessException(1);
            }
        } catch (EmptyResultDataAccessException e) {
            if (LOG.isInfoEnabled()) {
                LOG.info("Failed to find access token for token " + token);
            }
        } catch (IllegalArgumentException e) {
            LOG.warn("Failed to deserialize authentication for " + token, e);
            removeAccessToken(token);
        }
        return authentication;
    }

    @Override
    public void storeAccessToken(OAuth2AccessToken accessToken, OAuth2Authentication authentication) {
        String refreshToken = null;
        if (accessToken.getRefreshToken() != null) {
            refreshToken = accessToken.getRefreshToken().getValue();
        }

        if (readAccessToken(accessToken.getValue()) != null) {
            removeAccessToken(accessToken.getValue());
        }
        OAuthAccessToken oAuthAccessToken = new OAuthAccessToken();
        oAuthAccessToken.setTokenId(extractTokenKey(accessToken.getValue()));
        oAuthAccessToken.setToken(serializeAccessToken(accessToken));
        oAuthAccessToken.setAuthenticationId(authenticationKeyGenerator.extractKey(authentication));
        oAuthAccessToken.setUsername(authentication.isClientOnly() ? null : authentication.getName());
        oAuthAccessToken.setClientId(authentication.getOAuth2Request().getClientId());
        oAuthAccessToken.setAuthentication(serializeAuthentication(authentication));
        oAuthAccessToken.setRefreshToken(extractTokenKey(refreshToken));
        accessTokenRepository.save(oAuthAccessToken);
    }

    @Override
    public OAuth2AccessToken readAccessToken(String tokenValue) {
        OAuth2AccessToken accessToken = null;
        try {
            Optional<OAuthAccessToken> accessTokenOptional = accessTokenRepository.findByTokenId(extractTokenKey(tokenValue));
            if (accessTokenOptional.isPresent()) {
                accessToken = deserializeAccessToken(accessTokenOptional.get().getToken());
            } else {
                throw new EmptyResultDataAccessException(1);
            }
        } catch (EmptyResultDataAccessException e) {
            if (LOG.isInfoEnabled()) {
                LOG.info("Failed to find access token for token " + tokenValue);
            }
        } catch (IllegalArgumentException e) {
            LOG.warn("Failed to deserialize access token for " + tokenValue, e);
            removeAccessToken(tokenValue);
        }

        return accessToken;
    }

    @Override
    public void removeAccessToken(OAuth2AccessToken token) {
        removeAccessToken(token.getValue());
    }

    private void removeAccessToken(String tokenValue) {
        Optional<OAuthAccessToken> accessToken = accessTokenRepository.findByTokenId(extractTokenKey(tokenValue));
        if (accessToken.isPresent()) {
            accessTokenRepository.delete(accessToken.get());
        }
    }

    @Override
    public void storeRefreshToken(OAuth2RefreshToken refreshToken, OAuth2Authentication authentication) {
        OAuthRefreshToken oAuthRefreshToken = new OAuthRefreshToken();
        oAuthRefreshToken.setTokenId(extractTokenKey(refreshToken.getValue()));
        oAuthRefreshToken.setToken(serializeRefreshToken(refreshToken));
        oAuthRefreshToken.setAuthentication(serializeAuthentication(authentication));
        refreshTokenRepository.save(oAuthRefreshToken);
    }

    @Override
    public OAuth2RefreshToken readRefreshToken(String tokenValue) {
        OAuth2RefreshToken refreshToken = null;
        try {
            Optional<OAuthRefreshToken> refreshTokenOptional = refreshTokenRepository.findByTokenId(extractTokenKey(tokenValue));
            refreshToken = deserializeRefreshToken(refreshTokenOptional.orElseThrow(EntityNotFoundException::new).getToken());
        } catch (EntityNotFoundException e) {
            if (LOG.isInfoEnabled()) {
                LOG.info("Failed to find access token for token " + tokenValue);
            }
        } catch (IllegalArgumentException e) {
            LOG.warn("Failed to deserialize refresh token for token " + tokenValue, e);
            removeRefreshToken(tokenValue);
        }
        return refreshToken;
    }

    @Override
    public OAuth2Authentication readAuthenticationForRefreshToken(OAuth2RefreshToken token) {
        return readAuthenticationForRefreshToken(token.getValue());
    }

    private OAuth2Authentication readAuthenticationForRefreshToken(String tokenValue) {
        OAuth2Authentication authentication = null;
        try {
            Optional<OAuthRefreshToken> refreshTokenOptional = refreshTokenRepository.findByTokenId(extractTokenKey(tokenValue));
            authentication = deserializeAuthentication(refreshTokenOptional.orElseThrow(EntityNotFoundException::new).getAuthentication());
        } catch (EntityNotFoundException e) {
            if (LOG.isInfoEnabled()) {
                LOG.info("Failed to find access token for token " + tokenValue);
            }
        } catch (IllegalArgumentException e) {
            LOG.warn("Failed to deserialize access token for " + tokenValue, e);
            removeRefreshToken(tokenValue);
        }

        return authentication;
    }

    @Override
    public void removeRefreshToken(OAuth2RefreshToken token) {
        removeRefreshToken(token.getValue());
    }

    private void removeRefreshToken(String tokenValue) {
        Optional<OAuthRefreshToken> accessToken = refreshTokenRepository.findByTokenId(extractTokenKey(tokenValue));
        if (accessToken.isPresent()) {
            refreshTokenRepository.delete(accessToken.get());
        }
    }

    @Override
    public void removeAccessTokenUsingRefreshToken(OAuth2RefreshToken refreshToken) {
        removeAccessTokenUsingRefreshToken(refreshToken.getValue());
    }

    private void removeAccessTokenUsingRefreshToken(String tokenValue) {
        Optional<OAuthAccessToken> accessTokenOptional = accessTokenRepository.findByRefreshToken(extractTokenKey(tokenValue));
        if (accessTokenOptional.isPresent()) {
            accessTokenRepository.delete(accessTokenOptional.get());
        }
    }

    @Override
    public OAuth2AccessToken getAccessToken(OAuth2Authentication authentication) {
        OAuth2AccessToken accessToken = null;
        String key = authenticationKeyGenerator.extractKey(authentication);
        try {
            Optional<OAuthAccessToken> accessTokenOptional = accessTokenRepository.findByAuthenticationId(key);
            accessToken = deserializeAccessToken(accessTokenOptional.orElseThrow(EntityNotFoundException::new).getToken());
        } catch (EntityNotFoundException e) {
            if (LOG.isDebugEnabled()) {
                LOG.debug("Failed to find access token for authentication " + authentication);
            }
        } catch (IllegalArgumentException e) {
            LOG.error("Could not extract access token for authentication " + authentication, e);
        }

        if (accessToken != null
                && !key.equals(authenticationKeyGenerator.extractKey(readAuthentication(accessToken.getValue())))) {
            removeAccessToken(accessToken.getValue());
            // Keep the store consistent (maybe the same user is represented by this authentication but the details have
            // changed)
            storeAccessToken(accessToken, authentication);
        }
        return accessToken;
    }

    @Override
    public Collection<OAuth2AccessToken> findTokensByClientIdAndUserName(String clientId, String userName) {
        Collection<OAuth2AccessToken> tokens = new ArrayList<OAuth2AccessToken>();
        List<OAuthAccessToken> result = accessTokenRepository.findByClientIdAndUsername(clientId, userName);
        result.forEach(e -> tokens.add(deserializeAccessToken(e.getToken())));
        return tokens;
    }

    @Override
    public Collection<OAuth2AccessToken> findTokensByClientId(String clientId) {
        Collection<OAuth2AccessToken> tokens = new ArrayList<OAuth2AccessToken>();
        List<OAuthAccessToken> result = accessTokenRepository.findByClientId(clientId);
        result.forEach(e -> tokens.add(deserializeAccessToken(e.getToken())));
        return tokens;
    }


    protected byte[] serializeAccessToken(OAuth2AccessToken token) {
        return SerializationUtils.serialize(token);
    }

    protected byte[] serializeRefreshToken(OAuth2RefreshToken token) {
        return SerializationUtils.serialize(token);
    }

    protected byte[] serializeAuthentication(OAuth2Authentication authentication) {
        return SerializationUtils.serialize(authentication);
    }

    protected OAuth2AccessToken deserializeAccessToken(byte[] token) {
        return SerializationUtils.deserialize(token);
    }

    protected OAuth2RefreshToken deserializeRefreshToken(byte[] token) {
        return SerializationUtils.deserialize(token);
    }

    protected OAuth2Authentication deserializeAuthentication(byte[] authentication) {
        return SerializationUtils.deserialize(authentication);
    }

    protected String extractTokenKey(String value) {
        if (value == null) {
            return null;
        }
        MessageDigest digest;
        try {
            digest = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("MD5 algorithm not available.  Fatal (should be in the JDK).");
        }

        try {
            byte[] bytes = digest.digest(value.getBytes("UTF-8"));
            return String.format("%032x", new BigInteger(1, bytes));
        } catch (UnsupportedEncodingException e) {
            throw new IllegalStateException("UTF-8 encoding not available.  Fatal (should be in the JDK).");
        }
    }
}
