CREATE USER Test identified by Test;

GRANT create session to Test;

GRANT unlimited tablespace to Test;

GRANT create table to Test;